"""Bounded, versioned lookup. The Host owns source authority and all model calls."""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from datetime import datetime, timedelta, timezone
from hashlib import sha256
import json
import math
import time
from types import SimpleNamespace
from typing import Callable, NamedTuple, Protocol

from .comparisons import Comparisons
from .evidence import EvidenceDelivery, EvidenceLimits, OutputReadSet, format_recorded_time
from .maintenance import SourceInput
from .models import AccessScope, MemoryConflict, MemoryNotFound, MemoryValidationError, RecallReference, SourceContent, SourceSpan
from .retrieval import Retrieval, RetrievalItem, RetrievalReference
from .sources import locate_source_quote


class SourceView(Protocol):
    """One snapshot of the Host's currently authorized originals."""

    def pin(self, item: RetrievalItem) -> SourceInput: ...
    def read(self, pin: SourceInput, *, max_chars: int = ..., max_bytes: int = ...,
             discoverable: bool = False) -> SourceContent: ...
    def position(self, pin: SourceInput) -> tuple[object, int]: ...
    def relative(self, anchor: SourceInput, offset: int) -> tuple[SourceInput, str]: ...
    def recorded_offset(self, pin: SourceInput) -> int | None: ...


class SourcePort(Protocol):
    """Open a snapshot, then verify all reads before returning a usable receipt."""

    def view(self, access: AccessScope) -> SourceView: ...
    def authorized(self) -> bool: ...
    def verify_reads(self, access: AccessScope, reads: OutputReadSet, view: SourceView, *,
                     purpose: str | None = "lookup", record_watches=None) -> object: ...
    def require_fresh(self, snapshot: object) -> None: ...


@dataclass(frozen=True)
class RankedLookup:
    references: tuple
    coverage: dict
    question_time: dict
    current: object | None
    source_matches: tuple = ()
    match_query: object | None = None


@dataclass(frozen=True)
class LookupPack:
    groups: tuple
    records: tuple
    current: object | None
    max_tokens: int = 1024
    answer_time: dict | None = None


class LookupAssembly(NamedTuple):
    read_set: OutputReadSet
    signatures: object
    payload: dict
    pack: LookupPack


def _merge(domains):
    # Native cosine is comparable for one query/model. Lexical scores are
    # local to their own indices, so preserve each lexical order on fallback.
    scored = [(ref, score, domain, rank) for domain, rows in enumerate(domains)
              for rank, (ref, score, _) in enumerate(rows) if score is not None]
    scored.sort(key=lambda row: (-row[1], row[2], row[3]))
    lexical = [[ref for ref, score, hit in rows if score is None and hit] for rows in domains]
    return tuple([row[0] for row in scored] + [
        rows[rank] for rank in range(max(map(len, lexical), default=0))
        for rows in lexical if rank < len(rows)
    ])


class LookupEngine:
    """Keep ranking separate from the Session-owned, budgeted delivery."""

    def __init__(self, store, source_port: SourcePort, *, clock: Callable[[], int] | None = None,
                 source_errors=(), choice_prompts: tuple[str, str] | None = None,
                 ordered_change_policy: tuple[str, str, str] | None = None):
        self.store = store
        self.source_port = source_port
        self.retrieval = Retrieval(store)
        self.evidence = EvidenceDelivery(store)
        self.clock = clock or (lambda: time.time_ns() // 1_000_000)
        self.choice_prompts = choice_prompts
        self.ordered_change_policy = ordered_change_policy
        self.stale = (FileNotFoundError, MemoryConflict, MemoryNotFound, MemoryValidationError, *source_errors)

    def rank(self, access, query, *, current, question_time, prepare_choice=False):
        lookup_query = self.store.prepare_lookup_query(query)
        options = dict(limit=16, candidate_limit=32, max_chars=131072, query_wait_ms=100,
                       lookup_query=lookup_query)
        retrieval = self.retrieval
        matches = ()
        if (prepare_choice and current is not None and question_time.get("status") == "known"
                and lookup_query.supports_passage_split):
            raw, matches = retrieval.lookup_sources_with_matches(access, query, match_limit=WIDE_LIMIT,
                                                                  **options)
        else:
            raw = retrieval.lookup_sources(access, query, **options)

        notes = self.store.recall(access, query, now_ms=self.clock(),
            ranking="semantic_first", purpose="lookup", limit=16, max_chars=131072,
            lookup_query=lookup_query, max_vectors=4096,
            reference_filter=lambda ref: self.evidence.can_deliver(access, ref))
        comparable = lookup_query.model_is_current
        domains = (
            [(item.reference, item.semantic_score if comparable else None, item.lexical_match)
             for item in raw.items if item.source != current],
            [(RecallReference(item.memory_id, item.row_version),
              item.semantic_score if comparable else None, item.lexical_match) for item in notes.candidates],
        )
        coverage = asdict(notes.coverage)
        coverage["source_coverage"] = asdict(raw.coverage)
        coverage["budget_omitted"] += raw.coverage.budget_omitted
        if not comparable:
            matches = ()
        return RankedLookup(_merge(domains), coverage, question_time, current, matches,
                            lookup_query if matches else None)

    def search_originals(self, access, query):
        return self.retrieval.lookup_sources(access, query, limit=16, candidate_limit=32,
            max_chars=131072, query_wait_ms=100).items

    def require_reads(self, access, reads, view, *, purpose="lookup", record_watches=None):
        return self.source_port.verify_reads(access, reads, view, purpose=purpose, record_watches=record_watches)

    def capture(self, access, reads, *, purpose="lookup"):
        return self.store.capture_read_set(access, memories=reads.memories, sources=reads.sources,
            outputs=reads.outputs, candidates=reads.candidates, now_ms=self.clock(),
            purpose=purpose)

    def assemble(self, access, ranked, *, counter, method, _append_references=None, _original_choice=None):
        # Private per-call experiment seam: already ranked references from
        # trusted Host code, never request data, model IDs, labels, or body text.
        if (len(ranked.references) > 32 or (_append_references is not None and
                (not isinstance(_append_references, (tuple, list)) or len(_append_references) > 32))):
            raise MemoryValidationError("invalid_request")
        nominations = tuple(_append_references or ())
        if len(set((*ranked.references, *nominations))) > 32:
            raise MemoryValidationError("invalid_request")
        view = self.source_port.view(access)
        resolved = []
        unavailable = 0
        pinned = {}
        for ref in (*ranked.references, *nominations):
            try:
                if _append_references is not None and ref in pinned:
                    value = pinned[ref]
                else:
                    value = (view.pin(self.retrieval.detail(access, ref))
                             if isinstance(ref, RetrievalReference) else ref)
                    pinned[ref] = value
                resolved.append(value)
            except self.stale:
                unavailable += 1
                resolved.append(None)

        boundary = len(ranked.references)
        base = [ref for ref in resolved[:boundary] if ref is not None]
        appended = [ref for ref in resolved[boundary:] if ref is not None]
        max_tokens = 1024 if _append_references is None else 1536
        prefix_order, prefix_positions = None, ()

        def append_metadata(raw, records):
            nonlocal prefix_order, prefix_positions
            if prefix_order is None:
                snapshot = SimpleNamespace(payload=raw, record_inputs=records,
                    tokens=counter(raw), utf8_bytes=len(raw.encode("utf8")))
                first, _, _, prefix_positions = self._source_order(access, snapshot, view, counter)
                prefix_order = first.get("source_order", [])
            return {"source_order":prefix_order} if prefix_order else {}

        result = self._pack(access, base, view, counter,
            append_references=appended, append_max_tokens=(max_tokens if _append_references is not None else None),
            append_excluded_source=(ranked.current if _append_references is not None else None),
            append_metadata=(append_metadata if _append_references is not None else None))
        coverage = dict(ranked.coverage)
        if _append_references is None:
            coverage["budget_omitted"] += sum(group.status == "omitted" for group in result.groups)
        else:
            completed = {group.reference for group in result.groups if group.status == "complete"}
            coverage["budget_omitted"] += len({group.reference for group in result.groups
                if group.status == "omitted" and group.code not in
                {"already_selected", "no_new_sources", "excluded_source"} and group.reference not in completed})
        coverage["unavailable_groups"] = unavailable + sum(group.status == "unavailable" for group in result.groups)
        assembled = self._package(access, ranked.current, result, view, coverage, counter, method,
                                  max_tokens=max_tokens, prefix_positions=prefix_positions)
        if (_original_choice is not None and _append_references is None and not unavailable
                and not assembled[0].memories and 0 < len(assembled[3].groups) < 8
                and any(group.code == "payload_budget" for group in result.groups)):
            question, choices = _original_choice
            choice = prepare_excerpt_choice(self, access, ranked, base, view, assembled[0], question)
            if choice is not None:
                choices.append(choice)
        return assembled

    def _pack(self, access, resolved, view, counter, *, max_tokens=1024, max_groups=8,
              append_references=(), append_max_tokens=None, append_excluded_source=None, append_metadata=None):
        def read(pin, **limits):
            # A visible earlier answer may itself depend on a withdrawn
            # original. Omit that group before it takes a delivery slot.
            self.require_reads(access, OutputReadSet(sources=(pin,)), view)
            return view.read(pin, **limits)

        return self.evidence.assemble(access, resolved, limits=EvidenceLimits(
            8, 8192, 8192, max_tokens, max_groups=max_groups, max_references=32, read_sources=32,
            read_chars=262144, read_bytes=1048576),
            authorized=self.source_port.authorized, reader=SimpleNamespace(read=read), count_tokens=counter,
            now_ms=self.clock(), include_notes=True,
            append_references=append_references, append_max_tokens=append_max_tokens,
            append_excluded_source=append_excluded_source, append_metadata=append_metadata)

    def _package(self, access, current, result, view, coverage, counter, method, *,
                 prior=None, visited=(), state_change=None, max_tokens=1024, prefix_positions=()):
        memories = tuple(group.reference for group in result.groups if group.status == "complete"
                         and isinstance(group.reference, RecallReference))
        if state_change is not None:
            payload = json.loads(result.payload)
            aliases = {pin.source: row["source_id"]
                       for row, pin in zip(payload["records"], result.record_inputs, strict=True)}
            order = {}
            for label, excerpt in zip(("before", "after"), (state_change.left, state_change.right), strict=True):
                whole = SourceSpan(excerpt.namespace, excerpt.record_key, excerpt.revision)
                order[label] = [aliases[whole], excerpt.start_cp, excerpt.end_cp]
            payload = {**payload, "state_change": order}
            raw = json.dumps(payload, ensure_ascii=False, sort_keys=True)
            tokens, size = counter(raw), len(raw.encode("utf8"))
            if tokens > max_tokens or size > 8192:
                return None
            # The state relation is required by this lookup. The positional
            # hint is optional and may use only the remaining budget.
            result = replace(result, payload=raw, chars=len(raw), utf8_bytes=size, tokens=tokens)
        payload, tokens, size, position_reads = self._source_order(access, result, view, counter, max_tokens=max_tokens)
        if self.ordered_change_policy is not None and result.record_inputs:
            coverage = {**coverage, "ordered_state_lookup": True}
        before = prior or OutputReadSet()
        reads = self.capture(access, OutputReadSet(
            memories=(*before.memories, *memories),
            sources=(*before.sources, *result.record_inputs, *prefix_positions, *position_reads, *visited),
            outputs=before.outputs, candidates=before.candidates))
        signatures = self.require_reads(access, reads, view)
        package = LookupPack(tuple(group for group in result.groups if group.status == "complete"),
                             result.record_inputs, current, max_tokens,
                             admitted_time_metadata(payload["records"], result.record_inputs, view))
        return LookupAssembly(reads, signatures, {
            **payload, "coverage": {**coverage, "context_budget": {
                "used_tokens":tokens, "used_bytes":size, "method":method}},
        }, package)

    def _source_order(self, access, result, view, counter, *, max_tokens=1024):
        payload = json.loads(result.payload)
        locations = {}
        for row, pin in zip(payload["records"], result.record_inputs, strict=True):
            owner, position = view.position(pin)
            locations.setdefault(owner, []).append((position, row["source_id"], pin))
        edges, dependencies = list(payload.get("source_order", ())), []
        for positions in locations.values():
            positions.sort()
            for (i, left, anchor), (j, right, target) in zip(positions, positions[1:]):
                if j - i not in (1, 2):
                    continue
                try:
                    if view.relative(anchor, j - i)[0] != target:
                        continue
                    if j - i == 2:
                        bridge, _ = view.relative(anchor, 1)
                        self.require_reads(access, OutputReadSet(sources=(bridge,)), view)
                        dependencies.append(bridge)
                except self.stale:
                    continue
                edge = [left, right, j - i]
                if edge not in edges:
                    edges.append(edge)
        if edges:
            ordered = {**payload, "source_order":edges}
            raw = json.dumps(ordered, ensure_ascii=False, sort_keys=True)
            tokens, size = counter(raw), len(raw.encode("utf8"))
            if tokens <= max_tokens and size <= 8192:
                return ordered, tokens, size, tuple(dependencies)
        return payload, result.tokens, result.utf8_bytes, ()

    def supplement(self, access, package, prior, action, ranked, *, payload, counter, method,
                   required_originals=None, user_requested=False):
        """Apply one supplemental read. Host-selected originals must all fit."""
        view = self.source_port.view(access)
        prior = self.capture(access, prior)
        signatures = self.require_reads(access, prior, view)
        roots = tuple(group.reference for group in package.groups)
        anchor, visited, state_change = None, (), None
        if required_originals is not None:
            # Each nomination comes from the existing authorized source lookup,
            # independently of the role action and its serializable parameters.
            if {"record", "change_from"}.intersection(action) or len(required_originals) != 2:
                raise MemoryValidationError("invalid_request")
            try:
                additions = tuple(view.pin(item) for item in required_originals)
                self.require_reads(access, OutputReadSet(sources=additions), view)
            except self.stale:
                return None, signatures
            at = len(roots)
        elif "change_from" in action or "record" in action:
            is_state_change = "change_from" in action
            label = action["change_from" if is_state_change else "record"]
            anchor = self._visible_record(label, package, payload)
            if anchor.source == package.current:
                return None, signatures
            if is_state_change:
                ordered = self._ordered_change_reference(access, anchor, label, action, payload)
                if ordered is None:
                    return None, signatures
                addition, state_change = ordered
                additions, at = (addition,), len(roots)
            else:
                addition, visited = self._neighbor(access, view, anchor, action["direction"])
                at = next(i for i, group in enumerate(package.groups) if anchor.source in group.sources)
                at += action["direction"] == "next"
                additions = (addition,) if addition is not None else ()
        else:
            addition = self._new_original(access, view, package, ranked)
            at = len(roots)
            additions = (addition,) if addition is not None else ()
        originals = tuple(pin for pin in additions if isinstance(pin, SourceInput))
        if (not additions or set(additions).intersection(roots)
                or len({pin.source for pin in originals}) != len(originals)
                or any(pin.source == package.current or pin in package.records for pin in originals)):
            return None, signatures

        release = self._release(package, action.get("release_group"), anchor)
        discards = (None, release) if release is not None else (None,)
        # A direct recall can read one new original on its existing second pass.
        # Distinct original, text and authorization bounds still guard the final packet.
        group_limit = 9 if user_requested and len(additions) == len(originals) == 1 else 8
        proposals = []
        for discarded in discards:
            proposed = list(roots)
            proposed[at:at] = additions
            if discarded is not None:
                proposed.remove(discarded)
            if len(proposed) <= group_limit:
                proposals.append(tuple(proposed))

        # Only the existing user-authorized follow-up can gain space. Keep
        # successful smaller packs and retry only rejected token fits. The
        # read set, group/source/byte limits and legitimacy of a proposed
        # discard remain identical at either budget.
        budgets = ((package.max_tokens, 1536) if user_requested and len(additions) == 1
                   and package.max_tokens < 1536 else (package.max_tokens,))
        for limit in budgets:
            budget_blocked = []
            for proposed in proposals:
                result = self._pack(access, proposed, view, counter, max_tokens=limit, max_groups=group_limit)
                selected = tuple(group.reference for group in result.groups if group.status == "complete")
                if selected != proposed:
                    if all(group.status == "complete" or group.code == "payload_budget" for group in result.groups):
                        budget_blocked.append(proposed)
                    continue
                if state_change is not None:
                    added = {pin.source for pin in result.record_inputs} - {pin.source for pin in package.records}
                    if not added or package.current in added:
                        continue
                change = self._package(access, package.current, result, view, payload["coverage"], counter, method,
                                       prior=prior, visited=visited, state_change=state_change, max_tokens=limit)
                if change is not None:
                    return change, change[1]
                # Required relation metadata can overflow after raw groups fit.
                if state_change is not None:
                    budget_blocked.append(proposed)
            proposals = budget_blocked
        return None, signatures

    def _ordered_change_reference(self, access, anchor, label, action, payload):
        if self.ordered_change_policy is None:
            return None
        body, = (row["text"] for row in payload["records"] if row["source_id"] == label)
        try:
            excerpt = locate_source_quote(anchor.source, body, action["quote"])
        except MemoryValidationError:
            return None
        return Comparisons(self.store).find_authorized_change(access, excerpt,
            direction=action["direction"], expected_policy=self.ordered_change_policy)

    @staticmethod
    def _visible_record(label, package, payload):
        for row, pin in zip(payload["records"], package.records, strict=True):
            if row["source_id"] == label:
                return pin
        raise MemoryValidationError("invalid_request")

    def _neighbor(self, access, view, anchor, direction):
        step = 1 if direction == "next" else -1
        visited = []
        for distance in (step, 2 * step):
            try:
                pin, role = view.relative(anchor, distance)
                self.require_reads(access, OutputReadSet(sources=(pin,)), view)
            except self.stale:
                break
            if role == "user":
                return pin, tuple(visited)
            if role != "assistant":
                break
            visited.append(pin)
        return None, ()

    def _new_original(self, access, view, package, ranked):
        seen = {pin.source for pin in package.records}
        for item in ranked:
            if item.source in seen or item.source == package.current:
                continue
            try:
                pin = view.pin(item)
                self.require_reads(access, OutputReadSet(sources=(pin,)), view)
                return pin
            except self.stale:
                continue
        return None

    def _release(self, package, label, anchor):
        for group in package.groups:
            pin = group.reference
            if (group.group_id == label and isinstance(pin, SourceInput)
                    and group.sources == (pin.source,) and not group.highlights and pin != anchor
                    and not any(other is not group and pin.source in other.sources for other in package.groups)):
                return pin
        return None


def admitted_time_metadata(records, pins, view):
    """Use only originals from the verified view and their recorded clocks."""
    offsets, instants = {}, {}
    for row, pin in zip(records, pins, strict=True):
        identifier = row["source_id"]
        offsets[identifier] = view.recorded_offset(pin)
        if row["recorded_time"]["status"] == "known":
            instants.setdefault(pin.recorded_at_ms, []).append(identifier)
    return {"offsets": offsets, "recorded_order": [instants[at] for at in sorted(instants)]}


ORIGINAL_LIMIT = 16
WIDE_LIMIT = 64
EXCERPT_BYTES = 720
REPLY_LIMIT = 8
INPUT_BYTES = 65_536

@dataclass(frozen=True)
class ExcerptChoicePlan:
    aliases: dict
    messages: tuple
    reads: object
    signatures: object


def prepare_excerpt_choice(lookup, access, ranked, originals, view, baseline_reads, question):
    """Prepare a read-bounded choice request using only trusted original candidates."""
    if (lookup.choice_prompts is None or ranked.current is None or ranked.question_time.get("status") != "known"
            or not originals or len(originals) > ORIGINAL_LIMIT
            or any(not isinstance(pin, SourceInput) for pin in originals)):
        return None
    date = datetime.fromisoformat(ranked.question_time["utc"].replace("Z", "+00:00"))
    cutoff = (date - datetime(1970, 1, 1, tzinfo=timezone.utc)) // timedelta(milliseconds=1)
    if any(pin.source == ranked.current or pin.recorded_at_ms > cutoff for pin in originals):
        return None
    if len(ranked.source_matches) > len(originals):
        try:
            wide = _wide_choice(lookup, access, ranked, originals, view, baseline_reads, question, cutoff)
        except lookup.stale + (ValueError,):
            # A reserve that changed or can't be projected cannot authorize
            # new reads. The independently valid original proposal still can.
            wide = None
        if wide is not None:
            return wide
    return _render_choice(lookup, access, originals, view, baseline_reads, question, cutoff)


def _wide_choice(lookup, access, ranked, originals, view, baseline_reads, question, cutoff):
    split_passage = ranked.match_query.passage_splitter()
    if split_passage is None:
        return None
    scores = {}
    for match in ranked.source_matches:
        item = lookup.retrieval.detail(access, match.reference)
        if item.source == ranked.current:
            continue
        pin = view.pin(item)
        if pin.recorded_at_ms <= cutoff:
            scores[pin] = match.chunk_scores
    if len(scores) <= len(originals) or tuple(scores)[:len(originals)] != tuple(originals):
        return None
    return _render_choice(lookup, access, scores, view, baseline_reads, question, cutoff,
                          scores=scores, split_passage=split_passage)


def _excerpt(text, chunk_scores, split_passage):
    if len(text.encode("utf8")) <= EXCERPT_BYTES:
        return 0, len(text)
    chunks = list(split_passage(text))
    if len(chunks) != len(chunk_scores) or "".join(chunks) != text:
        raise ValueError("source_chunk_projection_changed")
    low = high = max(range(len(chunks)), key=chunk_scores.__getitem__)
    weights = [len(chunk.encode("utf8")) for chunk in chunks]
    used = weights[low]
    if used > EXCERPT_BYTES:
        raise ValueError("source_chunk_exceeds_excerpt_budget")
    while True:
        neighbors = [j for j in (low-1, high+1) if 0 <= j < len(chunks)
                     and used + weights[j] <= EXCERPT_BYTES]
        if not neighbors:
            break
        neighbor = max(neighbors, key=lambda j:(chunk_scores[j], -j))
        low, high = min(low, neighbor), max(high, neighbor)
        used += weights[neighbor]
    start = sum(map(len, chunks[:low]))
    return start, start + sum(map(len, chunks[low:high+1]))


def _render_choice(lookup, access, originals, view, baseline_reads, question, cutoff,
                   *, scores=None, split_passage=None):
    ordered = sorted(dict.fromkeys(originals), key=lambda pin:sha256(
        (question + pin.source.record_key).encode("utf8")).digest())
    aliases = {f"r{i:02d}": pin for i, pin in enumerate(ordered, 1)}
    rows = []
    for name, pin in aliases.items():
        record = view.read(pin, discoverable=True)
        row = {"id":name, "text":record.text, "speaker_role":record.speaker_role,
               "speaker_ref":record.speaker_ref, "recorded_utc":format_recorded_time(pin.recorded_at_ms).utc}
        if scores is not None:
            start, end = _excerpt(record.text, scores[pin], split_passage)
            if start or end != len(record.text):
                row["text"] = record.text[start:end]
                row["excerpt"] = [start, end]
        rows.append(row)
    content = json.dumps({"question":question, "accepted_question_utc_ms":cutoff, "sources":rows},
                         ensure_ascii=False, separators=(",",":"))
    rule, excerpt_rule = lookup.choice_prompts
    if scores is not None:
        rule += "\n" + excerpt_rule
    messages = ({"role":"system", "content":rule}, {"role":"user", "content":content})
    if len(json.dumps(messages, ensure_ascii=False).encode("utf8")) > INPUT_BYTES:
        return None
    reads = lookup.capture(access, replace(baseline_reads, sources=tuple(dict.fromkeys(
        (*baseline_reads.sources, *ordered)))))
    signatures = lookup.require_reads(access, reads, view)
    return ExcerptChoicePlan(aliases, messages, reads, signatures)


def requested_pins(proposal, aliases):
    if not isinstance(proposal, str) or len(proposal) > 4096:
        return ()

    def unique_fields(fields):
        result = dict(fields)
        if len(fields) != len(result):
            raise ValueError("duplicate choice field")
        return result

    try:
        value = json.loads(proposal, object_pairs_hook=unique_fields)
    except (ValueError, RecursionError):
        return ()
    if not isinstance(value, dict) or set(value) != {"groups"}:
        return ()
    groups = value["groups"]
    if not isinstance(groups, list) or not 1 <= len(groups) <= REPLY_LIMIT:
        return ()
    ordered = []
    for group in groups:
        if (not isinstance(group, list) or not 1 <= len(group) <= REPLY_LIMIT
                or any(not isinstance(ref, str) or ref not in aliases for ref in group)
                or len(group) != len(set(group))):
            return ()
        ordered.extend(group)
    ids = tuple(dict.fromkeys(ordered))
    return tuple(aliases[ref] for ref in ids) if len(ids) <= REPLY_LIMIT else ()


def apply_excerpt_choice(lookup, access, baseline: LookupAssembly, choice: ExcerptChoicePlan, proposal, counter, method) -> LookupAssembly:
    """Recheck selector-only dependencies even if the first packet is kept."""
    view = lookup.source_port.view(access)
    reads = lookup.capture(access, choice.reads)
    signatures = lookup.require_reads(access, reads, view)
    fallback = baseline._replace(read_set=reads, signatures=signatures)
    wanted = requested_pins(proposal, choice.aliases)
    if not wanted or wanted == tuple(group.reference for group in baseline.pack.groups):
        return fallback
    packed = lookup._pack(access, wanted, view, counter)
    if tuple(packed.record_inputs) != wanted or any(group.status != "complete" for group in packed.groups):
        return fallback
    coverage = {k:v for k,v in baseline.payload["coverage"].items() if k != "context_budget"}
    return lookup._package(
        access, baseline.pack.current, packed, view, coverage, counter, method, prior=reads)


def serialize_reference(value):
    # Match _decide's model-frame serializer, including its default spaces.
    return json.dumps(value, ensure_ascii=False)


def estimate_reply_tokens(value):
    """A bounded practical estimate, not an exact closed-model tokenizer.

    ASCII uses one estimated token per three codepoints; non-ASCII uses two
    per codepoint (four for non-BMP symbols). The separate byte ceiling bounds
    payload size even when an unknown reply tokenizer differs from this method.
    """
    ascii_count = sum(ord(char) < 128 for char in value)
    return math.ceil(ascii_count / 3) + sum(
        4 if ord(char) > 0xffff else 2 for char in value if ord(char) >= 128)


def pack_reference(candidates, *, token_count=None, count_method=None,
                   token_limit=512, byte_limit=4096, item_limit=4, selected=None):
    """Pack whole, already revalidated candidates; never truncate source meaning."""
    exact = token_count is not None
    counter = token_count or estimate_reply_tokens
    method = count_method if exact else "ascii_3_nonascii_2_nonbmp_4_estimate"
    if exact and (not isinstance(method, str) or not method.strip()):
        raise ValueError("reply_token_count_method_required")
    entries = []
    payload = {"authority":"user_reference_only", "entries":entries}

    def count_tokens(text):
        count = counter(text)
        if type(count) is not int or count < 0:
            raise ValueError("invalid_reply_token_count")
        return count

    omitted = 0
    for candidate in candidates:
        entry = {"text":candidate.text,
            "scope":candidate.scope.kind,"kind":candidate.kind}
        if candidate.condition:
            entry["condition"] = candidate.condition
        if len(entries) >= item_limit:
            omitted += 1
            continue
        entries.append(entry)
        text = serialize_reference(payload)
        # An already oversized whole entry cannot fit regardless of token count.
        # Reject it before invoking an exact tokenizer or the codepoint estimate.
        if len(text.encode("utf-8")) > byte_limit or count_tokens(text) > token_limit:
            entries.pop()
            omitted += 1
        elif selected is not None:
            selected.append(candidate)
    text = serialize_reference(payload)
    count, size = count_tokens(text), len(text.encode("utf-8"))
    budget = {"unit":"reply_model_tokens" if exact else "estimated_reply_tokens",
        "method":method,"limit":token_limit,"used":count,
        "hard_utf8_bytes":byte_limit,"used_utf8_bytes":size}
    return payload, budget, omitted
