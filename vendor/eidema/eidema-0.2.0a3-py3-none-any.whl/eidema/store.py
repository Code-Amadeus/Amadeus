"""One SQLite connection owns transactions, FTS maintenance and checkpoints.

No model work holds the database lock. Index commits and final recall assembly
re-read authoritative rows, so a late computation cannot revive obsolete data.
"""
from __future__ import annotations

from concurrent.futures import Future
from contextlib import contextmanager
from collections import defaultdict, deque
from dataclasses import asdict, replace
import hashlib
import heapq
from importlib.resources import files
import json
from pathlib import Path
import re
import sqlite3
import struct
import threading
import time
from typing import Callable, Sequence, TYPE_CHECKING
from uuid import uuid4

import numpy as np

from .embeddings import Embedder, EmbedderInfo, LookupQuery, _check_lookup_query, _embed_query, normalized
from .sources import _identity, _validate_source
from .models import (
    AccessScope, MemoryScope, SourceSpan, SourceRetirement, Memory, MemoryDetail, OperationResult,
    RecallReference, RecallCandidate, RecallCoverage, RecallResult, StoreStatus, IndexResult,
    MemoryConflict, MemoryNotFound, MemoryValidationError, ForgetTarget, ForgetPreview,
    MutationPreview, SourcePolicySnapshot,
)

if TYPE_CHECKING:
    from .candidates import CandidateReference
    from .evidence import OutputAncestry, OutputReadSet


_MAX_RECALL_CHARS = 1_000_000
_MAX_OUTPUT_GRAPH = 10000


def _terms(text: str, *, query: bool = False) -> list[str]:
    # Latin identifiers plus CJK single characters and adjacent bigrams. This is
    # lexical normalization, never a translation or a semantic-recall substitute.
    tokens = re.findall(r"[\w]+", text.lower(), re.UNICODE)
    out = []
    for token in tokens:
        runs = re.findall(r"[\u3400-\u9fff\u3040-\u30ff\uac00-\ud7af]+|[^\u3400-\u9fff\u3040-\u30ff\uac00-\ud7af]+", token)
        for run in runs:
            if re.match(r"[\u3400-\u9fff\u3040-\u30ff\uac00-\ud7af]", run):
                if not query or len(run) == 1:
                    out.extend(run)
                out.extend(run[i:i+2] for i in range(len(run)-1))
            else:
                out.append(run)
    return out


def _acquire_owner(path: str):
    if path == ":memory:":
        return None
    owner = open(path + ".owner", "a+b")
    try:
        if owner.seek(0, 2) == 0:
            owner.write(b"0")
            owner.flush()
        owner.seek(0)
        try:
            import msvcrt
            msvcrt.locking(owner.fileno(), msvcrt.LK_NBLCK, 1)
        except ImportError:
            import fcntl
            fcntl.flock(owner.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return owner
    except OSError:
        owner.close()
        raise MemoryConflict("store_already_owned") from None


@contextmanager
def source_policy_recovery_owner(path: str | Path):
    """Exclusively own an existing file store without opening or changing SQLite.

    For Host maintenance only: callers must validate readable authoritative
    state and identity before rebuilding derived policy. This acquires the same
    nonblocking owner lock as MemoryStore, but performs no initialization,
    migration, checkpoint, cleanup or database access. It cannot recover core.
    """
    target = Path(path).resolve()
    if str(path) == ":memory:" or not target.is_file():
        raise MemoryValidationError("recovery_requires_existing_file_store")
    owner = _acquire_owner(str(target))
    try:
        yield target
    finally:
        owner.close()


class _EmbeddingGate:
    """One resource, a bounded query queue, and at most four-query priority.

    Indexing releases ownership after each passage. Waiting queries get the
    next unit, while a continuous query stream still permits index progress.
    """

    def __init__(self):
        self._condition = threading.Condition()
        self._active = False
        self._queries = self._background = self._query_streak = 0

    def acquire(self, blocking=True, *, query=False, timeout=None):
        deadline = None if timeout is None else time.monotonic() + timeout
        with self._condition:
            if query and self._queries >= 8:
                return False
            if query:
                self._queries += 1
            else:
                self._background += 1
            try:
                while self._active or (query and self._background and self._query_streak >= 4) or (not query and self._queries and self._query_streak < 4):
                    remaining = None if deadline is None else deadline - time.monotonic()
                    if not blocking or (remaining is not None and remaining <= 0):
                        return False
                    self._condition.wait(remaining)
                self._active = True
                self._query_streak = self._query_streak + 1 if query else 0
                return True
            finally:
                if query:
                    self._queries -= 1
                else:
                    self._background -= 1
                self._condition.notify_all()

    def release(self):
        with self._condition:
            self._active = False
            self._condition.notify_all()

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, *exc):
        self.release()


class _IndexOwnership:
    """One ephemeral native owner; subscribers observe only its settlement."""

    def __init__(self):
        self._condition = threading.Condition()
        self._owned = False
        self._done = None

    def acquire(self, blocking=True, timeout=-1):
        deadline = None if timeout == -1 else time.monotonic() + timeout
        with self._condition:
            while self._owned:
                remaining = None if deadline is None else deadline - time.monotonic()
                if not blocking or remaining is not None and remaining <= 0:
                    return False
                self._condition.wait(remaining)
            self._owned = True
            return True

    def settlement(self):
        with self._condition:
            if not self._owned:
                return None
            if self._done is None:
                self._done = Future()
                self._done.set_running_or_notify_cancel()
            return self._done

    def release(self):
        with self._condition:
            if not self._owned:
                raise RuntimeError("release unlocked index ownership")
            self._owned = False
            settled, self._done = self._done, None
            self._condition.notify_all()
        # Native work has already left its DB/embedding locks. Run subscriber
        # callbacks after this resource's short ownership section is released.
        if settled is not None:
            settled.set_result(None)

    def locked(self):
        with self._condition:
            return self._owned

    def __enter__(self):
        self.acquire()
        return self

    def __exit__(self, *exc):
        self.release()


class MemoryStore:
    """A single managed owner per database, used off the Host event loop.

    ``access`` and requested scopes MUST be constructed by the trusted Host.
    This library checks consistency; it cannot authenticate UI callers.
    """

    def __init__(self, path: str | Path, *, embedder: Embedder | None = None,
                 max_text_chars: int = 32768, scan_timeout_ms: float | None = 250,
                 semantic_threshold: float | None = None):
        if max_text_chars < 1 or (scan_timeout_ms is not None and scan_timeout_ms < 0) or (semantic_threshold is not None and not -1 <= semantic_threshold <= 1):
            raise MemoryValidationError("invalid_limits")
        self._lock = threading.RLock()
        self._embedding_lock = _EmbeddingGate()
        self._index_lock = _IndexOwnership()
        self._formation_lock = threading.Lock()
        self._closed = False
        self._embedder = embedder
        self._source_vectors = None
        self._max_text_chars = max_text_chars
        self._scan_timeout_ms = scan_timeout_ms
        self._semantic_threshold = semantic_threshold
        if embedder is not None:
            _identity(embedder.version)
            if not isinstance(embedder.dimensions, int) or not 1 <= embedder.dimensions <= 65536:
                raise MemoryValidationError("invalid_dimensions")
        path = str(Path(path).resolve()) if str(path) != ":memory:" else ":memory:"
        if path != ":memory:":
            Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._owner_file = _acquire_owner(path)
        try:
            self._initialize(path, embedder)
        except BaseException:
            if hasattr(self, "_db"):
                self._db.close()
            if self._owner_file:
                self._owner_file.close()
            raise

    def _initialize(self, path, embedder):
        self._db = sqlite3.connect(path, check_same_thread=False, isolation_level=None,
                                   timeout=2.0)
        self._db.row_factory = sqlite3.Row
        with self._lock:
            self._db.execute("PRAGMA foreign_keys=ON")
            self._db.execute("PRAGMA secure_delete=ON")
            self._db.execute("PRAGMA synchronous=FULL")
            self._db.execute("PRAGMA journal_mode=WAL")
            # SQLite runs this on the same committing owner connection. A
            # blocked reader may delay recycling; forget has its own observable
            # durable cleanup marker and explicit TRUNCATE recovery.
            self._db.execute("PRAGMA wal_autocheckpoint=256")
            existing = self._db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='store_state'").fetchone()
            version = self._db.execute("SELECT schema_version FROM store_state").fetchone()[0] if existing else None
            if version is not None and version not in range(1, 21):
                raise MemoryValidationError("unsupported_schema")
            # Schema 4 widens the attempt outcome CHECK without relabeling old
            # completions. Rebuild only that control table, preserving its rows,
            # together with all new tables and the version in one transaction.
            schema = files("eidema").joinpath("schema.sql").read_text(encoding="utf-8")
            before = "ALTER TABLE formation_attempts RENAME TO formation_attempts_v3;\n" if version == 3 else ""
            after = ("\nINSERT INTO formation_attempts(attempt_id,task_id,reservation_key,window_id,reserved_input_tokens,reserved_output_tokens,reserved_cost_units,actual_input_tokens,actual_output_tokens,actual_cost_units,outcome,reserved_at_ms) SELECT attempt_id,task_id,reservation_key,window_id,reserved_input_tokens,reserved_output_tokens,reserved_cost_units,actual_input_tokens,actual_output_tokens,actual_cost_units,outcome,reserved_at_ms FROM formation_attempts_v3;"
                     "\nDROP TABLE formation_attempts_v3;"
                     "\nCREATE INDEX IF NOT EXISTS formation_attempts_window ON formation_attempts(window_id);\n") if version == 3 else ""
            if version in (3, 4):
                before += ("ALTER TABLE source_states ADD COLUMN lookup_allowed INTEGER NOT NULL DEFAULT 0 CHECK(lookup_allowed IN (0,1));\n"
                           "ALTER TABLE source_changes ADD COLUMN lookup_allowed INTEGER NOT NULL DEFAULT 0 CHECK(lookup_allowed IN (0,1));\n")
            if version in (4, 5, 6):
                # Keep evidence/projection foreign keys aimed at the stable
                # candidates name. The cache rows, UUIDs, FTS and vectors stay
                # in place while only the authority CHECK is widened.
                before += ("DROP TRIGGER IF EXISTS retrieval_candidate_change;\n"
                           "DROP INDEX candidates_pending;\nDROP INDEX candidates_task;\n"
                           "ALTER TABLE candidates RENAME TO candidates_previous;\n")
                after += ("\nINSERT INTO candidates(candidate_id,task_id,attempt_id,item_key,text,kind,condition_text,created_at_ms,row_version,state,invalid_reason,index_state) SELECT * FROM candidates_previous;"
                          "\nDROP TABLE candidates_previous;\n")
            if version in (1, 2, 3, 4, 5):
                before += ("ALTER TABLE origins RENAME TO origins_previous;\n"
                           "DROP INDEX IF EXISTS origins_source;\n"
                           "ALTER TABLE operations ADD COLUMN candidate_id TEXT REFERENCES candidates(candidate_id);\n"
                           "ALTER TABLE operations ADD COLUMN reviewed_at_ms INTEGER;\n")
                after += ("\nINSERT INTO origins(memory_id,namespace,record_key,revision,start_cp,end_cp) SELECT * FROM origins_previous;"
                          "\nDROP TABLE origins_previous;\n")
            if version in (1, 2, 3, 4, 5, 6):
                before += ("DROP INDEX IF EXISTS memory_scope;\nDROP INDEX IF EXISTS memory_root;\n"
                           "ALTER TABLE memories RENAME TO memories_previous;\n")
                after += ("\nINSERT INTO memories(memory_id,root_id,user_id,scope_kind,character_id,project_id,text,kind,condition_text,state,status_reason,replaced_by,row_version,created_at_ms,updated_at_ms,index_state,index_version,index_error) SELECT * FROM memories_previous;"
                          "\nDROP TABLE memories_previous;\n")
            if version is not None and 3 <= version < 19:
                before += ("ALTER TABLE source_states ADD COLUMN evidence_only INTEGER NOT NULL DEFAULT 0 CHECK(evidence_only IN (0,1));\n"
                           "ALTER TABLE source_changes ADD COLUMN evidence_only INTEGER NOT NULL DEFAULT 0 CHECK(evidence_only IN (0,1));\n")
            if version in (3, 4, 5, 6):
                before += ("ALTER TABLE source_states ADD COLUMN derived_use_mask INTEGER NOT NULL DEFAULT 0 CHECK(derived_use_mask BETWEEN 0 AND 3);\n"
                           "ALTER TABLE source_changes ADD COLUMN derived_use_mask INTEGER NOT NULL DEFAULT 0 CHECK(derived_use_mask BETWEEN 0 AND 3);\n")
            if version in (3, 4, 5, 6, 7):
                before += "ALTER TABLE formation_inputs ADD COLUMN input_role TEXT NOT NULL DEFAULT 'incremental' CHECK(input_role IN ('incremental','context'));\n"
            if version in (3, 4, 5, 6, 7, 8, 9):
                before += ("ALTER TABLE formation_tasks ADD COLUMN work_class TEXT NOT NULL DEFAULT 'warm' CHECK(work_class IN ('warm','cold'));\n"
                           "DROP INDEX IF EXISTS formation_one_active;\n")
            if version in (4, 5, 6, 7, 8, 9):
                before += "ALTER TABLE formation_attempts ADD COLUMN cold_dispatched_at_ms INTEGER;\n"
            if version in (3, 4, 5, 6, 7, 8, 9, 10):
                before += "ALTER TABLE formation_tasks ADD COLUMN target_use_mask INTEGER NOT NULL DEFAULT 0 CHECK(target_use_mask BETWEEN 0 AND 3);\n"
            if version in (3, 4, 5, 6, 7, 8, 9, 10, 11, 12):
                before += ("DROP INDEX IF EXISTS formation_one_active;\n"
                           "ALTER TABLE formation_tasks RENAME TO formation_tasks_previous;\n")
                after += ("\nINSERT INTO formation_tasks(rowid,task_id,stream_id,pipeline_version,cursor_before,cursor_after,state,max_attempts,current_attempt_id,work_class,target_use_mask)"
                          " SELECT rowid,task_id,stream_id,pipeline_version,cursor_before,cursor_after,state,max_attempts,current_attempt_id,work_class,target_use_mask FROM formation_tasks_previous;"
                          "\nDROP TABLE formation_tasks_previous;\n")
            if version in (13, 14):
                before += ("DROP INDEX IF EXISTS formation_one_active;\n"
                           "ALTER TABLE formation_tasks ADD COLUMN reformation_event_id INTEGER REFERENCES reformation_events(event_id);\n"
                           "ALTER TABLE formation_tasks ADD COLUMN reformation_candidate_id TEXT;\n"
                           "ALTER TABLE formation_tasks ADD COLUMN reformation_key TEXT;\n")
            if version in (7, 8, 9, 10, 11, 12, 13, 14):
                before += "ALTER TABLE candidates ADD COLUMN reformation_event_id INTEGER REFERENCES reformation_events(event_id);\n"
            if version is not None and version < 18:
                before += "ALTER TABLE operations ADD COLUMN formation_task_id TEXT REFERENCES formation_tasks(task_id);\n"
            # One-time physical metadata upgrade. Early unsealed research17
            # had only the semantic version guard, so inspect that actual layout
            # too; current17 opens never repeat the terminal-history backfill.
            maintenance_order_missing = (version in (13, 14, 15, 16, 17)
                and "maintenance_completion_order" not in {r[1] for r in self._db.execute("PRAGMA table_info(formation_tasks)")})
            if maintenance_order_missing:
                before += "ALTER TABLE formation_tasks ADD COLUMN maintenance_completion_order INTEGER;\n"
            if version not in (17, 18, 19) or maintenance_order_missing:
                # Public legacy warm maintenance has a last attempt and owns
                # its stream until terminal. Final-attempt order therefore
                # reconstructs old completion order once, independent of clocks
                # and of cancelled task creation IDs. New completions use the
                # terminal-owned indexed MAX+1 below, not implicit rowids.
                after += """
WITH completed AS (
    SELECT t.task_id,ROW_NUMBER() OVER(PARTITION BY t.stream_id,t.pipeline_version ORDER BY a.rowid) AS sequence
    FROM formation_tasks t JOIN formation_attempts a ON a.attempt_id=t.current_attempt_id
    WHERE (t.reformation_event_id IS NOT NULL OR t.reformation_key IS NOT NULL)
      AND t.state IN ('done','abandoned')
)
UPDATE formation_tasks SET maintenance_completion_order=(SELECT sequence FROM completed WHERE completed.task_id=formation_tasks.task_id)
WHERE task_id IN (SELECT task_id FROM completed);
"""
            # Legacy rename is deliberately bounded to initialization. With FK
            # enforcement temporarily disabled, SQLite won't rewrite stable
            # child references to the temporary authority table's name.
            rebuild = version in (1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12)
            if rebuild:
                self._db.execute("PRAGMA foreign_keys=OFF")
                self._db.execute("PRAGMA legacy_alter_table=ON")
            try:
                self._db.executescript("BEGIN IMMEDIATE;\n" + before + schema + after + "\nUPDATE store_state SET schema_version=20 WHERE singleton=1;")
                if version != 19 and self._db.execute("PRAGMA foreign_key_check").fetchone() is not None:
                    raise MemoryValidationError("migration_foreign_key_failure")
                self._db.execute("COMMIT")
            except BaseException:
                if self._db.in_transaction:
                    self._db.execute("ROLLBACK")
                raise
            finally:
                if rebuild:
                    self._db.execute("PRAGMA legacy_alter_table=OFF")
                    self._db.execute("PRAGMA foreign_keys=ON")
            try:
                self._db.execute("INSERT INTO memory_fts(memory_fts,rank) VALUES('secure-delete',1)")
                self._db.execute("INSERT INTO retrieval_fts(retrieval_fts,rank) VALUES('secure-delete',1)")
            except sqlite3.DatabaseError:
                self._db.close()
                raise MemoryValidationError("fts_secure_delete_requires_sqlite_3_42") from None
            # A newly acquired owner cannot know whether a previous external
            # call ran. Preserve its reservation and attempt quota, but revoke
            # commit eligibility. Facade construction never performs recovery.
            with self._transaction():
                self._db.execute("UPDATE formation_attempts SET outcome='unknown' WHERE outcome='reserved'")
                self._db.execute("UPDATE formation_tasks SET state='unknown' WHERE state='reserved'")
            # Restart uses authoritative active rows for explicit-memory index.
            if embedder is not None:
                with self._transaction():
                    self._db.execute("DELETE FROM embeddings WHERE embedding_version<>?", (embedder.version,))
                    self._db.execute("UPDATE memories SET index_state='pending',index_error=NULL WHERE state='active' AND invalid_reason IS NULL AND (index_version IS NULL OR index_version<>?)", (embedder.version,))
            with self._transaction():
                self._reset_retrieval_embeddings(embedder)
        if self._cleanup_pending():
            self.cleanup()

    @property
    def embedder_info(self) -> EmbedderInfo | None:
        with self._lock:
            self._check()
            model = self._embedder
            return None if model is None else EmbedderInfo(
                model.version, model.dimensions, callable(getattr(model, "split_passage", None)))

    def configure_embedder(self, embedder: Embedder | None) -> None:
        """Attach a Host-loaded resource offloop; version changes require reindex.

        This waits for the one bounded embedding operation. Callers must not
        invoke it from inside an embedder callback.
        """
        if embedder is not None:
            _identity(embedder.version)
            if not isinstance(embedder.dimensions, int) or not 1 <= embedder.dimensions <= 65536:
                raise MemoryValidationError("invalid_dimensions")
        with self._embedding_lock, self._lock:
            self._check()
            with self._transaction():
                if embedder is not None:
                    self._db.execute("DELETE FROM embeddings WHERE embedding_version<>?", (embedder.version,))
                    self._db.execute("UPDATE memories SET index_state='pending',index_error=NULL WHERE state='active' AND invalid_reason IS NULL AND (index_version IS NULL OR index_version<>?)", (embedder.version,))
                self._reset_retrieval_embeddings(embedder)
                self._embedder = embedder
            if self._source_vectors is not None:
                self._source_vectors.reset()

    def _reset_retrieval_embeddings(self, embedder):
        # Projection vectors share this owner's model/configuration. FTS and
        # candidate materialization state survive a semantic-resource change.
        if embedder is not None:
            self._db.execute("DELETE FROM retrieval_embeddings WHERE embedding_version<>? OR dimensions<>?", (embedder.version, embedder.dimensions))
            self._db.execute("UPDATE retrieval_documents SET index_state='pending',index_version=NULL,index_dimensions=NULL,index_error=NULL WHERE index_version IS NULL OR index_version<>? OR index_dimensions IS NULL OR index_dimensions<>?", (embedder.version, embedder.dimensions))

    @contextmanager
    def _transaction(self):
        self._db.execute("BEGIN IMMEDIATE")
        try:
            yield
            self._db.execute("COMMIT")
        except BaseException:
            self._db.execute("ROLLBACK")
            raise

    def _check(self):
        if self._closed:
            raise MemoryValidationError("store_closed")

    @staticmethod
    def _access(access: AccessScope):
        _identity(access.user_id)
        _identity(access.character_id)
        if access.project_id is not None:
            _identity(access.project_id)

    @staticmethod
    def _where(access: AccessScope, alias: str = "m"):
        return (f"{alias}.user_id=? AND ({alias}.scope_kind='shared' OR "
                f"({alias}.character_id=? AND ({alias}.scope_kind='character' OR "
                f"({alias}.scope_kind='project' AND {alias}.project_id=?))))",
                (access.user_id, access.character_id, access.project_id))

    @staticmethod
    def _purpose_bit(purpose):
        if purpose not in ("ordinary", "lookup"):
            raise MemoryValidationError("invalid_memory_purpose")
        return 2 if purpose == "ordinary" else 1

    @classmethod
    def _eligibility(cls, purpose, alias="m"):
        bit = cls._purpose_bit(purpose)
        return f"{alias}.state='active' AND {alias}.invalid_reason IS NULL AND ({alias}.retention='explicit' OR ({alias}.use_mask & {bit})<>0)"

    @classmethod
    def _eligible_row(cls, row, purpose, *, require_current=True):
        """Keep original use permissions on privacy-only historical reads.

        Output ancestry owns historical privacy invalidation. Direct consumers
        still require an active row; a retired ancestor is never new authority.
        """
        bit = cls._purpose_bit(purpose)
        return ((not require_current or (row["state"] == "active" and row["invalid_reason"] is None))
                and (row["retention"] == "explicit" or row["use_mask"] & bit))

    def _scope(self, access: AccessScope, scope: MemoryScope):
        self._access(access)
        if scope.user_id != access.user_id or scope.kind not in ("character", "project", "shared"):
            raise MemoryValidationError("unauthorized_scope")
        if scope.kind == "shared":
            valid = scope.character_id is None and scope.project_id is None
        elif scope.kind == "character":
            valid = scope.character_id == access.character_id and scope.project_id is None
        else:
            valid = (scope.character_id == access.character_id and scope.project_id is not None
                     and scope.project_id == access.project_id)
        if not valid:
            raise MemoryValidationError("unauthorized_scope")

    def _input(self, text, condition, kind, now_ms, source):
        if not isinstance(text, str) or not text.strip() or len(text) > self._max_text_chars:
            raise MemoryValidationError("invalid_text_length")
        if condition is not None and (not isinstance(condition, str) or len(condition) > 4096):
            raise MemoryValidationError("invalid_condition")
        if kind not in ("fact", "preference", "instruction", "event"):
            raise MemoryValidationError("invalid_kind")
        if not isinstance(now_ms, int) or isinstance(now_ms, bool) or now_ms < 0:
            raise MemoryValidationError("invalid_clock")
        self._source(source)

    @staticmethod
    def _source(source):
        _validate_source(source)

    def _key(self, operation_id, item_id):
        _identity(operation_id)
        _identity(item_id)

    @staticmethod
    def _fingerprint(data):
        return hashlib.sha256(json.dumps(data, ensure_ascii=False, sort_keys=True,
                                        separators=(",", ":")).encode("utf-8")).hexdigest()

    def _replay(self, access, operation_id, item_id, fingerprint, kind):
        row = self._db.execute("SELECT * FROM operations WHERE user_id=? AND operation_id=? AND item_id=?",
                               (access.user_id, operation_id, item_id)).fetchone()
        if row is None:
            return None
        result = self._operation_result(access, row)
        if row["operation_kind"] != kind:
            raise MemoryConflict("operation_key_reused")
        # Candidate-review fingerprints contain only IDs, version and kind;
        # unlike M1 payload fingerprints they survive erasure for exact replay.
        if kind in ("candidate_accept", "candidate_reject", "candidate_publish", "comparison_discard") and row["fingerprint"] != fingerprint:
            raise MemoryConflict("operation_key_reused")
        if row["outcome"] == "retired" or row["operation_kind"] == "forget":
            return result
        if row["fingerprint"] != fingerprint:
            raise MemoryConflict("operation_key_reused")
        return result

    def _operation_result(self, access, row):
        if row["operation_kind"] == "candidate_publish_set":
            if row["formation_task_id"] is None:
                raise MemoryNotFound("selection_receipt_scope_unavailable")
            from .maintenance import Maintenance
            Maintenance(self)._task_row(access, row["formation_task_id"])
            return OperationResult(row["outcome"], None, None, True, None, self._cleanup_pending())
        if row["candidate_id"] is not None:
            from .candidates import Candidates
            Candidates(self).detail(access, row["candidate_id"])
            if row["operation_kind"] == "candidate_reject":
                return OperationResult("rejected", None, None, True, None, self._cleanup_pending())
        # Older v1 stores recorded completed forgets as retired. The operation
        # kind distinguishes that success from a retired old write, without a
        # migration or retaining forgotten payload hashes.
        if row["operation_kind"] == "forget":
            return OperationResult("forgotten", row["memory_id"], None, True, None, self._cleanup_pending())
        if row["outcome"] == "retired":
            return OperationResult("retired", row["memory_id"], None, True, None, self._cleanup_pending())
        current = self._get(access, row["memory_id"])
        if row["operation_kind"] == "comparison_discard":
            # The method reconstructs its original post-version from the
            # fingerprint-validated request. Status alone cannot recover that
            # request from its hash and must not substitute a later version.
            return OperationResult("discarded", row["memory_id"], None, True, None, self._cleanup_pending())
        # Every write creates a new ID at version 1. This is the original write
        # receipt version; current lifecycle version comes from detail().
        return OperationResult(row["outcome"], row["memory_id"], 1, True,
                               current["index_state"], self._cleanup_pending())

    def operation_status(self, access: AccessScope, *, operation_id: str,
                         item_id: str) -> OperationResult | None:
        """Read a content-free durable outcome; None proves no committed key."""
        self._access(access)
        self._key(operation_id, item_id)
        with self._lock:
            self._check()
            row = self._db.execute("SELECT * FROM operations WHERE user_id=? AND operation_id=? AND item_id=?",
                                   (access.user_id, operation_id, item_id)).fetchone()
            return self._operation_result(access, row) if row else None

    def _record(self, access, operation_id, item_id, kind, mid, outcome, fingerprint,
                *, candidate_id=None, reviewed_at_ms=None, formation_task_id=None):
        self._db.execute("INSERT INTO operations(user_id,operation_id,item_id,operation_kind,memory_id,outcome,fingerprint,candidate_id,reviewed_at_ms,formation_task_id) VALUES(?,?,?,?,?,?,?,?,?,?)",
                         (access.user_id, operation_id, item_id, kind, mid, outcome, fingerprint, candidate_id, reviewed_at_ms, formation_task_id))

    def _change(self):
        self._db.execute("UPDATE store_state SET change_seq=change_seq+1")

    def _insert(self, scope, text, kind, condition, source, now_ms, root=None, *,
                authorization=None, use_mask=3):
        mid = str(uuid4())
        self._db.execute("INSERT INTO memories(memory_id,root_id,user_id,scope_kind,character_id,project_id,text,kind,condition_text,state,status_reason,replaced_by,row_version,created_at_ms,updated_at_ms,index_state,index_version,index_error,retention,use_mask,authorization_id,authorization_generation) VALUES(?,?,?,?,?,?,?,?,?,'active',NULL,NULL,1,?,?,'pending',NULL,NULL,?,?,?,?)",
                         (mid, root or mid, scope.user_id, scope.kind, scope.character_id,
                          scope.project_id, text, kind, condition, now_ms, now_ms,
                          "dependent" if authorization is not None else "explicit", use_mask,
                          authorization.authorization_id if authorization is not None else None,
                          authorization.generation if authorization is not None else None))
        if authorization is None:
            self._db.execute("INSERT INTO receipts VALUES(?,?)", (mid, json.dumps({"text": text, "kind": kind, "condition": condition}, ensure_ascii=False)))
        if source:
            self._db.execute("INSERT INTO origins(memory_id,namespace,record_key,revision,start_cp,end_cp) VALUES(?,?,?,?,?,?)",
                             (mid, source.namespace, source.record_key, source.revision,
                              source.start_cp, source.end_cp))
        projection = " ".join(_terms(text + ("\n" + condition if condition else "")))
        self._db.execute("INSERT INTO search_documents(memory_id,row_version,text) VALUES(?,1,?)", (mid, projection))
        self._change()
        return mid

    def remember(self, access: AccessScope, scope: MemoryScope, *, operation_id: str,
                 item_id: str, text: str, now_ms: int, kind: str = "fact",
                 condition: str | None = None, source: SourceSpan | None = None) -> OperationResult:
        self._scope(access, scope)
        self._key(operation_id, item_id)
        self._input(text, condition, kind, now_ms, source)
        fp = self._fingerprint(["remember", asdict(scope), text, kind, condition, asdict(source) if source else None])
        with self._lock:
            self._check()
            with self._transaction():
                replay = self._replay(access, operation_id, item_id, fp, "remember")
                if replay:
                    return replay
                self._check_origin(access, source)
                mid = self._insert(scope, text, kind, condition, source, now_ms)
                self._record(access, operation_id, item_id, "remember", mid, "saved", fp)
                return OperationResult("saved", mid, 1, False, "pending", self._cleanup_pending())

    def _get(self, access, mid):
        where, params = self._where(access)
        row = self._db.execute(f"SELECT m.* FROM memories m WHERE m.memory_id=? AND {where}", (mid, *params)).fetchone()
        if row is None:
            raise MemoryNotFound("memory_not_found")
        return row

    def _memory(self, row):
        origin = self._db.execute("SELECT * FROM origins WHERE memory_id=?", (row["memory_id"],)).fetchone()
        source = SourceSpan(origin["namespace"], origin["record_key"], origin["revision"], origin["start_cp"], origin["end_cp"]) if origin and origin["candidate_id"] is None else None
        return Memory(row["memory_id"], row["root_id"], MemoryScope(row["scope_kind"], row["user_id"], row["character_id"], row["project_id"]),
                      row["text"], row["kind"], row["condition_text"], row["state"], row["status_reason"], row["replaced_by"], row["row_version"],
                      row["created_at_ms"], row["updated_at_ms"], row["index_state"], source,
                      origin["candidate_id"] if origin else None, row["retention"], row["invalid_reason"],
                      tuple(p for p, bit in (("lookup", 1), ("ordinary", 2)) if row["use_mask"] & bit))

    def list_memories(self, access: AccessScope, *, limit: int = 100,
                      include_history: bool = False, scope_kind: str | None = None,
                      before: tuple[int, str] | list | None = None) -> tuple[Memory, ...]:
        self._access(access)
        if not 1 <= limit <= 1000 or scope_kind not in (None, "character", "project", "shared"):
            raise MemoryValidationError("invalid_list_options")
        where, params = self._where(access)
        if not include_history:
            where += " AND m.state='active' AND m.invalid_reason IS NULL"
        if scope_kind:
            where += " AND m.scope_kind=?"
            params += (scope_kind,)
        if before is not None:
            if (not isinstance(before, (tuple, list)) or len(before) != 2
                    or not isinstance(before[0], int) or isinstance(before[0], bool)
                    or not 0 <= before[0] <= 2**63-1
                    or not isinstance(before[1], str) or not before[1].strip()
                    or len(before[1]) > 2048):
                raise MemoryValidationError("invalid_list_cursor")
            where += " AND (m.updated_at_ms<? OR (m.updated_at_ms=? AND m.memory_id>?))"
            params += (before[0], before[0], before[1])
        with self._lock:
            self._check()
            rows = self._db.execute(f"SELECT m.* FROM memories m WHERE {where} ORDER BY m.updated_at_ms DESC,m.memory_id LIMIT ?", (*params, limit)).fetchall()
            return tuple(self._memory(row) for row in rows)

    def detail(self, access: AccessScope, memory_id: str) -> MemoryDetail:
        self._access(access)
        with self._lock:
            self._check()
            row = self._get(access, memory_id)
            where, params = self._where(access)
            history = self._db.execute(f"SELECT m.* FROM memories m WHERE m.root_id=? AND {where} ORDER BY m.created_at_ms,m.rowid", (row["root_id"], *params)).fetchall()
            return MemoryDetail(self._memory(row), tuple(self._memory(r) for r in history))

    def correct(self, access: AccessScope, target_id: str, expected_version: int, *,
                operation_id: str, item_id: str, text: str, mode: str,
                now_ms: int, condition: str | None = None,
                source: SourceSpan | None = None) -> OperationResult:
        self._access(access)
        _identity(target_id)
        if not isinstance(expected_version, int) or isinstance(expected_version, bool) or expected_version < 1:
            raise MemoryValidationError("invalid_expected_version")
        self._key(operation_id, item_id)
        self._input(text, condition, "fact", now_ms, source)
        if mode not in ("change", "error"):
            raise MemoryValidationError("invalid_correction_mode")
        fp = self._fingerprint(["correct", target_id, expected_version, text, mode, condition, asdict(source) if source else None])
        with self._lock:
            self._check()
            with self._transaction():
                replay = self._replay(access, operation_id, item_id, fp, "correct")
                if replay:
                    return replay
                old = self._get(access, target_id)
                if old["row_version"] != expected_version or old["state"] != "active":
                    raise MemoryConflict("stale_memory_version")
                self._check_origin(access, source)
                old_memory = self._memory(old)
                scope = old_memory.scope
                retired_sources = self._use_sources(access, target_id)
                if old["retention"] == "explicit":
                    retired_sources += self._retirement_origins(target_id)
                mid = self._insert(scope, text, old["kind"], condition, source, now_ms, old["root_id"])
                self._db.execute("UPDATE memories SET state=?,status_reason=?,replaced_by=?,row_version=row_version+1,updated_at_ms=? WHERE memory_id=?",
                                 ("superseded" if mode == "change" else "retracted", "preference_changed" if mode == "change" else "corrected_by_user", mid, now_ms, target_id))
                self._db.execute("DELETE FROM search_documents WHERE memory_id=?", (target_id,))
                self._db.execute("DELETE FROM embeddings WHERE memory_id=?", (target_id,))
                from .candidates import _invalidate_retirements
                _invalidate_retirements(self, access, retired_sources, reason="preference_changed" if mode == "change" else "corrected_by_user")
                self._record(access, operation_id, item_id, "correct", mid, "corrected", fp)
            clean = self.cleanup() if self._cleanup_pending() else True
            return OperationResult("corrected", mid, 1, False, "pending", not clean)

    @staticmethod
    def _overlap(a, b):
        return (all(a[k] == b[k] for k in ("namespace", "record_key", "revision"))
                and (a["start_cp"] is None or b["start_cp"] is None
                     or (a["start_cp"] < b["end_cp"] and b["start_cp"] < a["end_cp"])))

    def _forget_roots(self, access, target_id, expected_version):
        # The internal plan uses only identities, versions and persisted edges.
        # Bodies and display authorization are assembled only for public preview.
        where, params = self._where(access)
        old = self._db.execute(f"SELECT m.root_id,m.row_version FROM memories m WHERE m.memory_id=? AND {where}", (target_id, *params)).fetchone()
        if old is None:
            raise MemoryNotFound("memory_not_found")
        if old["row_version"] != expected_version:
            raise MemoryConflict("stale_memory_version")
        origins = self._db.execute("SELECT o.*,m.root_id FROM memory_sources o JOIN memories m ON m.memory_id=o.memory_id WHERE m.user_id=?", (access.user_id,)).fetchall()
        uses = self._db.execute("SELECT u.namespace,u.record_key,u.revision,NULL start_cp,NULL end_cp,m.root_id FROM recall_uses u JOIN memories m ON m.memory_id=u.memory_id WHERE u.user_id=?", (access.user_id,)).fetchall()
        by_root, by_source, outputs = defaultdict(list), defaultdict(list), defaultdict(list)
        for origin in origins:
            by_root[origin["root_id"]].append(origin)
            by_source[(origin["namespace"], origin["record_key"], origin["revision"])].append(origin)
        for output in uses:
            outputs[output["root_id"]].append(output)
        direct_root = old["root_id"]
        roots, queue, spans = {direct_root}, deque((direct_root,)), set()
        heads = []
        while queue:
            root = queue.popleft()
            row = self._db.execute("SELECT memory_id,root_id,row_version,retention FROM memories WHERE root_id=? AND state='active'", (root,)).fetchone()
            if row is None:
                raise MemoryConflict("forget_invalid_family")
            if self._db.execute(f"SELECT 1 FROM memories m WHERE m.memory_id=? AND {where}", (row["memory_id"], *params)).fetchone() is None:
                raise MemoryConflict("forget_linked_scope_unavailable")
            heads.append(row)
            # Only directly targeted or independent explicit assets contribute
            # their origins. An automatic dependent cascade follows its outputs
            # forward, without dragging other still-valid inputs backwards.
            linked = outputs[root]
            if root == direct_root or row["retention"] == "explicit":
                linked = [*by_root[root], *linked]
            linked = deque(linked)
            enqueued = {SourceSpan(r["namespace"], r["record_key"], r["revision"], r["start_cp"], r["end_cp"]) for r in linked}
            while linked:
                source = linked.popleft()
                span = SourceSpan(source["namespace"], source["record_key"], source["revision"], source["start_cp"], source["end_cp"])
                if span in spans:
                    continue
                spans.add(span)
                for output in self._direct_output_children(access.user_id, span, cross_revision=True):
                    if output not in enqueued and output not in spans:
                        enqueued.add(output)
                        linked.append(asdict(output))
                if len(spans) > _MAX_OUTPUT_GRAPH:
                    raise MemoryConflict("output_invalidation_limit")
                for origin in by_source[(span.namespace, span.record_key, span.revision)]:
                    successor = origin["root_id"]
                    if successor not in roots and self._overlap(source, origin):
                        roots.add(successor)
                        if len(roots) > 1000:
                            raise MemoryConflict("forget_linked_limit")
                        queue.append(successor)
        heads.sort(key=lambda m: m["memory_id"])
        confirmation = tuple(ForgetTarget(m["memory_id"], m["row_version"]) for m in heads if m["retention"] == "explicit" or m["root_id"] == direct_root)
        cascaded = tuple(ForgetTarget(m["memory_id"], m["row_version"]) for m in heads if m["retention"] == "dependent" and m["root_id"] != direct_root)
        return ForgetPreview(confirmation, (), self._sort_sources(spans), cascaded), roots

    def _forget_plan(self, access, target_id, expected_version, *, display=False):
        preview, roots = self._forget_roots(access, target_id, expected_version)
        from .candidates import _exclusion_impact
        impacted_memories, impacted_outputs = _exclusion_impact(self, access, preview.source_exclusions)
        memories, invalidated_memories, invalidated_outputs = (), [], []
        if display:
            memories = tuple(self._memory(self._get(access, t.memory_id)) for t in sorted((*preview.targets, *preview.dependent_targets), key=lambda t: t.memory_id))
            for mid in impacted_memories:
                try:
                    row = self._get(access, mid)
                except MemoryNotFound:
                    continue
                if row["root_id"] not in roots and row["state"] == "active" and row["invalid_reason"] is None:
                    invalidated_memories.append(self._memory(row))
            for output in impacted_outputs:
                try:
                    # Existing authoritative eligibility/scope validation. Host
                    # projection identity and text display policy still apply.
                    self._output_dependencies(access, (output,), None)
                except (MemoryConflict, MemoryNotFound, MemoryValidationError):
                    continue
                invalidated_outputs.append(output)
        preview = replace(preview, memories=memories, invalidated_memories=tuple(invalidated_memories),
                          invalidated_outputs=tuple(invalidated_outputs))
        return preview, roots, impacted_memories, impacted_outputs

    def preview_forget(self, access: AccessScope, target_id: str, expected_version: int) -> ForgetPreview:
        self._access(access)
        _identity(target_id)
        if not isinstance(expected_version, int) or isinstance(expected_version, bool) or expected_version < 1:
            raise MemoryValidationError("invalid_expected_version")
        with self._lock:
            self._check()
            return self._forget_plan(access, target_id, expected_version, display=True)[0]

    @staticmethod
    def _confirm_forget(preview, confirmed_targets):
        if confirmed_targets is None:
            if len(preview.targets) > 1:
                raise MemoryConflict("forget_confirmation_required")
            return
        if any(not isinstance(t, ForgetTarget) or not isinstance(t.row_version, int) or isinstance(t.row_version, bool) or t.row_version < 1 for t in confirmed_targets):
            raise MemoryValidationError("invalid_forget_targets")
        supplied = {(t.memory_id, t.row_version) for t in confirmed_targets}
        required = {(t.memory_id, t.row_version) for t in preview.targets}
        if supplied != required or len(supplied) != len(confirmed_targets):
            raise MemoryConflict("forget_preview_stale")

    def prepare_mutation(self, access: AccessScope, target_id: str, expected_version: int,
                         *, operation_id: str, item_id: str, kind: str,
                         confirmed_targets: Sequence[ForgetTarget] | None = None) -> MutationPreview:
        """Read exact source coordinates before a Host write-ahead publication.

        This is not a reservation: the mutator rechecks versions/overlaps in its
        transaction. The Host durably masks these coordinates before calling it.
        """
        self._access(access)
        _identity(target_id)
        self._key(operation_id, item_id)
        if kind not in ("correct", "forget") or not isinstance(expected_version, int) or isinstance(expected_version, bool) or expected_version < 1:
            raise MemoryValidationError("invalid_mutation_options")
        with self._lock:
            self._check()
            operation = self._db.execute("SELECT * FROM operations WHERE user_id=? AND operation_id=? AND item_id=?",
                                         (access.user_id, operation_id, item_id)).fetchone()
            if operation:
                result = self._operation_result(access, operation)
                if operation["operation_kind"] != kind:
                    raise MemoryConflict("operation_key_reused")
                return MutationPreview((), replay=result)
            if kind == "forget":
                preview, _, impacted_memories, impacted_outputs = self._forget_plan(access, target_id, expected_version)
                self._confirm_forget(preview, confirmed_targets)
                return MutationPreview(self._sort_sources((*preview.source_exclusions, *impacted_outputs)),
                    tuple(sorted({*(t.memory_id for t in (*preview.targets, *preview.dependent_targets)), *impacted_memories})))
            old = self._get(access, target_id)
            if old["row_version"] != expected_version or old["state"] != "active":
                raise MemoryConflict("stale_memory_version")
            spans = set(self._use_sources(access, target_id))
            if old["retention"] == "explicit":
                spans.update(self._retirement_origins(target_id))
            return MutationPreview(self._output_descendants(access.user_id, spans), (target_id,))

    def forget(self, access: AccessScope, target_id: str, expected_version: int, *,
               operation_id: str, item_id: str, now_ms: int,
               confirmed_targets: Sequence[ForgetTarget] | None = None) -> OperationResult:
        self._access(access)
        _identity(target_id)
        if not isinstance(expected_version, int) or isinstance(expected_version, bool) or expected_version < 1:
            raise MemoryValidationError("invalid_expected_version")
        self._key(operation_id, item_id)
        if not isinstance(now_ms, int) or isinstance(now_ms, bool) or now_ms < 0:
            raise MemoryValidationError("invalid_clock")
        with self._lock:
            self._check()
            with self._transaction():
                replay = self._replay(access, operation_id, item_id, None, "forget")
                if replay:
                    return replay
                preview, roots = self._forget_roots(access, target_id, expected_version)
                self._confirm_forget(preview, confirmed_targets)
                placeholders = ",".join("?" for _ in roots)
                family = self._db.execute(f"SELECT memory_id FROM memories WHERE root_id IN ({placeholders})", tuple(roots)).fetchall()
                for source in preview.source_exclusions:
                    self._db.execute("INSERT INTO exclusions(user_id,namespace,record_key,revision,start_cp,end_cp) VALUES(?,?,?,?,?,?)", (access.user_id, source.namespace, source.record_key, source.revision, source.start_cp, source.end_cp))
                from .candidates import _invalidate_exclusions
                _invalidate_exclusions(self, access, preview.source_exclusions, permanent=True)
                for member in family:
                    mid = member[0]
                    self._db.execute("INSERT OR IGNORE INTO forgotten VALUES(?,?)", (mid, access.user_id))
                    self._db.execute("UPDATE operations SET outcome='retired',fingerprint=CASE WHEN operation_kind IN ('candidate_accept','candidate_publish','comparison_discard') THEN fingerprint ELSE NULL END WHERE user_id=? AND memory_id=?", (access.user_id, mid))
                self._db.execute(f"DELETE FROM memories WHERE root_id IN ({placeholders})", tuple(roots))
                self._record(access, operation_id, item_id, "forget", target_id, "forgotten", None)
                self._db.execute("UPDATE store_state SET cleanup_pending=1")
                self._change()
            # Cleanup is attempted only after the durable logical forget commit.
            clean = self.cleanup()
            return OperationResult("forgotten", target_id, None, False, None, not clean)

    def _check_origin(self, access, source):
        if source is None:
            return
        rows = self._db.execute("SELECT * FROM exclusions WHERE user_id=? AND namespace=? AND record_key=?", (access.user_id, source.namespace, source.record_key)).fetchall()
        for row in rows:
            # Different revisions need Host-authorised position mapping; don't
            # blindly reuse old coordinates on a new canonical source revision.
            if row["revision"] != source.revision or row["start_cp"] is None or source.start_cp is None or (source.start_cp < row["end_cp"] and source.end_cp > row["start_cp"]):
                raise MemoryValidationError("excluded_source")

    def source_exclusions(self, access: AccessScope) -> tuple[SourceSpan, ...]:
        self._access(access)
        with self._lock:
            self._check()
            from .policy import _exclusions
            return _exclusions(self._db, access.user_id)

    def source_retirements(self, access: AccessScope) -> tuple[SourceRetirement, ...]:
        """Derived coordinates of obsolete assertions for ordinary Host history.

        These are reversible lifecycle projections, not forget rules. They carry
        no old statement and apply across the user's character/project switches.
        """
        self._access(access)
        with self._lock:
            self._check()
            return self._source_retirements(access.user_id)

    def _source_retirements(self, user_id):
        # Internal callers obtain this owner from an authoritative task scope.
        from .policy import _retirements
        return _retirements(self._db, user_id)

    def source_policy(self, access: AccessScope) -> SourcePolicySnapshot:
        """One owner-lock snapshot for the Host's content-free policy projection."""
        self._access(access)
        with self._lock:
            self._check()
            from .policy import _snapshot
            return _snapshot(self._db, access.user_id)

    def registered_output_sources(self, access: AccessScope) -> tuple[SourceSpan, ...]:
        """Complete user-owned output catalog for Host startup/recovery only.

        Includes legacy Memory-only uses and unified-read-set output headers,
        whether current or invalidated. Coordinates classify dependency-bearing
        history; they grant no permission and carry no memory/source bodies.
        Routine turns and mutations use their specific read sets instead.
        """
        self._access(access)
        with self._lock:
            self._check()
            from .policy import _outputs
            return _outputs(self._db, access.user_id)

    def _cleanup_pending(self):
        return bool(self._db.execute("SELECT cleanup_pending FROM store_state").fetchone()[0])

    def cleanup(self) -> bool:
        """Clean managed SQLite free pages/FTS/WAL; report busy recovery honestly.

        This does not claim erasure of filesystem snapshots, backups, external
        model requests or unmanaged copies. Never run a parallel checkpoint.
        """
        with self._lock:
            self._check()
            if not self._cleanup_pending():
                return True
            # A WAL reader cannot invalidate the already-committed forget.
            # Report pending instead of holding the Store for its busy timeout.
            busy_ms = self._db.execute("PRAGMA busy_timeout").fetchone()[0]
            try:
                self._db.execute("PRAGMA busy_timeout=0")
                self._db.execute("INSERT INTO memory_fts(memory_fts) VALUES('optimize')")
                self._db.execute("INSERT INTO retrieval_fts(retrieval_fts) VALUES('optimize')")
                checkpoint = self._db.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
                if checkpoint[0]:
                    return False
                # This content-free marker update may leave a tiny WAL; truncate
                # again, and retain pending if an external reader blocks it.
                self._db.execute("UPDATE store_state SET cleanup_pending=0")
                if self._db.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()[0]:
                    self._db.execute("UPDATE store_state SET cleanup_pending=1")
                    return False
                return True
            except sqlite3.DatabaseError:
                return False
            finally:
                self._db.execute(f"PRAGMA busy_timeout={busy_ms}")

    def status(self, access: AccessScope, *, purpose: str = "ordinary") -> StoreStatus:
        self._access(access)
        with self._lock:
            self._check()
            where, params = self._where(access)
            where += " AND " + self._eligibility(purpose)
            rows = self._db.execute(f"SELECT m.index_state,m.index_version,count(*) n FROM memories m WHERE {where} AND m.state='active' AND m.invalid_reason IS NULL GROUP BY m.index_state,m.index_version", params).fetchall()
            total = sum(row["n"] for row in rows)
            indexed = sum(row["n"] for row in rows if row["index_state"] == "ready" and self._embedder and row["index_version"] == self._embedder.version)
            failed = sum(row["n"] for row in rows if row["index_state"] == "failed")
            pending = total-indexed-failed
            semantic = "unavailable" if self._embedder is None else ("partial" if indexed < total else "ready")
            state = self._db.execute("SELECT * FROM store_state").fetchone()
            return StoreStatus(total, indexed, pending, failed, semantic, self._embedder.version if self._embedder else None, bool(state["cleanup_pending"]), state["change_seq"])

    def index_settlement(self):
        """Current native index settlement, or None if release already won.

        The handle conveys no result or execution authority. All acquisitions,
        including close, use the same primitive; observers cannot cancel it.
        """
        return self._index_lock.settlement()

    def run_index_batch(self, *, limit: int = 8, max_chunks: int = 128,
                        retry_failed: bool = False, access: AccessScope | None = None,
                        references: Sequence[RecallReference] | None = None) -> IndexResult:
        if not 1 <= limit <= 100 or not 1 <= max_chunks <= 4096:
            raise MemoryValidationError("invalid_index_limits")
        if references is not None:
            self._access(access)
            references = tuple(references)
            if len(references) > 1000 or any(not isinstance(ref, RecallReference) for ref in references):
                raise MemoryValidationError("invalid_index_references")
            for ref in references:
                _identity(ref.memory_id)
                if not isinstance(ref.row_version, int) or isinstance(ref.row_version, bool) or ref.row_version < 1:
                    raise MemoryValidationError("invalid_index_references")
        if not self._index_lock.acquire(blocking=False):
            return IndexResult(0, 0, 0, 0, True)
        try:
            with self._lock:
                self._check()
                embedder = self._embedder
                if embedder is None:
                    return IndexResult(0, 0, 0, 0)
                states = "('pending','failed')" if retry_failed else "('pending')"
                if references is None:
                    rows = self._db.execute(f"SELECT * FROM memories WHERE state='active' AND invalid_reason IS NULL AND index_state IN {states} ORDER BY created_at_ms,memory_id LIMIT ?", (limit,)).fetchall()
                else:
                    rows = []
                    for ref in dict.fromkeys(references):
                        try:
                            row = self._get(access, ref.memory_id)
                        except MemoryNotFound:
                            continue
                        if row["row_version"] == ref.row_version and row["state"] == "active" and row["invalid_reason"] is None and row["index_state"] in (("pending", "failed") if retry_failed else ("pending",)):
                            rows.append(row)
                    rows = sorted(rows, key=lambda row: (row["created_at_ms"], row["memory_id"]))[:limit]
            indexed = failed = stale = 0
            chunks_used = 0
            attempted = 0
            for row in rows:
                attempted += 1
                text = row["text"] + ("\n" + row["condition_text"] if row["condition_text"] else "")
                try:
                    with self._embedding_lock:
                        if self._embedder is not embedder:
                            return IndexResult(attempted, indexed, failed, stale + 1)
                        chunks = list(embedder.split_passage(text))
                    if not chunks or any(not isinstance(c, str) or not c for c in chunks) or "".join(chunks) != text:
                        raise ValueError("incomplete_chunks")
                    if len(chunks) > max_chunks-chunks_used:
                        # A too-large first item is explicitly failed; a later
                        # item stays pending for the next bounded invocation.
                        if chunks_used:
                            attempted -= 1
                            break
                        raise ValueError("chunk_budget_exceeded")
                    chunks_used += len(chunks)
                    vectors = []
                    for chunk in chunks:
                        with self._embedding_lock:
                            if self._embedder is not embedder:
                                return IndexResult(attempted, indexed, failed, stale + 1)
                            with self._lock:
                                if not self._db.execute("SELECT 1 FROM memories WHERE memory_id=? AND row_version=? AND state='active' AND invalid_reason IS NULL", (row["memory_id"], row["row_version"])).fetchone():
                                    break
                            unit = list(embedder.embed_passages([chunk]))
                            if len(unit) != 1:
                                raise ValueError("invalid_embedding_count")
                            vectors.append(normalized(unit[0], embedder.dimensions))
                except Exception:
                    # Provider messages can contain inputs; persist a code only.
                    with self._lock, self._transaction():
                        changed = 0 if self._embedder is not embedder else self._db.execute("UPDATE memories SET index_state='failed',index_error='embedding_failed' WHERE memory_id=? AND row_version=? AND state='active' AND invalid_reason IS NULL", (row["memory_id"], row["row_version"])).rowcount
                        failed += changed
                        stale += not changed
                    continue
                with self._lock, self._transaction():
                    current = self._db.execute("SELECT * FROM memories WHERE memory_id=? AND row_version=? AND state='active' AND invalid_reason IS NULL", (row["memory_id"], row["row_version"])).fetchone()
                    if current is None or self._embedder is not embedder:
                        stale += 1
                        continue
                    # Scope is immutable in M1; checking all authority-bearing
                    # dimensions prevents a future migration bypassing this gate.
                    if any(current[k] != row[k] for k in ("user_id", "scope_kind", "character_id", "project_id")):
                        stale += 1
                        continue
                    self._db.execute("DELETE FROM embeddings WHERE memory_id=?", (row["memory_id"],))
                    for number, vector in enumerate(vectors):
                        self._db.execute("INSERT INTO embeddings VALUES(?,?,?,?,?,?)", (row["memory_id"], row["row_version"], embedder.version, number, embedder.dimensions, struct.pack(f"<{len(vector)}f", *vector)))
                    self._db.execute("UPDATE memories SET index_state='ready',index_version=?,index_error=NULL WHERE memory_id=?", (embedder.version, row["memory_id"]))
                    indexed += 1
            return IndexResult(attempted, indexed, failed, stale)
        finally:
            self._index_lock.release()

    def prepare_lookup_query(self, query: str, *, recent_context: Sequence[str] = ()) -> LookupQuery:
        """Pin a query and current embedding model without encoding it yet."""
        if (not isinstance(query, str) or len(query) > self._max_text_chars
                or not isinstance(recent_context, (list, tuple)) or len(recent_context) > 100
                or any(not isinstance(value, str) for value in recent_context)
                or sum(map(len, recent_context)) > _MAX_RECALL_CHARS):
            raise MemoryValidationError("invalid_lookup_query")
        with self._lock:
            self._check()
            return LookupQuery(self, query, tuple(recent_context))

    def recall(self, access: AccessScope, query: str, *, now_ms: int,
               limit: int = 8, max_chars: int = 4096,
               recent_context: Sequence[str] = (),
               minimum_semantic_score: float | None = None,
               ranking: str = "hybrid", purpose: str = "ordinary",
               lookup_query: LookupQuery | None = None, max_vectors: int | None = None,
               explicit_notes_only: bool = False,
               reference_filter: Callable[[RecallReference], bool] | None = None) -> RecallResult:
        """Recall current notes, with an optional read-only plan filter.

        The trusted filter runs before the result quotas and grants no access,
        availability or delivery authority. It must not mutate the Store.
        """
        self._access(access)
        if (not isinstance(query, str) or len(query) > self._max_text_chars
                or not 1 <= limit <= 100 or not 0 <= max_chars <= _MAX_RECALL_CHARS
                or ranking not in ("hybrid", "semantic_first")
                or type(explicit_notes_only) is not bool
                or (reference_filter is not None and not callable(reference_filter))
                or (max_vectors is not None and (type(max_vectors) is not int or not 0 <= max_vectors <= 1_000_000))
                or (minimum_semantic_score is not None
                    and (isinstance(minimum_semantic_score, bool)
                         or not isinstance(minimum_semantic_score, (int, float))
                         or not -1 <= minimum_semantic_score <= 1))):
            raise MemoryValidationError("invalid_recall_options")
        _check_lookup_query(lookup_query, self, query, recent_context)
        candidate_limit = max(20, limit * 4)
        where, params = self._where(access)
        where += " AND " + self._eligibility(purpose)
        if explicit_notes_only:
            where += " AND m.retention='explicit' AND NOT EXISTS (SELECT 1 FROM origins o WHERE o.memory_id=m.memory_id AND o.candidate_id IS NOT NULL)"
        if reference_filter is not None:
            # A dependent entry nominates whole necessary originals. Apply the
            # existing source lookup necessary condition before the unchanged
            # lexical/vector shortlist. The exact SDK plan below still checks
            # formation snapshots, origins and output ancestry; this is no new
            # grant and explicit saved bodies remain independent.
            from .maintenance import Maintenance
            source_where, source_params = self._where(access, "s")
            where += (" AND (m.retention='explicit' OR ("
                "EXISTS (SELECT 1 FROM memory_sources v WHERE v.memory_id=m.memory_id) AND "
                "NOT EXISTS (SELECT 1 FROM memory_sources v WHERE v.memory_id=m.memory_id AND NOT EXISTS ("
                "SELECT 1 FROM source_states q JOIN source_streams s ON s.stream_id=q.stream_id WHERE "
                + source_where + " AND q.namespace=v.namespace AND q.record_key=v.record_key "
                "AND q.revision=v.revision AND " + Maintenance._lookup_eligibility() + "))))")
            params = (*params, *source_params)
        ranks: dict[str, float] = {}
        lexical_ids = set()
        semantic_scores: dict[str, float] = {}
        with self._lock:
            self._check()
            terms = list(dict.fromkeys(_terms(query, query=True)))[:64]
            if terms:
                match = " OR ".join('"' + t.replace('"', '""') + '"' for t in terms)
                lexical = self._db.execute(f"SELECT m.memory_id FROM memory_fts JOIN search_documents d ON d.document_id=memory_fts.rowid JOIN memories m ON m.memory_id=d.memory_id WHERE memory_fts MATCH ? AND {where} AND m.state='active' AND m.invalid_reason IS NULL AND m.row_version=d.row_version ORDER BY bm25(memory_fts),m.memory_id LIMIT ?", (match, *params, candidate_limit)).fetchall()
                for rank, row in enumerate(lexical, 1):
                    ranks[row[0]] = 1 / (60 + rank)
                    lexical_ids.add(row[0])
        semantic_error = None
        scanned = 0
        scan_limited = False
        # The bounded mixed caller shares a lazily encoded query across both
        # native indices. Empty vector corpora need no model work.
        semantic_available = self._embedder is not None
        if semantic_available and max_vectors is not None:
            with self._lock:
                semantic_available = bool(max_vectors and self._db.execute(
                    f"SELECT 1 FROM embeddings e JOIN memories m ON m.memory_id=e.memory_id WHERE {where} AND e.row_version=m.row_version AND e.embedding_version=? AND e.dimensions=? LIMIT 1",
                    (*params, self._embedder.version, self._embedder.dimensions)).fetchone())
        if semantic_available:
            if not self._embedding_lock.acquire(query=True, timeout=.25):
                semantic_error = "busy"
            else:
                try:
                    embedder = self._embedder
                    if embedder is None:
                        raise ValueError("embedder_changed")
                    raw = (_embed_query(embedder, query, recent_context) if lookup_query is None
                           else lookup_query._vector_for(embedder))
                    query_vector = normalized(raw, embedder.dimensions)
                except Exception:
                    semantic_error = "failed"
                finally:
                    self._embedding_lock.release()
            if semantic_error is None:
                try:
                    best: dict[str, float] = {}
                    deadline = None if self._scan_timeout_ms is None else time.monotonic() + self._scan_timeout_ms / 1000
                    with self._lock:
                        self._check()
                        # Order only metadata; fetching vector payloads in that
                        # order keeps the scoped sort from copying large BLOBs.
                        sql = f"SELECT e.rowid AS vector_row,e.memory_id,e.dimensions FROM embeddings e JOIN memories m ON m.memory_id=e.memory_id WHERE {where} AND m.state='active' AND m.invalid_reason IS NULL AND e.row_version=m.row_version AND e.embedding_version=? ORDER BY e.memory_id,e.chunk_no"
                        args = (*params, embedder.version)
                        if max_vectors is not None:
                            sql += " LIMIT ?"
                            args += (max_vectors + 1,)
                        cursor = self._db.execute(sql, args)
                        while batch := cursor.fetchmany(256):
                            if max_vectors is not None and scanned + len(batch) > max_vectors:
                                scan_limited = True
                                batch = batch[:max_vectors - scanned]
                            if not batch:
                                break
                            if deadline is not None and time.monotonic() >= deadline:
                                scan_limited = True
                                break
                            valid = [row for row in batch if row["dimensions"] == embedder.dimensions]
                            if valid:
                                marks = ",".join("?" for _ in valid)
                                vectors = dict(self._db.execute(f"SELECT rowid,vector FROM embeddings WHERE rowid IN ({marks})",
                                    tuple(row["vector_row"] for row in valid)))
                            if deadline is not None and time.monotonic() >= deadline:
                                scan_limited = True
                                break
                            scanned += len(batch)
                            if valid:
                                matrix = np.stack([np.frombuffer(vectors[row["vector_row"]], dtype="<f4") for row in valid])
                                scores = matrix @ np.asarray(query_vector, dtype=np.float32)
                                for row, raw_score in zip(valid, scores):
                                    score = float(raw_score)
                                    if self._semantic_threshold is None or score >= self._semantic_threshold:
                                        best[row["memory_id"]] = max(score, best.get(row["memory_id"], -2))
                                best = dict(heapq.nlargest(candidate_limit, best.items(), key=lambda item: (item[1], item[0])))
                    # Retain only top candidates after scoped exact calculation.
                    semantic_scores = best
                    for rank, (mid, _) in enumerate(heapq.nlargest(candidate_limit, best.items(), key=lambda item: (item[1], item[0])), 1):
                        ranks[mid] = ranks.get(mid, 0) + 1 / (60 + rank)
                except Exception:
                    semantic_error = "failed"
        with self._lock:
            self._check()
            candidates = []
            if ranking == "semantic_first":
                ordered_ids = sorted(semantic_scores, key=lambda mid: (-semantic_scores[mid], mid))
                ordered_ids += sorted(lexical_ids - semantic_scores.keys(), key=lambda mid: (-ranks[mid], mid))
            else:
                ordered_ids = sorted(ranks, key=lambda mid: (-ranks[mid], mid))
            for mid in ordered_ids:
                # Automatic admission precedes final item/payload budgets.
                # Otherwise below-floor lexical+RRF hits could consume the
                # whole budget before a relevant semantic-only candidate.
                cosine = semantic_scores.get(mid)
                if minimum_semantic_score is not None and (cosine is None or cosine < minimum_semantic_score):
                    continue
                try:
                    row = self._get(access, mid)
                except MemoryNotFound:
                    continue
                if self._eligible_row(row, purpose):
                    # Trusted composition may require evidence-deliverable
                    # references. Use its existing SDK authority before final
                    # item/character quotas, without widening the ranked pool.
                    if (reference_filter is not None and reference_filter(
                            RecallReference(mid, row["row_version"])) is not True):
                        continue
                    m = self._memory(row)
                    candidates.append(RecallCandidate(m.memory_id, m.row_version, m.text, m.kind, m.condition, m.scope, m.source, ranks[mid], cosine, mid in lexical_ids, m.retention))
            result = self.revalidate(access, candidates, now_ms=now_ms, max_chars=max_chars, limit=limit, purpose=purpose)
            coverage = replace(result.coverage, semantic=semantic_error or result.coverage.semantic,
                               scanned_vectors=scanned, scan_limited=scan_limited,
                               semantic_threshold=self._semantic_threshold)
            if scan_limited and coverage.semantic == "ready":
                coverage = replace(coverage, semantic="partial")
            return replace(result, coverage=coverage)

    @staticmethod
    def _sort_sources(sources):
        return tuple(sorted(set(sources), key=lambda s: (s.namespace, s.record_key, s.revision,
                            s.start_cp if s.start_cp is not None else -1,
                            s.end_cp if s.end_cp is not None else -1)))

    def _use_sources(self, access, memory_id):
        return self._output_descendants(access.user_id, self._memory_use_sources(access, memory_id))

    def _memory_use_sources(self, access, memory_id):
        rows = self._db.execute("SELECT namespace,record_key,revision FROM recall_uses WHERE user_id=? AND memory_id=?", (access.user_id, memory_id)).fetchall()
        return tuple(SourceSpan(*row) for row in rows)

    def _candidate_use_sources(self, access, candidate_id, row_version):
        return tuple(SourceSpan(*row) for row in self._db.execute(
            "SELECT namespace,record_key,revision FROM output_candidate_reads WHERE user_id=? AND candidate_id=? AND row_version=?",
            (access.user_id, candidate_id, row_version)))

    def _raw_reader_outputs(self, user_id, source, *, cross_revision=False):
        sql = "SELECT namespace,record_key,revision FROM output_source_reads WHERE user_id=? AND source_namespace=? AND source_record_key=?"
        args = (user_id, source.namespace, source.record_key)
        if not cross_revision:
            sql += " AND source_revision=?"
            args += (source.revision,)
        return tuple(SourceSpan(*r) for r in self._db.execute(sql, args))

    def _direct_output_children(self, user_id, source, *, cross_revision=False):
        sql = "SELECT namespace,record_key,revision FROM output_parent_reads WHERE user_id=? AND parent_namespace=? AND parent_record_key=?"
        args = user_id, source.namespace, source.record_key
        if not cross_revision:
            sql += " AND parent_revision=?"
            args += (source.revision,)
        rows = tuple(SourceSpan(*r) for r in self._db.execute(sql, args))
        siblings = ()
        if cross_revision:
            # Permanent exclusion is the no-position-mapping contract:
            # another revision of the same canonical identity is not an escape.
            siblings = tuple(SourceSpan(*r) for r in self._db.execute("SELECT namespace,record_key,revision FROM output_bindings WHERE user_id=? AND namespace=? AND record_key=? UNION SELECT namespace,record_key,revision FROM recall_uses WHERE user_id=? AND namespace=? AND record_key=?", (*args, *args)))
        return self._sort_sources((*self._raw_reader_outputs(user_id, source, cross_revision=cross_revision), *rows, *siblings))

    def _output_descendants(self, user_id, sources):
        queue, found = deque(dict.fromkeys(sources)), set()
        queued = set(queue)
        while queue:
            source = queue.popleft()
            if source in found:
                continue
            found.add(source)
            if len(found) > _MAX_OUTPUT_GRAPH:
                raise MemoryConflict("output_invalidation_limit")
            for child in self._direct_output_children(user_id, source):
                if child not in queued:
                    queued.add(child)
                    if len(queued) > _MAX_OUTPUT_GRAPH:
                        raise MemoryConflict("output_invalidation_limit")
                    queue.append(child)
        return self._sort_sources(found)

    def _origin_sources(self, memory_id):
        return tuple(SourceSpan(*row) for row in self._db.execute(
            "SELECT namespace,record_key,revision,start_cp,end_cp FROM memory_sources WHERE memory_id=?", (memory_id,)))

    def _retirement_origins(self, memory_id):
        return tuple(SourceSpan(*row) for row in self._db.execute(
            "SELECT namespace,record_key,revision,start_cp,end_cp FROM memory_retirement_sources WHERE memory_id=?", (memory_id,)))

    @staticmethod
    def _scope_contains(parent, child):
        if parent["user_id"] != child.user_id:
            return False
        if parent["scope_kind"] == "shared":
            return True
        if child.kind == "shared" or parent["character_id"] != child.character_id:
            return False
        return (parent["scope_kind"] == "character"
                or (child.kind == "project" and parent["project_id"] == child.project_id))

    def _validate_recall_references(self, access, references, purpose, *, derived_scope=None, require_current=True):
        if access is None:
            # Global maintenance has no fabricated Host identity. Its existing
            # source/task scope supplies the owner and containment boundary.
            if derived_scope is None:
                raise MemoryValidationError("missing_internal_scope")
            where, params = "m.user_id=?", (derived_scope.user_id,)
        else:
            where, params = self._where(access)
        for mid, version in references.items():
            row = self._db.execute(f"SELECT m.row_version,m.state,m.invalid_reason,m.retention,m.use_mask,m.user_id,m.scope_kind,m.character_id,m.project_id FROM memories m WHERE m.memory_id=? AND {where}", (mid, *params)).fetchone()
            if row is None:
                raise MemoryConflict("stale_memory_version")
            if require_current and (row["state"] != "active" or row["invalid_reason"] is not None or row["row_version"] != version):
                raise MemoryConflict("stale_memory_version")
            if purpose is not None and not self._eligible_row(row, purpose, require_current=require_current):
                raise MemoryConflict("stale_memory_version")
            if derived_scope is not None and not self._scope_contains(row, derived_scope):
                raise MemoryConflict("derived_output_scope_expansion")

    def recall_use_dependencies(self, access: AccessScope, sources: Sequence[SourceSpan], *,
                                now_ms: int, purpose: str = "ordinary") -> tuple[RecallReference, ...]:
        """Resolve known projected output uses without reading memory bodies.

        Partial source spans are allowed; any surviving part of a known whole
        output inherits its dependencies. Unknown sources contribute nothing.
        The Host still checks its actual projected-history policy and context.
        """
        self._access(access)
        self._purpose_bit(purpose)
        if not isinstance(now_ms, int) or isinstance(now_ms, bool) or now_ms < 0:
            raise MemoryValidationError("invalid_clock")
        sources = tuple(sources)
        for source in sources:
            if source is None:
                raise MemoryValidationError("invalid_source")
            self._source(source)
        with self._lock:
            self._check()
            reads = self._output_dependencies(access, sources, None)
            if reads.sources or reads.candidates:
                raise MemoryConflict("unified_read_set_required")
            self._validate_recall_references(access, {r.memory_id: r.row_version for r in reads.memories}, purpose)
            return reads.memories

    def filter_recall_use_dependencies(self, access: AccessScope, sources: Sequence[SourceSpan], *,
                                       now_ms: int, purpose: str = "ordinary") -> tuple[tuple[SourceSpan, tuple[RecallReference, ...]], ...]:
        """Select complete known output versions in one authoritative read window.

        Each returned pair is the delivered output and its complete memory-only
        ancestry. A rejected member never contributes dependencies to another
        member. Unknown versions are not evidence of independent history.
        Raw-source/candidate bodies retain the unified-read-set boundary.
        The strict recall_use_dependencies API remains unchanged.
        """
        return tuple((source, reads.memories) for source, reads in self.filter_output_read_sets(
            access, sources, now_ms=now_ms, purpose=purpose))

    def filter_output_read_sets(
        self, access: AccessScope, sources: Sequence[SourceSpan], *, now_ms: int, purpose: str = "ordinary",
    ) -> tuple[tuple[SourceSpan, OutputReadSet], ...]:
        """Return current, known output revisions with memory-only ancestry.

        Each output is checked independently. A missing, invalid or raw-source
        dependent output contributes no evidence to this history filter.
        """
        self._access(access)
        self._purpose_bit(purpose)
        if not isinstance(now_ms, int) or isinstance(now_ms, bool) or now_ms < 0:
            raise MemoryValidationError("invalid_clock")
        from .evidence import MAX_READ_REFERENCES
        sources = tuple(sources)
        if len(sources) > MAX_READ_REFERENCES:
            raise MemoryValidationError("read_set_limit")
        for source in sources:
            self._source(source)
            if source is None or source.start_cp is not None:
                raise MemoryValidationError("recall_use_requires_whole_source")
        sources = tuple(dict.fromkeys(sources))
        with self._lock:
            self._check()
            # Reuse an existing owner transaction, including write callers.
            # Otherwise BEGIN pins all member checks to one SQLite snapshot;
            # an RLock alone cannot exclude another connection's commits.
            owns_snapshot = not self._db.in_transaction
            if owns_snapshot:
                self._db.execute("BEGIN")
            try:
                snapshot = {"origins": set(), "outputs": {}, "notes": set()}
                accepted = []
                for source in sources:
                    if not self._known_output(access.user_id, source):
                        continue
                    try:
                        reads = self._output_dependencies(
                            access, (source,), purpose, snapshot=snapshot)
                        if not reads.memories or reads.sources or reads.candidates:
                            continue
                    except (MemoryConflict, MemoryNotFound):
                        continue
                    accepted.append((source, reads))
                if owns_snapshot:
                    self._db.execute("COMMIT")
                return tuple(accepted)
            except BaseException:
                if owns_snapshot:
                    self._db.execute("ROLLBACK")
                raise

    def _known_output(self, user_id, source):
        args = (user_id, source.namespace, source.record_key, source.revision)
        return (self._db.execute("SELECT 1 FROM output_bindings WHERE user_id=? AND namespace=? AND record_key=? AND revision=?", args).fetchone()
                or self._db.execute("SELECT 1 FROM recall_uses WHERE user_id=? AND namespace=? AND record_key=? AND revision=? LIMIT 1", args).fetchone()) is not None

    def _output_revision_floor(self, user_id, source):
        """Trusted source-owner integration: occupied identity floor, no reads.

        Includes legacy bindings. This scalar is not proof of publication or
        permission, and never releases an invalidated/unpublished identity.
        """
        args = (user_id, source.namespace, source.record_key)
        with self._lock:
            self._check()
            return self._db.execute(
                "SELECT MAX(revision) FROM (SELECT revision FROM output_bindings "
                "WHERE user_id=? AND namespace=? AND record_key=? UNION ALL "
                "SELECT revision FROM recall_uses WHERE user_id=? AND namespace=? AND record_key=?)",
                (*args, *args)).fetchone()[0] or 0

    def resolve_output_ancestry(
        self, access: AccessScope, outputs: Sequence[SourceSpan], *, purpose: str | None = "lookup",
        candidates: Sequence[CandidateReference] = (),
    ) -> OutputAncestry:
        """Resolve stored authority and the exact output revisions to recheck.

        `purpose=None` checks lineage without granting an output new uses.
        Callers still validate any Host-side sources against their snapshots.
        """
        from .evidence import OutputAncestry, OutputReadSet, _read_set

        self._access(access)
        if purpose is not None:
            self._purpose_bit(purpose)
        inputs = _read_set(OutputReadSet(outputs=tuple(outputs), candidates=tuple(candidates)))
        current = set()
        with self._lock:
            self._check()
            reads = self._output_dependencies(
                access, inputs.outputs, purpose, candidates=inputs.candidates, current_outputs=current)
        return OutputAncestry(reads, self._sort_sources(current))

    def output_read_set(self, access: AccessScope, source: SourceSpan, *,
                        purpose: str = "lookup") -> OutputReadSet:
        """Inspect the sealed direct reads for one authorized output revision."""
        self._source(source)
        if source is None or source.start_cp is not None:
            raise MemoryValidationError("recall_use_requires_whole_source")
        self._purpose_bit(purpose)
        with self._lock:
            ancestry = self.resolve_output_ancestry(access, (source,), purpose=purpose)
            if source not in ancestry.current_outputs:
                raise MemoryNotFound("output_use_not_found")
            return self._output_direct_reads(access.user_id, source)

    def _output_direct_reads(self, user_id, source):
        from .evidence import OutputReadSet
        from .maintenance import SourceInput
        from .candidates import CandidateReference
        args = (user_id, source.namespace, source.record_key, source.revision)
        memories = tuple(RecallReference(*r) for r in self._db.execute("SELECT memory_id,row_version FROM recall_uses WHERE user_id=? AND namespace=? AND record_key=? AND revision=? ORDER BY memory_id", args))
        sources = tuple(SourceInput(SourceSpan(*r[:3]), *r[3:]) for r in self._db.execute("SELECT source_namespace,source_record_key,source_revision,state_version,policy_revision,recorded_at_ms FROM output_source_reads WHERE user_id=? AND namespace=? AND record_key=? AND revision=? ORDER BY source_namespace,source_record_key", args))
        outputs = tuple(SourceSpan(*r) for r in self._db.execute("SELECT parent_namespace,parent_record_key,parent_revision FROM output_parent_reads WHERE user_id=? AND namespace=? AND record_key=? AND revision=? ORDER BY parent_namespace,parent_record_key,parent_revision", args))
        candidates = tuple(CandidateReference(*r) for r in self._db.execute("SELECT candidate_id,row_version FROM output_candidate_reads WHERE user_id=? AND namespace=? AND record_key=? AND revision=? ORDER BY candidate_id", args))
        return OutputReadSet(memories, sources, outputs, candidates)

    def _output_dependencies(self, access, outputs, purpose, *, owner=None, derived_scope=None,
                             require_current=True, candidates=(), current_outputs=None, snapshot=None):
        """One bounded, iterative ancestor validator for output and body versions.

        Current and privacy-only paths have distinct validation contexts. A
        completed candidate's unquoted input may retire ordinarily; its privacy
        ancestry and immutable scope still apply. No source callbacks run here.
        """
        from .evidence import OutputReadSet
        from .maintenance import Maintenance
        from .candidates import Candidates, CandidateReference
        owner = access.user_id if access is not None else owner
        if owner is None:
            raise MemoryValidationError("missing_internal_scope")
        maintenance, proposals = Maintenance(self), Candidates(self)
        origins = snapshot["origins"] if snapshot is not None else None
        output_reads = snapshot["outputs"] if snapshot is not None else None
        note_checks = snapshot["notes"] if snapshot is not None else None
        queue, queued = deque(), set()
        def enqueue(kind, value, current, scope):
            if kind == "output":
                # Validate the delivered span before normalizing the identity.
                # An unknown disjoint fragment need not inherit a whole-record
                # exclusion; a known output still inherits its complete reads.
                origin = (owner, value) if origins is not None else None
                try:
                    if origins is None or origin not in origins:
                        self._check_origin(MemoryScope("shared", owner) if access is None else access, value)
                        if origins is not None:
                            origins.add(origin)
                except MemoryValidationError:
                    raise MemoryConflict("recall_use_source_unavailable") from None
                if value.start_cp is not None:
                    value = SourceSpan(value.namespace, value.record_key, value.revision)
            node = kind, value, current, scope
            if node not in queued:
                queued.add(node)
                if len(queued) > _MAX_OUTPUT_GRAPH:
                    raise MemoryConflict("output_dependency_limit")
                queue.append(node)
        for source in outputs:
            enqueue("output", source, require_current, derived_scope)
        for ref in candidates:
            enqueue("candidate", ref, require_current, derived_scope)
        memories, raw, known, bodies = {}, {}, set(), {}
        while queue:
            kind, value, current, scope = queue.popleft()
            if kind == "candidate":
                ref = value
                if ref.candidate_id in bodies and bodies[ref.candidate_id] != ref.row_version:
                    raise MemoryConflict("stale_candidate_reference")
                bodies[ref.candidate_id] = ref.row_version
                where, parameters = self._where(access, "s") if access is not None else ("s.user_id=?", (owner,))
                row = self._db.execute("SELECT c.*,s.scope_kind,s.user_id,s.character_id,s.project_id FROM candidates c JOIN formation_tasks t ON t.task_id=c.task_id JOIN source_streams s ON s.stream_id=t.stream_id WHERE c.candidate_id=? AND " + where, (ref.candidate_id, *parameters)).fetchone()
                if row is None or (current and (row["state"] != "pending" or row["text"] is None or row["row_version"] != ref.row_version)):
                    raise MemoryConflict("stale_candidate_reference")
                if scope is not None and not self._scope_contains(row, scope):
                    raise MemoryConflict("derived_output_scope_expansion")
                candidate = proposals._candidate(row)
                inputs = proposals._review_eligible(access, candidate, check_parents=False, require_current=current)
                for source, necessary_current in inputs:
                    enqueue("output", source, necessary_current, candidate.scope)
                continue
            source = value
            output_key = (owner, source) if output_reads is not None else None
            cached = output_reads is not None and output_key in output_reads
            if cached:
                state = output_reads[output_key]
                if state is None:
                    continue
                binding, reads = state
            else:
                if not self._known_output(owner, source):
                    if output_reads is not None:
                        output_reads[output_key] = None
                    continue
                binding = self._db.execute("SELECT invalid_reason,privacy_invalidated FROM output_bindings WHERE user_id=? AND namespace=? AND record_key=? AND revision=?", (owner, source.namespace, source.record_key, source.revision)).fetchone()
                reads = None
            known.add(source)
            if current and current_outputs is not None:
                current_outputs.add(source)
            if binding is not None and binding["invalid_reason"] is not None and (current or binding["privacy_invalidated"]):
                raise MemoryConflict("output_unavailable")
            if reads is None:
                reads = self._output_direct_reads(owner, source)
                if output_reads is not None:
                    output_reads[output_key] = (binding, reads)
            versions = {ref.memory_id: ref.row_version for ref in reads.memories}
            note_key = ((access, tuple(sorted(versions.items())), purpose, scope, current)
                        if note_checks is not None else None)
            if note_checks is None or note_key not in note_checks:
                self._validate_recall_references(access, versions, purpose, derived_scope=scope, require_current=current)
                if note_checks is not None:
                    note_checks.add(note_key)
            for mid, version in versions.items():
                if mid in memories and memories[mid] != version:
                    raise MemoryConflict("stale_memory_version")
                memories[mid] = version
            for item in reads.sources:
                key = item.source.namespace, item.source.record_key
                if key in raw and raw[key] != item:
                    raise MemoryConflict("source_snapshot_conflict")
                raw[key] = item
                row = self._db.execute("SELECT * FROM source_states WHERE namespace=? AND record_key=?", key).fetchone()
                if row is None:
                    raise MemoryConflict("output_source_unavailable")
                if current:
                    row = maintenance._lookup_input(access, item, check_parents=False, stream_id=row["stream_id"])
                else:
                    self._check_origin(MemoryScope("shared", owner) if access is None else access, item.source)
                stream = maintenance._source_stream(access, row["stream_id"])
                if stream["user_id"] != owner or (scope is not None and not self._scope_contains(stream, scope)):
                    raise MemoryConflict("derived_output_scope_expansion")
                enqueue("output", item.source, current, scope)
            for parent in reads.outputs:
                enqueue("output", parent, current, scope)
            for ref in reads.candidates:
                enqueue("candidate", ref, current, scope)
        if raw and purpose == "ordinary":
            raise MemoryConflict("raw_read_set_lookup_only")
        if bodies and purpose == "ordinary":
            raise MemoryConflict("candidate_read_set_lookup_only")
        return OutputReadSet(tuple(RecallReference(k, v) for k, v in sorted(memories.items())),
                             tuple(raw[k] for k in sorted(raw)), self._sort_sources(known),
                             tuple(CandidateReference(k, v) for k, v in sorted(bodies.items())))

    def capture_read_set(self, access: AccessScope, *, memories=(), sources=(), outputs=(), candidates=(), now_ms: int,
                         purpose: str = "lookup", review_pending: bool = False):
        """Capture actual raw records, Memory/candidate versions and history.

        Sources must be the records actually delivered, not merely fetched by
        a Reader. Unknown history sources contribute no registered output edge.
        Direct pending bodies require explicit lookup review; recorded lookup
        history keeps its ancestry without granting ordinary-use permission.
        """
        from .evidence import OutputReadSet, _read_set
        from .maintenance import Maintenance, _integer
        self._access(access)
        self._purpose_bit(purpose)
        _integer(now_ms, "now_ms")
        output_inputs = tuple(outputs)
        reads = _read_set(OutputReadSet(tuple(memories), tuple(sources), output_inputs, tuple(candidates)))
        if not isinstance(review_pending, bool):
            raise MemoryValidationError("invalid_review_pending")
        if reads.candidates and (not review_pending or purpose != "lookup"):
            raise MemoryValidationError("pending_requires_lookup_review")
        with self._lock:
            self._check()
            self._validate_recall_references(access, {r.memory_id: r.row_version for r in reads.memories}, purpose)
            for item in reads.sources:
                Maintenance(self)._lookup_input(access, item)
            if reads.sources and purpose != "lookup":
                raise MemoryConflict("raw_read_set_lookup_only")
            for output in output_inputs:
                self._check_origin(access, output)
            known = tuple(s for s in reads.outputs if self._known_output(access.user_id, s))
            self._output_dependencies(access, (*known, *(i.source for i in reads.sources)), purpose, candidates=reads.candidates)
            return replace(reads, outputs=known)

    def register_output_use(self, access: AccessScope, reads, *, source: SourceSpan,
                            now_ms: int, purpose: str = "lookup", review_pending: bool = False) -> None:
        """Seal an immutable complete direct read set in one owner transaction."""
        from .evidence import _read_set
        self._source(source)
        if source is None or source.start_cp is not None:
            raise MemoryValidationError("recall_use_requires_whole_source")
        reads = _read_set(reads)
        if not (reads.memories or reads.sources or reads.outputs or reads.candidates):
            raise MemoryValidationError("invalid_recall_use")
        with self._lock:
            self._check()
            with self._transaction():
                current = self.capture_read_set(access, memories=reads.memories, sources=reads.sources, outputs=reads.outputs, candidates=reads.candidates,
                                                now_ms=now_ms, purpose=purpose, review_pending=review_pending)
                if current != reads:
                    raise MemoryConflict("output_read_set_changed")
                try:
                    self._check_origin(access, source)
                except MemoryValidationError:
                    raise MemoryConflict("recall_use_source_unavailable") from None
                if self._known_output(access.user_id, source):
                    # Legacy recall_uses without a header are already sealed.
                    if self._output_direct_reads(access.user_id, source) != reads:
                        raise MemoryConflict("recall_use_source_reused")
                    self._output_dependencies(access, (source,), purpose)
                    return
                # Count the prospective root under the same ancestor bound as
                # later reads, before accepting the final node at capacity.
                self._output_dependencies(access, (*reads.outputs, *(i.source for i in reads.sources), source), purpose, candidates=reads.candidates)
                args = access.user_id, source.namespace, source.record_key, source.revision
                self._db.execute("INSERT INTO output_bindings(user_id,namespace,record_key,revision) VALUES(?,?,?,?)", args)
                self._db.executemany("INSERT INTO recall_uses(user_id,memory_id,row_version,namespace,record_key,revision) VALUES(?,?,?,?,?,?)", ((access.user_id, r.memory_id, r.row_version, source.namespace, source.record_key, source.revision) for r in reads.memories))
                self._db.executemany("INSERT INTO output_source_reads VALUES(?,?,?,?,?,?,?,?,?,?)", ((*args, i.source.namespace, i.source.record_key, i.source.revision, i.state_version, i.policy_revision, i.recorded_at_ms) for i in reads.sources))
                self._db.executemany("INSERT INTO output_parent_reads VALUES(?,?,?,?,?,?,?)", ((*args, p.namespace, p.record_key, p.revision) for p in reads.outputs))
                self._db.executemany("INSERT INTO output_candidate_reads VALUES(?,?,?,?,?,?)", ((*args, r.candidate_id, r.row_version) for r in reads.candidates))
                self._change()

    def register_recall_use(self, access: AccessScope, candidates: Sequence[RecallCandidate | RecallReference], *,
                            source: SourceSpan, now_ms: int, purpose: str = "ordinary") -> None:
        """Atomically bind a whole Host output revision to current memory IDs.

        This stores no text, receipts or user-operation outcome. The Host owns
        the source identity and must register before first delivery. A source's
        exact dependency set is immutable; retries of that set are idempotent.
        """
        from .evidence import OutputReadSet
        return self.register_output_use(access, OutputReadSet(memories=tuple(candidates)), source=source, now_ms=now_ms, purpose=purpose)

    def revalidate(self, access: AccessScope, candidates: Sequence[RecallCandidate], *,
                   now_ms: int, max_chars: int = 4096, limit: int = 100,
                   purpose: str = "ordinary") -> RecallResult:
        self._access(access)
        self._purpose_bit(purpose)
        if not isinstance(now_ms, int) or isinstance(now_ms, bool) or now_ms < 0 or not 0 <= max_chars <= _MAX_RECALL_CHARS or not 1 <= limit <= 100:
            raise MemoryValidationError("invalid_revalidation_options")
        with self._lock:
            self._check()
            chosen = []
            used = omitted = 0
            seen = set()
            for candidate in candidates:
                if candidate.memory_id in seen:
                    continue
                seen.add(candidate.memory_id)
                try:
                    row = self._get(access, candidate.memory_id)
                except MemoryNotFound:
                    continue
                if not self._eligible_row(row, purpose) or row["row_version"] != candidate.row_version:
                    continue
                # Read current authoritative text instead of trusting caller DTOs.
                m = self._memory(row)
                size = len(m.text) + len(m.condition or "")
                if len(chosen) >= limit or used + size > max_chars:
                    omitted += 1
                    continue
                used += size
                chosen.append(RecallCandidate(m.memory_id, m.row_version, m.text, m.kind, m.condition, m.scope, m.source, candidate.score, candidate.semantic_score, candidate.lexical_match, m.retention))
            status = self.status(access, purpose=purpose)
            coverage = RecallCoverage(status.semantic, status.active_memories, status.indexed_memories,
                                      status.pending_memories, status.failed_memories, budget_omitted=omitted)
            return RecallResult(tuple(chosen), coverage, status.change_seq)

    def rebuild_fts(self) -> None:
        with self._lock:
            self._check()
            with self._transaction():
                self._db.execute("INSERT INTO memory_fts(memory_fts) VALUES('rebuild')")
                self._db.execute("INSERT INTO retrieval_fts(retrieval_fts) VALUES('rebuild')")

    def close(self) -> None:
        with self._index_lock, self._embedding_lock, self._lock:
            if not self._closed:
                if self._source_vectors is not None:
                    self._source_vectors.reset()
                self.cleanup()
                self._db.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                self._db.close()
                if self._owner_file:
                    self._owner_file.close()
                self._closed = True

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
