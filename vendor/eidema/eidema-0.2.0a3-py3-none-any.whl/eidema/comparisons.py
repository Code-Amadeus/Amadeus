"""Source-targeted comparison records, without a relation authority or scheduler."""
from __future__ import annotations

from dataclasses import dataclass, replace
from typing import Mapping, Sequence

from .candidates import (
    Candidates, CandidateDraft, ComparisonDraft, Comparison, EvidenceQuote,
    _COMPARISON_KINDS, _MAX_BODY_CHARS, _invalidate_memories,
)
from .executor import FormationExecutor, _strict_json
from .maintenance import _integer
from .models import (
    AccessScope, Memory, SourceSpan, RecallReference, OperationResult,
    MemoryConflict, MemoryNotFound, MemoryValidationError,
)
from .sources import _identity, _validate_source


def parse_comparison_v1(content: str, sources: Mapping[str, SourceSpan]) -> tuple[CandidateDraft, ...]:
    """Strict complete comparison proposals; no semantic qualification."""
    try:
        body = _strict_json(content)
    except (ValueError, TypeError, RecursionError):
        raise MemoryValidationError("invalid_comparison_json") from None
    if (not isinstance(body, dict) or set(body) != {"complete", "items"}
            or type(body["complete"]) is not bool or not isinstance(body["items"], list)):
        raise MemoryValidationError("invalid_comparison_envelope")
    if not body["complete"]:
        raise MemoryValidationError("incomplete_comparison_batch")
    if len(body["items"]) > 64:
        raise MemoryValidationError("comparison_item_limit")
    def reference(value):
        if (not isinstance(value, dict) or set(value) != {"source_id", "quote"}
                or not isinstance(value["source_id"], str) or value["source_id"] not in sources
                or not isinstance(value["quote"], str) or not value["quote"]):
            raise MemoryValidationError("invalid_comparison_reference")
        return EvidenceQuote(sources[value["source_id"]], value["quote"])
    drafts = []
    for index, item in enumerate(body["items"]):
        required = {"statement", "comparison_kind", "left", "right"}
        if (not isinstance(item, dict) or not required <= set(item) <= required | {"support"}
                or not isinstance(item["statement"], str) or not item["statement"].strip()
                or not isinstance(item["comparison_kind"], str) or item["comparison_kind"] not in _COMPARISON_KINDS
                or not isinstance(item.get("support", []), list)):
            raise MemoryValidationError("invalid_comparison_item")
        drafts.append(CandidateDraft(str(index), item["statement"], "proposal",
            tuple(reference(ref) for ref in item.get("support", [])),
            comparison=ComparisonDraft(item["comparison_kind"], reference(item["left"]), reference(item["right"]))))
    return tuple(drafts)


class ComparisonExecutor(FormationExecutor):
    """The bounded executor with one fixed comparison-v1 output contract."""
    _codec = staticmethod(parse_comparison_v1)


class ColdReflectionExecutor(ComparisonExecutor):
    """One Host-driven cold comparison batch, using the existing bounded loop."""
    _work_class = "cold"

    def __init__(self, store, reader, provider, *, max_runs=1, **options):
        super().__init__(store, reader, provider, **options)
        self.max_runs = max_runs


@dataclass(frozen=True)
class ComparisonView:
    memory: Memory
    comparison: Comparison


@dataclass(frozen=True)
class ComparisonResult:
    items: tuple[ComparisonView, ...]
    budget_omitted: int = 0


class Comparisons:
    """Read adopted comparison notes or discard one dependent projection.

    Constructing this facade reads no resources. Endpoints are historical source
    locators; only the associated Memory supplies the available authoritative body.
    """
    def __init__(self, store):
        self._store = store
        self._candidates = Candidates(store)

    @staticmethod
    def _reference(reference):
        if not isinstance(reference, RecallReference):
            raise MemoryValidationError("invalid_comparison_reference")
        _identity(reference.memory_id)
        _integer(reference.row_version, "row_version", 1)

    def _binding(self, memory_id):
        row = self._store._db.execute("SELECT c.candidate_id FROM origins o JOIN candidate_comparisons c ON c.candidate_id=o.candidate_id WHERE o.memory_id=?", (memory_id,)).fetchone()
        if row is None:
            raise MemoryNotFound("comparison_not_found")
        return row["candidate_id"]

    def detail(self, access: AccessScope, reference: RecallReference, *, purpose: str = "lookup") -> ComparisonView:
        self._store._access(access)
        self._reference(reference)
        self._store._purpose_bit(purpose)
        with self._store._lock:
            self._store._check()
            row = self._store._get(access, reference.memory_id)
            if row["row_version"] != reference.row_version:
                raise MemoryConflict("stale_comparison_reference")
            if not self._store._eligible_row(row, purpose) or row["text"] is None:
                raise MemoryNotFound("comparison_not_found")
            comparison = self._candidates._comparison(self._binding(reference.memory_id))
            return ComparisonView(self._store._memory(row), comparison)

    def find(self, access: AccessScope, targets: Sequence[SourceSpan], *, purpose: str = "lookup",
             limit: int = 20, max_chars: int = 32768) -> ComparisonResult:
        self._store._access(access)
        self._store._purpose_bit(purpose)
        _integer(limit, "comparison_limit", 1, 1000)
        _integer(max_chars, "comparison_chars", 0, _MAX_BODY_CHARS)
        if not isinstance(targets, (list, tuple)) or len(targets) > 1000:
            raise MemoryValidationError("invalid_comparison_targets")
        for source in targets:
            _validate_source(source)
            if source is None:
                raise MemoryValidationError("invalid_comparison_targets")
            _integer(source.revision, "source_revision", 1)
            if source.start_cp is not None:
                _integer(source.start_cp, "source_start")
                _integer(source.end_cp, "source_end", source.start_cp+1)
        targets = tuple(dict.fromkeys(targets))
        with self._store._lock:
            self._store._check()
            if not targets:
                return ComparisonResult(())
            values = ",".join("(?,?,?,?,?)" for _ in targets)
            params = tuple(v for source in targets for v in
                (source.namespace, source.record_key, source.revision, source.start_cp, source.end_cp))
            where, scope_params = self._store._where(access)
            sql = ("WITH requested(namespace,record_key,revision,start_cp,end_cp) AS (VALUES " + values + ") "
                "SELECT DISTINCT m.*,c.candidate_id comparison_candidate FROM requested q "
                "JOIN candidate_evidence e ON e.namespace=q.namespace AND e.record_key=q.record_key AND e.revision=q.revision "
                "AND (q.start_cp IS NULL OR (e.start_cp<q.end_cp AND e.end_cp>q.start_cp)) "
                "JOIN candidate_comparisons c ON c.candidate_id=e.candidate_id AND e.ordinal IN (c.left_ordinal,c.right_ordinal) "
                "JOIN origins o ON o.candidate_id=c.candidate_id JOIN memories m ON m.memory_id=o.memory_id WHERE "
                + where + " AND " + self._store._eligibility(purpose) + " AND m.text IS NOT NULL "
                "ORDER BY m.created_at_ms DESC,m.memory_id")
            result, omitted, used = [], 0, 0
            for row in self._store._db.execute(sql, (*params, *scope_params)):
                size = len(row["text"]) + len(row["condition_text"] or "")
                if len(result) >= limit or size > max_chars-used:
                    omitted += 1
                    continue
                comparison = self._candidates._comparison(row["comparison_candidate"])
                result.append(ComparisonView(self._store._memory(row), comparison))
                used += size
            return ComparisonResult(tuple(result), omitted)

    def find_authorized_change(self, access: AccessScope, excerpt: SourceSpan, *, direction: str,
                               expected_policy: tuple[str, str, str], purpose: str = "lookup"
                               ) -> tuple[RecallReference, Comparison] | None:
        """Return a unique published change under an exact Host policy binding."""
        match_end = {"previous": "right", "next": "left"}.get(direction)
        if match_end is None:
            return None
        selected = []
        with self._store._lock:
            found = self.find(access, [excerpt], purpose=purpose)
            if found.budget_omitted:
                return None
            for row in found.items:
                relation = row.comparison
                if relation.kind != "reported_change" or excerpt not in (relation.left, relation.right):
                    continue
                ref = RecallReference(row.memory.memory_id, row.memory.row_version)
                policy = self._store._db.execute(
                    "SELECT a.policy_id,a.policy_version,a.pipeline_version "
                    "FROM memories m JOIN derived_authorizations a ON a.authorization_id=m.authorization_id "
                    "WHERE m.memory_id=? AND m.row_version=? AND a.enabled=1 "
                    "AND m.authorization_generation=a.generation AND m.state='active' AND m.invalid_reason IS NULL",
                    (ref.memory_id, ref.row_version),
                ).fetchone()
                if policy is None or tuple(policy) != expected_policy:
                    return None
                if getattr(relation, match_end) == excerpt:
                    selected.append((ref, relation))
        return selected[0] if len(selected) == 1 else None

    def discard(self, access: AccessScope, reference: RecallReference, *, operation_id: str,
                item_id: str, now_ms: int) -> OperationResult:
        self._store._access(access)
        self._reference(reference)
        self._store._key(operation_id, item_id)
        _integer(now_ms, "now_ms")
        fp = self._store._fingerprint(["comparison_discard", reference.memory_id, reference.row_version])
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                replay = self._store._replay(access, operation_id, item_id, fp, "comparison_discard")
                if replay:
                    return replace(replay, row_version=reference.row_version+1) if replay.status == "discarded" else replay
                row = self._store._get(access, reference.memory_id)
                if row["row_version"] != reference.row_version:
                    raise MemoryConflict("stale_comparison_reference")
                self._binding(reference.memory_id)
                if row["retention"] != "dependent":
                    raise MemoryValidationError("explicit_comparison_not_discardable")
                if row["state"] != "active" or row["invalid_reason"] is not None:
                    raise MemoryConflict("comparison_unavailable")
                _invalidate_memories(self._store, access, (reference.memory_id,), "comparison_discarded", privacy=False)
                self._store._db.execute("UPDATE memories SET updated_at_ms=? WHERE memory_id=?", (now_ms, reference.memory_id))
                self._store._record(access, operation_id, item_id, "comparison_discard", reference.memory_id,
                                    "discarded", fp)
            clean = self._store.cleanup()
            return OperationResult("discarded", reference.memory_id, reference.row_version+1, False, None, not clean)
