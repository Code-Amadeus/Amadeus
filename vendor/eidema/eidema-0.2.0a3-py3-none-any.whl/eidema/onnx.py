"""Optional offline CPU embedding for ONNX graphs with pooled 2-D output."""
from __future__ import annotations

from bisect import bisect_right
import json
from pathlib import Path
from threading import RLock

import numpy as np

from .embeddings import prepare_embedding_query
from .models import MemoryValidationError


class _QueryTokenizer:
    """The existing Eidema bounded-query API over a Rust tokenizers instance."""
    def __init__(self, tokenizer):
        self.tokenizer = tokenizer

    def encode(self, value, **_kwargs):
        return self.tokenizer.encode(value).ids

    def __call__(self, value, **_kwargs):
        return {"offset_mapping": self.tokenizer.encode(value).offsets}


class OnnxTextEmbedder:
    """Use Host-supplied local model files. Nothing is downloaded.

    The graph accepts int64 input_ids and attention_mask and returns one
    floating point sentence vector per input at the requested output name.
    Token budgets include prefixes and any tokenizer special tokens.
    """

    def __init__(self, model_file, tokenizer_file, tokenizer_config_file, *,
                 version: str, dimensions: int, query_prefix: str = "", document_prefix: str = "",
                 max_tokens: int, max_passage_tokens: int, max_history_tokens: int = 0,
                 intra_op_threads: int = 4, output_name: str = "sentence_embedding"):
        integers = dimensions, max_tokens, max_passage_tokens, max_history_tokens, intra_op_threads
        if (any(type(value) is not int for value in integers) or not 1 <= dimensions <= 65536
                or not 1 <= max_passage_tokens <= max_tokens
                or not 0 <= max_history_tokens <= max_tokens or not 1 <= intra_op_threads
                or not isinstance(version, str) or not version.strip()
                or not isinstance(output_name, str) or not output_name
                or not isinstance(query_prefix, str) or not isinstance(document_prefix, str)):
            raise MemoryValidationError("invalid_onnx_embedding_configuration")
        import onnxruntime as ort
        from tokenizers import Tokenizer

        self.version, self.dimensions, self.output_name = version, dimensions, output_name
        self.query_prefix, self.document_prefix = query_prefix, document_prefix
        self.max_tokens, self.max_passage_tokens, self.max_history_tokens = (
            max_tokens, max_passage_tokens, max_history_tokens)
        self._lock = RLock()
        self.tokenizer = Tokenizer.from_file(str(tokenizer_file))
        self.tokenizer.no_truncation()
        self.tokenizer.no_padding()
        config = json.loads(Path(tokenizer_config_file).read_text(encoding="utf-8"))
        pad_token = config.get("pad_token")
        pad_id = self.tokenizer.token_to_id(pad_token) if isinstance(pad_token, str) else None
        if pad_id is None or config.get("padding_side", "right") != "right":
            raise MemoryValidationError("onnx_padding_unsupported")
        self.padding = {"direction": "right", "pad_id": pad_id, "pad_token": pad_token}
        self.query_tokenizer = _QueryTokenizer(self.tokenizer)
        options = ort.SessionOptions()
        options.intra_op_num_threads = intra_op_threads
        options.inter_op_num_threads = 1
        options.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        try:
            self.session = ort.InferenceSession(str(model_file), sess_options=options,
                providers=["CPUExecutionProvider"])
        except Exception:
            raise MemoryValidationError("onnx_model_unsupported") from None
        self.session.disable_fallback()
        inputs = self.session.get_inputs()
        outputs = {item.name: item for item in self.session.get_outputs()}
        output = outputs.get(output_name)
        if (set(item.name for item in inputs) != {"input_ids", "attention_mask"}
                or any(item.type != "tensor(int64)" for item in inputs)
                or output is None or len(output.shape or ()) != 2 or output.shape[-1] != dimensions):
            raise MemoryValidationError("onnx_model_unsupported")

    def _fits(self, value, *, max_tokens=None):
        max_tokens = self.max_tokens if max_tokens is None else max_tokens
        return len(self.tokenizer.encode(value).ids) <= max_tokens

    def _encode(self, values, *, overflow, max_tokens=None):
        with self._lock:
            # Never silently truncate a stored passage or direct query call.
            if not all(self._fits(value, max_tokens=max_tokens) for value in values):
                raise ValueError(overflow)
            if not values:
                return []
            vectors = []
            try:
                self.tokenizer.enable_padding(**self.padding)
                for start in range(0, len(values), 8):
                    encoded = self.tokenizer.encode_batch(values[start:start + 8])
                    feeds = {"input_ids": np.asarray([x.ids for x in encoded], dtype=np.int64),
                        "attention_mask": np.asarray([x.attention_mask for x in encoded], dtype=np.int64)}
                    output = np.asarray(self.session.run([self.output_name], feeds)[0], dtype=np.float32)
                    if output.shape != (len(encoded), self.dimensions) or not np.isfinite(output).all():
                        raise ValueError("invalid_embedding")
                    norms = np.linalg.norm(output, axis=1, keepdims=True)
                    if (norms == 0).any():
                        raise ValueError("zero_embedding")
                    vectors.extend((output / norms).tolist())
            finally:
                self.tokenizer.no_padding()
            return vectors

    def split_passage(self, text):
        chunks, start = [], 0
        prefix, limit = self.document_prefix, self.max_passage_tokens
        with self._lock:
            tokenizer = self.tokenizer
            # Tokenize the whole source once; byte tokens may share an offset.
            # Offsets choose boundaries, while exact prefixed measurements own fit.
            ends = [end for begin, end in tokenizer.encode(text).offsets if end > begin]
            available = limit - len(tokenizer.encode(prefix).ids)
            if available < 1:
                raise ValueError("embedding_character_too_long")
            while start < len(text):
                index = bisect_right(ends, start)
                end = (ends[index + available - 1]
                    if index + available < len(ends) else len(text))
                end = max(start + 1, end)
                # Prefix/boundary retokenization can add tokens. Retain a complete
                # codepoint and verify it instead of assuming token additivity.
                while end > start and not self._fits(prefix + text[start:end], max_tokens=limit):
                    end -= 1
                if end == start:
                    raise ValueError("embedding_character_too_long")
                chunks.append(text[start:end])
                start = end
        return chunks

    def embed_passages(self, texts):
        return self._encode([self.document_prefix + text for text in texts],
            overflow="passage_too_long", max_tokens=self.max_passage_tokens)

    def embed_query(self, query):
        return self._encode([self.query_prefix + query], overflow="query_too_long")[0]

    def prepare_query(self, query, *, context=()):
        with self._lock:
            tokenizer, prefix = self.tokenizer, self.query_prefix
            maximum, history_cap = self.max_tokens, self.max_history_tokens
            current = prepare_embedding_query(self.query_tokenizer, query,
                max_tokens=maximum, prefix=prefix)
            # Current input owns its unchanged bounded projection. History can
            # use only a separately capped remainder; it cannot displace detail.
            recent = [text for text in context if isinstance(text, str) and text.strip()][:2]
            if current != query or not recent:
                return current
            current_tokens = len(tokenizer.encode(prefix + current).ids)
            budget = min(history_cap, maximum - current_tokens)
            if budget <= 0:
                return current
            target = current_tokens + budget
            combined = current + "\n" + "\n".join(recent)
            if len(tokenizer.encode(prefix + combined).ids) <= target:
                return combined

            special = len(tokenizer.encode("").ids)
            def added_tokens(text):
                return len(tokenizer.encode("\n" + text).ids) - special
            costs = [added_tokens(text) for text in recent]
            shares = [min(cost, budget // len(recent) + (index < budget % len(recent)))
                for index, cost in enumerate(costs)]
            # Give an unused half to the other turn rather than wasting it.
            spare = budget - sum(shares)
            for index, cost in enumerate(costs):
                extra = min(spare, cost - shares[index])
                shares[index] += extra
                spare -= extra
            offsets = [[(begin, end) for begin, end in tokenizer.encode(text).offsets if end > begin]
                for text in recent]
            marker = "\n[…]\n"
            marker_cost = added_tokens(marker)
            def excerpt(index):
                text, share = recent[index], shares[index]
                if costs[index] <= share:
                    return text
                body = share - marker_cost
                while body >= 2:
                    head, tail = (body + 1) // 2, body // 2
                    spans = offsets[index]
                    end = spans[min(head, len(spans)) - 1][1]
                    begin = spans[max(0, len(spans) - tail)][0]
                    bounded = text if end >= begin else text[:end] + marker + text[begin:]
                    if added_tokens(bounded) <= share:
                        return bounded
                    body -= 1
                return ""
            while True:
                excerpts = [excerpt(index) for index in range(len(recent))]
                prepared = current + "".join("\n" + text for text in excerpts if text)
                if len(tokenizer.encode(prefix + prepared).ids) <= target:
                    return prepared
                # Final measurement includes cross-boundary tokenization. Trim
                # the larger allocation until the whole actual input fits.
                index = max(range(len(shares)), key=shares.__getitem__)
                shares[index] -= 1
