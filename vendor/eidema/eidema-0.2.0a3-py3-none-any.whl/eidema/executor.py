"""Explicitly driven formation; no scheduler, transport, model or credential I/O.

Callbacks are trusted Host adapters. Source, request preparation, generation,
gates and adoption selection never run inside a database write transaction.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, replace
import json
from typing import Literal, Mapping, Sequence

from .candidates import Candidates, CandidateDraft, CandidateReference, EvidenceQuote, _KINDS
from .maintenance import Maintenance, SourceInput, Usage, Attempt, BudgetStatus, _integer, _usage, _target_use_mask
from .models import AccessScope, SourceSpan, SourceContent, RecallReference, MemoryError, MemoryConflict, MemoryNotFound, MemoryValidationError
from .retrieval import Retrieval, RetrievalReference
from .sources import _validate_source


@dataclass(frozen=True)
class FormationSource:
    """Model-visible batch alias and Host metadata, without SQL/permission IDs."""
    source_id: str
    text: str
    speaker_role: str
    speaker_ref: str | None
    recorded_at_ms: int | None
    input_role: Literal["incremental", "context", "reformation_root", "quote_gap_root"] = "incremental"


@dataclass(frozen=True)
class PreparedCall:
    pipeline_version: str
    payload: bytes
    reserved: Usage


@dataclass(frozen=True)
class ProviderResult:
    content: str
    finish: str = "stop"
    actual: Usage | None = None


@dataclass(frozen=True)
class AdoptionDecision:
    authorization_id: str
    generation: int
    memory_kind: str
    uses: tuple[str, ...] = ("lookup",)


@dataclass(frozen=True)
class ExecutorLimits:
    source_chars: int = 1_000_000
    source_bytes: int = 4_000_000
    response_chars: int = 262144
    max_usage: Usage = Usage(100000, 4096, 100000)
    timeout_ms: int = 30000
    post_limit: int = 64
    max_chunks: int = 128


class SourceCapacityExceeded(MemoryValidationError):
    """Trusted current whole-source size receipt, distinct from read failure."""
    def __init__(self, pin, chars, utf8_bytes, *, code="source_read_capacity"):
        super().__init__(code)
        self.pin, self.chars, self.utf8_bytes = pin, chars, utf8_bytes


@dataclass(frozen=True)
class StepReport:
    stage: str
    code: str | None = None
    task_id: str | None = None
    attempt: Attempt | None = None
    budget: BudgetStatus | None = None
    candidates: tuple[CandidateReference, ...] = ()
    remaining: tuple[CandidateReference, ...] = ()
    published: tuple[RecallReference, ...] = ()
    raw: tuple[RetrievalReference, ...] = ()
    generated: bool = False
    actual: Usage | None = None
    usage_pending: bool = False
    post_pending: bool = False
    index_followup: str | None = None
    quote_failures: tuple[tuple[str, str], ...] = ()


def _strict_json(content):
    def unique(pairs):
        body = {}
        for key, value in pairs:
            if key in body:
                raise ValueError()
            body[key] = value
        return body
    def constant(_):
        raise ValueError()
    return json.loads(content, object_pairs_hook=unique, parse_constant=constant)


def parse_formation_v2(content: str, sources: Mapping[str, SourceSpan]) -> tuple[CandidateDraft, ...]:
    """Strict complete-batch codec. Structural acceptance proves no semantics."""
    try:
        body = _strict_json(content)
    except (ValueError, TypeError, RecursionError):
        raise MemoryValidationError("invalid_formation_json") from None
    if (not isinstance(body, dict) or set(body) != {"complete", "items"}
            or type(body["complete"]) is not bool or not isinstance(body["items"], list)):
        raise MemoryValidationError("invalid_formation_envelope")
    if not body["complete"]:
        raise MemoryValidationError("incomplete_formation_batch")
    if len(body["items"]) > 64:
        raise MemoryValidationError("formation_item_limit")
    def refs(value, *, necessary=False):
        if not isinstance(value, list) or (necessary and not value):
            raise MemoryValidationError("invalid_formation_support")
        result = []
        for ref in value:
            if (not isinstance(ref, dict) or set(ref) != {"source_id", "quote"}
                    or not isinstance(ref["source_id"], str) or ref["source_id"] not in sources
                    or not isinstance(ref["quote"], str) or not ref["quote"]):
                raise MemoryValidationError("invalid_formation_reference")
            result.append(EvidenceQuote(sources[ref["source_id"]], ref["quote"]))
        return tuple(result)
    drafts = []
    for index, item in enumerate(body["items"]):
        if (not isinstance(item, dict) or not {"statement", "kind", "support"} <= set(item) <= {"statement", "kind", "support", "transition_evidence"}
                or not isinstance(item["statement"], str) or not item["statement"].strip()
                or not isinstance(item["kind"], str) or item["kind"] not in _KINDS):
            raise MemoryValidationError("invalid_formation_item")
        transitions = item.get("transition_evidence")
        drafts.append(CandidateDraft(str(index), item["statement"], item["kind"], refs(item["support"], necessary=True),
                                     transitions=refs([] if transitions is None else transitions)))
    return tuple(drafts)


class FormationStopped(MemoryError):
    """A trusted Host cannot authorize the current stage of formation."""

    def __init__(self, stage, code):
        super().__init__(code)
        self.stage, self.code = stage, code


class FormationExecutor:
    """One bounded step; construction only retains Host-supplied objects."""
    _codec = staticmethod(parse_formation_v2)
    _work_class = "warm"
    def __init__(self, store, reader, provider, *, authorized=None, ready=None,
                 clock=None, selector=None, limits=ExecutorLimits(), isolate_quote_failures=False,
                 access_scope: AccessScope | None = None, prepare_inputs=None, source_guard=None):
        """Bind optional Host source preparation and serialization.

        prepare_inputs(access, task, max_sources) returns the task and its
        reader. source_guard(access, task, contents) returns a context manager
        entered immediately before dispatch, commit or publication. Contents
        are the actual read of each pin. On resumed publication they are
        None, so a Host can reopen the exact task inputs.
        """
        self.store, self.reader, self.provider = store, reader, provider
        self.authorized, self.ready, self.selector, self.limits = authorized, ready, selector, limits
        if any(hook is not None and not callable(hook) for hook in (prepare_inputs, source_guard)):
            raise MemoryValidationError("invalid_formation_source_hook")
        if access_scope is not None:
            store._access(access_scope)
        self.access_scope, self.prepare_inputs, self.source_guard = access_scope, prepare_inputs, source_guard
        if type(isolate_quote_failures) is not bool:
            raise MemoryValidationError("invalid_quote_isolation")
        if isolate_quote_failures and (self._work_class != "warm" or self._codec is not parse_formation_v2):
            raise MemoryValidationError("quote_isolation_warm_only")
        self.isolate_quote_failures = isolate_quote_failures
        self.clock = clock
        self.maintenance, self.candidates, self.retrieval = Maintenance(store), Candidates(store), Retrieval(store)

    def _allowed(self):
        try:
            allowed = self.authorized is not None and self.authorized() is True
        except Exception:
            raise FormationStopped("denied", "authorization_check_failed") from None
        if not allowed:
            raise FormationStopped("denied", "execution_not_authorized")

    def require_resources(self):
        """Raise FormationStopped if a new unit cannot use Host resources."""
        try:
            ready = self.ready is None or self.ready() is True
        except Exception:
            raise FormationStopped("deferred", "resource_check_failed") from None
        if not ready:
            raise FormationStopped("deferred", "resource_busy")

    def _now(self):
        if self.clock is None:
            raise FormationStopped("denied", "host_clock_required")
        try:
            now = self.clock()
            _integer(now, "now_ms")
            return now
        except Exception:
            raise FormationStopped("failed", "host_clock_failed") from None

    def _limits(self):
        if not isinstance(self.limits, ExecutorLimits):
            raise MemoryValidationError("invalid_executor_limits")
        for name in ("source_chars", "source_bytes", "response_chars", "timeout_ms", "post_limit", "max_chunks"):
            _integer(getattr(self.limits, name), name, 1)
        _integer(self.limits.post_limit, "post_limit", 1, 64)
        _integer(self.limits.max_chunks, "max_chunks", 1, 4096)
        _usage(self.limits.max_usage)

    def _current(self, access, task):
        if not self.maintenance.task_current(access, task.task_id):
            raise FormationStopped("stale", "source_snapshot_changed")

    def _report(self, report, access):
        if report.attempt is None:
            return report
        try:
            attempt = self.maintenance.attempt(access, report.attempt.attempt_id)
            committed = self.candidates.result(access, attempt.attempt_id) if attempt.outcome == "candidates" else None
            refs = committed.candidates if committed is not None else report.candidates
            task = self.maintenance.task(access, attempt.task_id)
            raw = self.retrieval.source_references(access, task.inputs)
            incomplete = any(state != "ready" for _, state in self._cache_states(raw))
            return replace(report, attempt=attempt, candidates=refs, raw=raw,
                           quote_failures=report.quote_failures,
                           post_pending=report.post_pending or incomplete, budget=self.maintenance.budget_status(attempt.window_id),
                           usage_pending=report.actual is not None and attempt.actual is None)
        except Exception:
            return replace(report, usage_pending=report.actual is not None)

    def _prepare_task(self, access, stream_id, pipeline_version, **planning):
        """Protected planning seam, after authorization/resource/formation lock.

        Default path performs exactly the existing prepare operation.
        """
        return self.maintenance.prepare(access, stream_id, pipeline_version, **planning)

    def _check_budget(self, budget, now_ms):
        if not budget.window.start_ms <= now_ms < budget.window.end_ms:
            raise FormationStopped("blocked", "outside_budget_window")
        if budget.calls >= budget.window.max_calls:
            raise FormationStopped("blocked", "budget_exhausted")

    def _prepare_source_inputs(self, access, task, **planning):
        """Protected Host seam under the formation lock and existing gates.

        Default behavior is unchanged. A specialization may replan only an
        unattempted task and return a step-local current Reader callable.
        """
        if self.prepare_inputs is not None:
            return self.prepare_inputs(access, task, planning["max_sources"])
        return task, self.reader.read

    @contextmanager
    def _source_boundary(self, access, task, contents, *, require_ready=False):
        if self.source_guard is None:
            yield
            return
        with self.source_guard(access, task, contents):
            # Staging the Host read set can take longer than a resource probe.
            # In-flight work can still settle even when new work is deferred.
            if require_ready:
                self._allowed()
                self.require_resources()
            yield

    def step(self, access: AccessScope, stream_id: str, pipeline_version: str, *,
             window_id: str, reservation_key: str = "initial",
             max_events: int = 100, max_sources: int = 100, max_attempts: int = 1,
             materialize_raw: bool = False, retry: bool = False,
             context_inputs: Sequence[SourceInput] | None = None,
             target_uses: Sequence[str] | None = None) -> StepReport:
        if self.access_scope is not None and self.access_scope != access:
            return StepReport("denied", "formation_scope_mismatch")
        if not self.store._formation_lock.acquire(blocking=False):
            return StepReport("busy", "formation_busy")
        try:
            return self._step(access, stream_id, pipeline_version, window_id=window_id,
                reservation_key=reservation_key, max_events=max_events, max_sources=max_sources,
                max_attempts=max_attempts, materialize_raw=materialize_raw, retry=retry, context_inputs=context_inputs, target_uses=target_uses)
        finally:
            self.store._formation_lock.release()

    def _step(self, access, stream_id, pipeline_version, *, window_id, reservation_key,
              max_events, max_sources, max_attempts, materialize_raw, retry, context_inputs, target_uses):
        report = StepReport("pending")
        sent = False
        owns_reservation = False
        provider = self.provider
        codec = self._codec
        work_class = self._work_class
        cold_max_runs = self.max_runs if work_class == "cold" else 1
        try:
            self._limits()
            _integer(cold_max_runs, "cold_max_runs", 1, 2)
            requested_mask = _target_use_mask(target_uses)
            target_uses = None if requested_mask is None else tuple(p for p, bit in (("lookup", 1), ("ordinary", 2)) if requested_mask & bit)
            if not isinstance(materialize_raw, bool) or not isinstance(retry, bool):
                raise MemoryValidationError("invalid_executor_options")
            self._allowed()
            self.require_resources()
            now_ms = self._now()
            reformation_available = callable(getattr(provider, "prepare_reformation", None))
            task = self._prepare_task(access, stream_id, pipeline_version, max_events=max_events, max_sources=max_sources, max_attempts=max_attempts, context_inputs=context_inputs, work_class=work_class, target_uses=target_uses, allow_reformation=reformation_available)
            if task is None:
                if not reformation_available and self.maintenance.reformation_pending(access,stream_id,pipeline_version):
                    return StepReport("deferred", "reformation_provider_unsupported")
                return StepReport("idle", "no_events")
            report = replace(report, task_id=task.task_id)
            if task.state == "done":
                return self._resume(access, task.task_id, report)
            previous = self.maintenance.find_attempt(access, task.task_id, reservation_key)
            if previous is not None:
                return self._report(replace(report, stage="replayed", code=previous.outcome, attempt=previous), access)
            current = self.maintenance.current_attempt(access, task.task_id)
            if current is not None:
                report = replace(report, attempt=current)
            if current is not None and (not retry or reservation_key == "initial"):
                return self._report(replace(report, stage="replayed", code=current.outcome, attempt=current), access)
            if current is not None and task.state not in ("failed", "truncated", "unknown"):
                return self._report(replace(report, stage="replayed", code=current.outcome, attempt=current), access)
            if task.attempts >= task.max_attempts:
                raise FormationStopped("blocked", "task_attempts_exhausted")
            prepare_name, root_role = {
                "source_delta": ("prepare", None),
                "source_excluded_reformation": ("prepare_reformation", "reformation_root"),
                "quote_gap_repair": ("prepare_quote_gap_repair", "quote_gap_root"),
            }[task.reason]
            if root_role is not None and not callable(getattr(provider, prepare_name, None)):
                raise FormationStopped("deferred", "quote_gap_repair_provider_unsupported" if task.reason == "quote_gap_repair" else "reformation_provider_unsupported")
            budget = self.maintenance.budget_status(window_id)
            report = replace(report, budget=budget)
            self._check_budget(budget, now_ms)
            self._current(access, task)
            if work_class == "cold" and self.maintenance.cold_status(now_ms, max_runs=cold_max_runs).remaining == 0:
                raise FormationStopped("blocked", "cold_quota_exhausted")
            task, read_source = self._prepare_source_inputs(access, task, window_id=window_id,
                max_events=max_events, max_sources=max_sources, max_attempts=max_attempts, target_uses=target_uses)
            report = replace(report, task_id=task.task_id)
            if task.state == "done":
                return self._resume(access, task.task_id, report)
            texts, visible, aliases, raw = {}, [], {}, []
            contents = {} if self.source_guard is not None else None
            chars = bytes_used = 0
            for index, item in enumerate(task.inputs):
                self._allowed()
                self.require_resources()
                self._current(access, task)
                try:
                    content = read_source(item, max_chars=self.limits.source_chars-chars, max_bytes=self.limits.source_bytes-bytes_used)
                except Exception:
                    raise FormationStopped("failed", "source_reader_failed") from None
                if not isinstance(content, SourceContent):
                    raise FormationStopped("failed", "invalid_source_content")
                try:
                    _validate_source(content.source)
                except MemoryValidationError:
                    raise FormationStopped("failed", "invalid_source_content") from None
                if (content.source != item.source or not isinstance(content.text, str)
                        or not content.text or not isinstance(content.speaker_role, str) or len(content.speaker_role) > 64
                        or (content.speaker_ref is not None and (not isinstance(content.speaker_ref, str) or len(content.speaker_ref) > 256))):
                    raise FormationStopped("failed", "invalid_source_content")
                chars += len(content.text)
                try:
                    bytes_used += len(content.text.encode("utf-8"))
                except UnicodeError:
                    raise FormationStopped("failed", "invalid_source_content") from None
                if chars > self.limits.source_chars or bytes_used > self.limits.source_bytes:
                    raise FormationStopped("blocked", "source_limit_exceeded")
                self._allowed()
                self._current(access, task)
                alias = "s" + str(index)
                aliases[alias] = item.source
                texts[item.source] = content.text
                if contents is not None:
                    contents[item] = content
                visible.append(FormationSource(alias, content.text, content.speaker_role, content.speaker_ref, item.recorded_at_ms,
                    root_role if root_role is not None else task.input_roles[index]))
                if materialize_raw:
                    try:
                        raw.append(self.retrieval.materialize_source(access, item, content.text))
                        report = replace(report, raw=tuple(raw))
                    except MemoryNotFound:
                        pass
            report = replace(report, raw=tuple(raw))
            self._allowed()
            self.require_resources()
            self._current(access, task)
            try:
                if self.provider is not provider:
                    raise FormationStopped("failed", "provider_configuration_mismatch")
                provider_pipeline = provider.pipeline_version
                prepare = getattr(provider, prepare_name)
                call = prepare(tuple(visible), max_output_tokens=self.limits.max_usage.output_tokens, timeout_ms=self.limits.timeout_ms)
            except FormationStopped:
                raise
            except Exception:
                raise FormationStopped("failed", "request_prepare_failed") from None
            if (self.provider is not provider or provider_pipeline != pipeline_version or provider.pipeline_version != provider_pipeline
                    or not isinstance(call, PreparedCall) or call.pipeline_version != pipeline_version or type(call.payload) is not bytes):
                raise FormationStopped("failed", "provider_configuration_mismatch")
            try:
                _usage(call.reserved)
            except MemoryValidationError:
                raise FormationStopped("failed", "invalid_request_reservation") from None
            if any(getattr(call.reserved, field) > getattr(self.limits.max_usage, field) for field in ("input_tokens", "output_tokens", "cost_units")):
                raise FormationStopped("blocked", "request_limit_exceeded")
            self._allowed()
            self.require_resources()
            self._current(access, task)
            reservation = self.maintenance.reserve_attempt(access, task.task_id, reservation_key=reservation_key, window_id=window_id, reserved=call.reserved, now_ms=self._now(), cold_max_runs=cold_max_runs)
            report = replace(report, attempt=reservation.attempt)
            if reservation.replayed:
                return self._report(replace(report, stage="replayed", code=reservation.attempt.outcome), access)
            owns_reservation = True
            self._allowed()
            self.require_resources()
            self._current(access, task)
            if self.provider is not provider or provider.pipeline_version != provider_pipeline:
                raise FormationStopped("failed", "provider_configuration_mismatch")
            with self._source_boundary(access, task, contents, require_ready=True):
                self.maintenance.validate_dispatch(access, report.attempt.attempt_id, now_ms=self._now(), cold_max_runs=cold_max_runs)
            sent = True
            report = replace(report, generated=True)
            try:
                result = provider.generate(call.payload, max_output_tokens=call.reserved.output_tokens, timeout_ms=self.limits.timeout_ms)
            except Exception:
                raise FormationStopped("unknown", "provider_call_failed") from None
            if not isinstance(result, ProviderResult):
                raise FormationStopped("failed", "invalid_provider_result")
            if result.actual is not None:
                try:
                    _usage(result.actual)
                except MemoryValidationError:
                    raise FormationStopped("failed", "invalid_provider_usage") from None
                report = replace(report, actual=result.actual)
                self.maintenance.settle_usage(access, report.attempt.attempt_id, result.actual)
            if self.provider is not provider or provider.pipeline_version != provider_pipeline:
                raise FormationStopped("failed", "provider_configuration_mismatch")
            if result.actual is not None and any(getattr(result.actual, field) > getattr(call.reserved, field) for field in ("input_tokens", "output_tokens", "cost_units")):
                raise FormationStopped("failed", "provider_reservation_exceeded")
            self._allowed()
            self._current(access, task)
            if result.finish != "stop":
                raise FormationStopped("truncated" if result.finish == "length" else "unknown" if result.finish == "unknown" else "failed", "provider_incomplete")
            if not isinstance(result.content, str) or len(result.content) > self.limits.response_chars:
                raise FormationStopped("truncated", "response_limit_exceeded")
            try:
                drafts = codec(result.content, aliases)
                # Candidate compilation/quote location occurs outside its write
                # transaction and commit rechecks the fixed task afterwards.
                self._allowed()
                now_ms = self._now()
                if drafts:
                    committed = self.candidates.commit(access, report.attempt.attempt_id, drafts, canonical_texts=texts, now_ms=now_ms,
                        isolate_quote_failures=self.isolate_quote_failures and task.advances_cursor,
                        guard=lambda: self._source_boundary(access, task, contents))
                    report = replace(report, quote_failures=committed.quote_failures)
                    if committed.status != "committed":
                        raise FormationStopped("stale", "source_snapshot_changed")
                else:
                    with self._source_boundary(access, task, contents):
                        committed = self.maintenance.complete_no_candidates(access, report.attempt.attempt_id)
                    if not committed.committed:
                        raise FormationStopped("stale", "source_snapshot_changed")
            except MemoryValidationError:
                raise FormationStopped("failed", "invalid_formation_batch") from None
            return self._resume(access, task.task_id, report, contents=contents)
        except FormationStopped as stop:
            report = replace(report, stage=stop.stage, code=stop.code)
        except (MemoryConflict, MemoryValidationError, MemoryNotFound) as error:
            code = str(error)
            known = {"budget_exhausted", "outside_budget_window", "task_attempts_exhausted", "task_not_reservable", "attempt_not_dispatchable", "clock_rollback", "store_closed", "stream_task_active"}
            known.update({"source_limit_exceeded", "context_snapshot_conflict", "context_inputs_conflict", "context_snapshot_stale"})
            known.update({"cold_quota_exhausted", "task_work_class_conflict", "invalid_work_class", "invalid_cold_max_runs", "cold_attempt_already_dispatched"})
            known.update({"invalid_target_uses", "task_target_uses_conflict", "context_target_uses_not_allowed"})
            report = replace(report, stage="stale" if code == "context_snapshot_stale" else "blocked" if code in known else "failed", code=code if code in known or code == "invalid_context_inputs" else "store_or_contract_failed")
        except Exception:
            report = replace(report, stage="failed", code="store_closed" if self.store._closed else "store_or_contract_failed")
        finally:
            if owns_reservation and report.attempt is not None:
                try:
                    current = self.maintenance.attempt(access, report.attempt.attempt_id)
                    if current.outcome == "reserved":
                        outcome = report.stage if report.stage in ("unknown", "truncated") else "failed"
                        self.maintenance.finish_attempt(access, current.attempt_id, outcome=outcome, actual=Usage() if not sent else report.actual)
                except Exception:
                    pass  # A closed owner cannot write; return late actual usage.
        if report.task_id and not self.store._closed:
            try:
                report = self._raw_work(access, self.maintenance.task(access, report.task_id), report)
            except Exception:
                report = replace(report, post_pending=bool(report.raw) or report.post_pending)
        return self._report(report, access)

    def resume(self, access: AccessScope, task_id: str, *,
               references: tuple[CandidateReference, ...] | None = None) -> StepReport:
        if self.access_scope is not None and self.access_scope != access:
            return StepReport("denied", "formation_scope_mismatch", task_id=task_id)
        if not self.store._formation_lock.acquire(blocking=False):
            return StepReport("busy", "formation_busy", task_id=task_id)
        report = StepReport("pending", task_id=task_id)
        try:
            self._limits()
            self._allowed()
            return self._resume(access, task_id, report, references)
        except FormationStopped as stop:
            return self._report(replace(report, stage=stop.stage, code=stop.code, post_pending=True), access)
        except Exception:
            return self._report(replace(report, stage="deferred", code="postprocessing_failed", post_pending=True), access)
        finally:
            self.store._formation_lock.release()

    def _resume(self, access, task_id, report, references=None, *, contents=None):
        task = self.maintenance.task(access, task_id)
        attempt = self.maintenance.current_attempt(access, task_id)
        report = replace(report, task_id=task_id, attempt=attempt)
        if task.state == "abandoned":
            return self._raw_work(access, task, replace(report, stage="abandoned", code="formation_coverage_gap"))
        if task.state != "done":
            return self._raw_work(access, task, replace(report, stage="replayed", code=attempt.outcome if attempt else task.state))
        if attempt is None or attempt.outcome == "no_candidates":
            return self._raw_work(access, task, replace(report, stage="done", code="no_candidates"))
        if attempt.outcome != "candidates":
            return self._raw_work(access, task, replace(report, stage="replayed", code=attempt.outcome))
        refs = self.candidates.result(access, attempt.attempt_id).candidates
        report = replace(report, candidates=refs)
        selected = refs
        if references is not None:
            references = tuple(references)
            if len(references) > 64 or any(not isinstance(ref, CandidateReference) or ref not in refs for ref in references):
                raise FormationStopped("deferred", "invalid_postprocessing_references")
            selected = tuple(dict.fromkeys(references))
        report = replace(report, remaining=selected)
        try:
            self._allowed()
            self.require_resources()
            report = replace(report, raw=self.retrieval.source_references(access, task.inputs))
            published, review = [], []
            pending = False
            processed = 0
            for ref in selected:
                if processed >= self.limits.post_limit:
                    break
                self._allowed()
                self.require_resources()
                try:
                    candidate = self.candidates.detail(access, ref.candidate_id)
                except MemoryNotFound:
                    report = replace(report, remaining=tuple(r for r in report.remaining if r != ref))
                    continue
                if candidate.state not in ("pending", "published", "accepted"):
                    report = replace(report, remaining=tuple(r for r in report.remaining if r != ref))
                    continue
                processed += 1
                deferred_decision = False
                if candidate.state == "pending" and self.selector is not None and task.reason != "quote_gap_repair":
                    try:
                        decision = self.selector(candidate)
                    except Exception:
                        raise FormationStopped("deferred", "adoption_selector_failed") from None
                    if decision is not None:
                        if not isinstance(decision, AdoptionDecision):
                            raise FormationStopped("deferred", "invalid_adoption_decision")
                        self._allowed()
                        self.require_resources()
                        try:
                            self.candidates.publish_derived(access, candidate.candidate_id, candidate.row_version,
                                authorization_id=decision.authorization_id, expected_generation=decision.generation,
                                operation_id="formation-adoption:" + attempt.attempt_id, item_id=candidate.candidate_id,
                                memory_kind=decision.memory_kind, uses=decision.uses, now_ms=self._now(),
                                guard=lambda: self._source_boundary(access, task, contents, require_ready=True))
                        except (MemoryConflict, MemoryNotFound, MemoryValidationError):
                            deferred_decision = True
                        try:
                            candidate = self.candidates.detail(access, candidate.candidate_id)
                        except MemoryNotFound:
                            report = replace(report, remaining=tuple(r for r in report.remaining if r != ref))
                            continue
                pending = pending or deferred_decision
                if candidate.state == "pending":
                    review.append(CandidateReference(candidate.candidate_id, candidate.row_version))
                elif candidate.state in ("published", "accepted") and candidate.memory_id:
                    try:
                        memory = self.store.detail(access, candidate.memory_id).memory
                    except MemoryNotFound:
                        report = replace(report, remaining=tuple(r for r in report.remaining if r != ref))
                        continue
                    if memory.state == "active" and memory.invalid_reason is None:
                        published.append(RecallReference(memory.memory_id, memory.row_version))
                report = replace(report, published=tuple(published))
                if not deferred_decision:
                    report = replace(report, remaining=tuple(r for r in report.remaining if r != ref))
            report = replace(report, post_pending=pending or bool(report.remaining))
            projections = self.retrieval.materialize_candidates(access, review) if review else ()
            self._allowed()
            self.require_resources()
            if self.store._embedder is None:
                return self._report(replace(report, stage="done", code="embedding_unavailable", post_pending=bool(projections or published) or report.post_pending), access)
            remaining = self.limits.max_chunks
            if projections or report.raw:
                result, incomplete, index_pending = self._index_retrieval(access, (*projections, *report.raw))
                # One bounded embedding channel per resume; M1 follows on the
                # next wake when a review/raw index batch consumed this budget.
                report = replace(report, post_pending=report.post_pending or incomplete)
                if result is not None and (result.attempted or result.busy):
                    published_states = tuple(self.store.detail(access, ref.memory_id).memory.index_state for ref in published)
                    pending = incomplete or any(state != "ready" for state in published_states) or report.post_pending
                    return self._report(replace(report, stage="done", code="index_pending" if pending else None,
                        post_pending=pending, index_followup=self._index_followup(result,
                            index_pending or "pending" in published_states)), access)
            if published:
                pending = tuple(ref for ref in published if self.store.detail(access, ref.memory_id).memory.index_state == "pending")
                second = self.store.run_index_batch(access=access, references=pending, limit=self.limits.post_limit, max_chunks=remaining) if pending else None
                incomplete = any(self.store.detail(access, ref.memory_id).memory.index_state != "ready" for ref in published)
                report = replace(report, post_pending=report.post_pending or incomplete)
                return self._report(replace(report, stage="done", code="index_pending" if report.post_pending else None,
                    index_followup=self._index_followup(second, any(
                        self.store.detail(access, ref.memory_id).memory.index_state == "pending" for ref in published))), access)
            return self._report(replace(report, stage="done", code="index_pending" if report.post_pending else None), access)
        except FormationStopped as stop:
            return self._report(replace(report, stage=stop.stage, code=stop.code, post_pending=True), access)
        except Exception:
            return self._report(replace(report, stage="deferred", code="postprocessing_failed", post_pending=True), access)

    def _cache_states(self, references):
        with self.store._lock:
            self.store._check()
            states = []
            for ref in dict.fromkeys(references):
                row = self.store._db.execute("SELECT index_state FROM retrieval_documents WHERE document_key=? AND target_kind=? AND target_version=?", (ref.document_key, ref.target_kind, ref.target_version)).fetchone()
                if row is not None:
                    states.append((ref, row[0]))
            return states

    def _index_retrieval(self, access, references):
        # Already ready documents never occupy a target/batch slot; failed work
        # stays observable without silently becoming another embedding attempt.
        states = self._cache_states(references)
        pending = tuple(ref for ref, state in states if state == "pending")
        result = self.retrieval.run_index_batch(access=access, references=pending[:1000],
            limit=self.limits.post_limit, max_chunks=self.limits.max_chunks) if pending else None
        states = self._cache_states(references)
        return result, any(state != "ready" for _, state in states), any(state == "pending" for _, state in states)

    @staticmethod
    def _index_followup(result, pending):
        if not pending:
            return None
        if result is not None and result.busy:
            return "busy"
        # A failed item also leaves pending exactly once. Continue only when
        # another pending item can use the next bounded unit; never retry failed.
        if pending and result is not None and (result.indexed or result.failed):
            return "progress"
        return None

    def _raw_work(self, access, task, report):
        try:
            self._allowed()
            report = replace(report, raw=self.retrieval.source_references(access, task.inputs))
            if not report.raw:
                return self._report(report, access)
            self.require_resources()
            if self.store._embedder is None:
                return self._report(replace(report, post_pending=True), access)
            result, incomplete, pending = self._index_retrieval(access, report.raw)
            return self._report(replace(report, post_pending=report.post_pending or incomplete,
                index_followup=self._index_followup(result, pending)), access)
        except FormationStopped:
            return self._report(replace(report, post_pending=bool(report.raw) or report.post_pending), access)
        except Exception:
            return self._report(replace(report, post_pending=bool(report.raw) or report.post_pending), access)
