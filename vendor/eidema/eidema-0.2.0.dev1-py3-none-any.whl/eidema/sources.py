"""Source shape validation and exact quotes in Host-owned canonical text."""
from __future__ import annotations

from .models import MemoryValidationError, SourceSpan


def _identity(value: str) -> None:
    if not isinstance(value, str) or not value.strip() or len(value) > 2048:
        raise MemoryValidationError("invalid_identity")


def _validate_source(source):
    if source is not None:
        if not isinstance(source, SourceSpan):
            raise MemoryValidationError("invalid_source")
        _identity(source.namespace)
        _identity(source.record_key)
        if not isinstance(source.revision, int) or isinstance(source.revision, bool) or source.revision < 1:
            raise MemoryValidationError("invalid_source_revision")
        if (source.start_cp is None) != (source.end_cp is None):
            raise MemoryValidationError("invalid_source_span")
        if source.start_cp is not None and (not isinstance(source.start_cp, int)
                or not isinstance(source.end_cp, int) or isinstance(source.start_cp, bool)
                or isinstance(source.end_cp, bool) or not 0 <= source.start_cp < source.end_cp):
            raise MemoryValidationError("invalid_source_span")


def locate_source_quote(source: SourceSpan, source_text: str, quote: str) -> SourceSpan:
    """Locate one exact quote in a whole canonical record, in codepoints.

    The Host owns the text projection, identity, revision and permissions. This
    pure function checks shape and unique location, not semantic support or
    whether the supplied source is current or authorized.
    """
    _validate_source(source)
    if source is None:
        raise MemoryValidationError("invalid_source")
    if source.start_cp is not None:
        raise MemoryValidationError("quote_requires_whole_source")
    if not isinstance(source_text, str):
        raise MemoryValidationError("invalid_source_text")
    if not isinstance(quote, str) or not quote:
        raise MemoryValidationError("invalid_quote")
    start = source_text.find(quote)
    if start < 0:
        raise MemoryValidationError("quote_not_found")
    # Advancing one codepoint also detects overlapping occurrences: aa in aaa.
    if source_text.find(quote, start + 1) >= 0:
        raise MemoryValidationError("quote_not_unique")
    return SourceSpan(source.namespace, source.record_key, source.revision, start, start + len(quote))
