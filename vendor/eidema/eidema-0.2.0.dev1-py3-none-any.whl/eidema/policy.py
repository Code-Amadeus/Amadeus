"""SDK DTO adapters for the single stdlib policy metadata implementation."""
from .models import SourceSpan, SourceRetirement, SourcePolicySnapshot
from . import policy_metadata as _raw


def _exclusions(db, user_id):
    return tuple(SourceSpan(*row) for row in _raw._exclusion_rows(db, user_id))


def _retirements(db, user_id):
    return tuple(SourceRetirement(SourceSpan(*row[:5]), row[5]) for row in _raw._retirement_rows(db, user_id))


def _outputs(db, user_id):
    return tuple(SourceSpan(*row) for row in _raw._output_rows(db, user_id))


def _snapshot(db, user_id):
    return SourcePolicySnapshot(_exclusions(db, user_id), _retirements(db, user_id),
        db.execute("SELECT change_seq FROM store_state WHERE singleton=1").fetchone()[0])


def read_source_policy_metadata(db, user_id):
    value = _raw.read_source_policy_metadata(db, user_id)
    snapshot = SourcePolicySnapshot(tuple(SourceSpan(*row) for row in value["exclusions"]),
        tuple(SourceRetirement(SourceSpan(*row[:5]),row[5]) for row in value["retirements"]), value["change_seq"])
    return snapshot, tuple(SourceSpan(*row) for row in value["outputs"]), value["owner_namespaces"]
