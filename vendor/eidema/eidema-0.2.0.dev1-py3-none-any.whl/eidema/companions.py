"""Content-free companions nominated by committed, causally prior use.

This is a formation-material opportunity, never semantic identity/adoption.
The trusted Host supplies one comparable transaction-order coordinate. Its
callbacks run outside the Store lock; no candidate/source body is selected.
"""
from dataclasses import dataclass
from typing import Literal, Protocol

from .models import SourceSpan, MemoryScope, MemoryConflict, MemoryValidationError, MemoryNotFound
from .maintenance import SourceInput, _validate_input, _target_use_mask


@dataclass(frozen=True)
class CommitCoordinate:
    journal_id: str
    order: int


@dataclass(frozen=True)
class CommitEvidence:
    status: Literal["committed", "unwitnessed", "unknown"]
    coordinate: CommitCoordinate | None = None


class CommittedUseReader(Protocol):
    """Trusted source owner; serialize canonical writes across the operation.

    An output witness attests an atomic canonical/outbox commit through the
    output-registration protocol. It is not a UI display or user-read receipt.
    Unknown legacy facts must not be inferred from wall/source timestamps.
    """
    def source_commit(self, access, item: SourceInput) -> CommitEvidence: ...
    def output_commit(self, access, source: SourceSpan) -> CommitEvidence: ...
    def authorized(self) -> bool: ...


@dataclass(frozen=True)
class UsedCompanions:
    """Only currently readable pins; no retired root/output identities."""
    incoming: SourceInput
    groups: tuple[tuple[SourceInput, ...], ...]
    target_uses: tuple[str, ...]
    status: Literal["ready", "not_replacement", "no_companions", "unknown_commit_order"]

    @property
    def companions(self):
        """Compatibility projection: first occurrence of each whole pin.

        Anonymous necessary groups are the only source of truth. This flat
        projection is safe for the original all-or-fail reader, not pruning.
        """
        return tuple(dict.fromkeys(pin for group in self.groups for pin in group))


def _coordinate(evidence):
    if not isinstance(evidence, CommitEvidence) or evidence.status not in ("committed", "unwitnessed", "unknown"):
        raise MemoryValidationError("invalid_commit_evidence")
    c = evidence.coordinate
    if evidence.status == "committed":
        if (not isinstance(c, CommitCoordinate) or not isinstance(c.journal_id, str)
                or not c.journal_id or type(c.order) is not int or c.order < 1):
            raise MemoryValidationError("invalid_commit_coordinate")
        return c
    if c is not None:
        raise MemoryValidationError("unexpected_commit_coordinate")
    return None


def _incoming(maintenance, access, incoming, mask):
    _validate_input(incoming)
    row = maintenance._formation_row(access, incoming.source)
    stream = maintenance._stream(access, row["stream_id"])
    scope = MemoryScope(stream["scope_kind"], stream["user_id"], stream["character_id"], stream["project_id"])
    if (row["state_version"], row["policy_revision"], row["recorded_at_ms"]) != (incoming.state_version, incoming.policy_revision, incoming.recorded_at_ms):
        raise MemoryConflict("stale_source_input")
    # A known derived/registered output is not an ordinary canonical revision.
    # Reject before graph traversal could enumerate a historical body.
    if maintenance._store._known_output(access.user_id, incoming.source):
        return row, scope, None
    maintenance._source_scope(access, row)
    if not maintenance._planning_allows(access, row, scope, mask):
        raise MemoryConflict("companion_purpose_unavailable")
    old = maintenance._db.execute(
        "SELECT revision,action,formation_allowed,lookup_allowed,derived_use_mask,policy_revision FROM source_changes "
        "WHERE stream_id=? AND namespace=? AND record_key=? AND position<? ORDER BY position DESC LIMIT 1",
        (row["stream_id"], incoming.source.namespace, incoming.source.record_key, incoming.state_version)).fetchone()
    ordinary = (old is not None and old["action"] == row["action"] == "upsert"
                and old["revision"] < row["revision"]
                and all(old[k] == row[k] for k in ("formation_allowed", "lookup_allowed", "derived_use_mask", "policy_revision"))
                )
    return row, scope, old["revision"] if ordinary else None


def _roots(maintenance, access, source, old_revision, scope):
    where, params = maintenance._store._where(access, "s")
    rows = maintenance._db.execute(
        "SELECT DISTINCT c.candidate_id,r.row_version,r.namespace,r.record_key,r.revision "
        "FROM candidate_evidence e JOIN candidates c ON c.candidate_id=e.candidate_id "
        "JOIN formation_tasks t ON t.task_id=c.task_id JOIN source_streams s ON s.stream_id=t.stream_id "
        "JOIN output_candidate_reads r ON r.candidate_id=c.candidate_id AND r.user_id=s.user_id "
        "JOIN output_bindings b ON b.user_id=r.user_id AND b.namespace=r.namespace AND b.record_key=r.record_key AND b.revision=r.revision "
        "WHERE e.namespace=? AND e.record_key=? AND e.revision=? AND e.role='support' AND " + where +
        " AND b.privacy_invalidated=0 AND (b.invalid_reason IS NULL OR b.invalid_reason='source_retired') "
        "AND (c.invalid_reason IS NULL OR c.invalid_reason='source_retired') "
        "ORDER BY c.candidate_id,r.namespace,r.record_key,r.revision",
        (source.namespace, source.record_key, old_revision, *params)).fetchall()
    # Containment is a metadata check, independent of a body's retired version.
    accepted = []
    for r in rows:
        parent = maintenance._db.execute(
            "SELECT s.* FROM candidates c JOIN formation_tasks t ON t.task_id=c.task_id "
            "JOIN source_streams s ON s.stream_id=t.stream_id WHERE c.candidate_id=?", (r["candidate_id"],)).fetchone()
        if maintenance._store._scope_contains(parent, scope):
            accepted.append(tuple(r))
    return tuple(accepted)


def nominate(maintenance, access, incoming, commits, *, target_uses=("lookup",)):
    mask = _target_use_mask(target_uses)
    uses = tuple(k for k, bit in (("lookup", 1), ("ordinary", 2)) if mask & bit)
    store = maintenance._store
    with store._lock:
        store._check()
        _, scope, old_revision = _incoming(maintenance, access, incoming, mask)
        if old_revision is None:
            return UsedCompanions(incoming, (), uses, "not_replacement")
        roots = _roots(maintenance, access, incoming.source, old_revision, scope)
    # Host/Store lock order stays Host -> Store. Never call a Host under Store.
    source_evidence = commits.source_commit(access, incoming)
    source_order = _coordinate(source_evidence)
    if source_order is None:
        return UsedCompanions(incoming, (), uses, "unknown_commit_order")
    witnesses = []
    unknown = False
    for cid, version, ns, key, revision in roots:
        evidence = commits.output_commit(access, SourceSpan(ns, key, revision))
        coord = _coordinate(evidence)
        if evidence.status == "unknown":
            unknown = True
        elif coord is not None:
            if coord.journal_id != source_order.journal_id:
                unknown = True
            elif coord.order < source_order.order:
                witnesses.append((coord.order, cid))
    if not commits.authorized():
        raise MemoryConflict("companion_authority_unavailable")
    with store._lock:
        store._check()
        _, current_scope, current_old = _incoming(maintenance, access, incoming, mask)
        if (current_old != old_revision or _roots(maintenance, access, incoming.source, old_revision, current_scope) != roots):
            raise MemoryConflict("companion_evidence_changed")
        latest = {}
        for order, cid in witnesses:
            latest[cid] = max(latest.get(cid, 0), order)
        # An unproven extra edge grants nothing, but cannot negate a separate
        # proven prior use. Ordering/capping below uses only the proven subset;
        # this does not assert that all historical uses are known.
        if not latest and unknown:
            return UsedCompanions(incoming, (), uses, "unknown_commit_order")
        groups, selected, seen = [], [], set()
        for cid in sorted(latest, key=lambda k: (-latest[k], k)):
            rows = maintenance._db.execute(
                "SELECT namespace,record_key,revision FROM candidate_evidence WHERE candidate_id=? AND role='support' "
                "ORDER BY ordinal", (cid,)).fetchall()
            group, distinct = [], set()
            eligible = True
            for r in rows:
                source = SourceSpan(*r)
                if (source.namespace, source.record_key) == (incoming.source.namespace, incoming.source.record_key) or source in distinct:
                    continue
                distinct.add(source)
                if store._known_output(access.user_id, source):
                    eligible = False
                    break
                try:
                    pin = maintenance.formation_input(access, source)
                    row = maintenance._formation_row(access, source)
                    if not maintenance._planning_allows(access, row, current_scope, mask):
                        eligible = False
                        break
                except (MemoryConflict, MemoryNotFound, MemoryValidationError):
                    eligible = False
                    break
                group.append(pin)
            fresh = [pin for pin in group if pin.source not in seen]
            if not eligible or not group or len(selected) + len(fresh) > 2:
                continue
            if tuple(group) not in groups:
                groups.append(tuple(group))
            selected.extend(fresh)
            seen.update(pin.source for pin in fresh)
        return UsedCompanions(incoming, tuple(groups), uses, "ready" if groups else "no_companions")


def revalidate(maintenance, access, proposal, commits):
    if not isinstance(proposal, UsedCompanions) or proposal.status != "ready":
        raise MemoryValidationError("ready_used_companions_required")
    current = nominate(maintenance, access, proposal.incoming, commits, target_uses=proposal.target_uses)
    if current != proposal:
        raise MemoryConflict("used_companions_changed")
    return proposal.companions
