"""Optional metadata journal inside a Host-owned SQLite transaction.

The Host owns serialization, canonical bodies and stable stream positions.
This helper borrows its connection; it never acquires an Eidema connection.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass
import sqlite3
from typing import Sequence
from uuid import uuid4

from .maintenance import Maintenance, SourceChange, StreamProgress, _change_batch, _change_metadata, _integer
from .models import AccessScope, MemoryScope, SourceSpan, MemoryConflict, MemoryNotFound, MemoryValidationError
from .sources import _identity


@dataclass(frozen=True)
class SourceDelivery:
    stream_id: str
    committed_position: int
    receiver: StreamProgress
    delivered: int
    caught_up: bool


def _change(row):
    return SourceChange(row[0], SourceSpan(*row[1:4]), row[4], bool(row[5]), row[6], row[7], bool(row[8]), row[9], bool(row[10]))


class SourceOutbox:
    """Content-free, immutable source changes; no persisted sender ACK.

    Construction performs no SQL. Initialize and append require a caller-owned
    transaction. Deliver requires that transaction to have been committed.
    The caller must serialize source writes and delivery/consumption.
    """

    def __init__(self, connection: sqlite3.Connection):
        self._db = connection

    def _query(self, sql, values=()):
        # Respect the connection's row factory, including custom Host factories,
        # by selecting tuple rows only on this helper's private cursor.
        cursor = self._db.cursor()
        cursor.row_factory = None
        try:
            cursor.execute(sql, values)
            return cursor.fetchall()
        finally:
            cursor.close()

    @contextmanager
    def _batch(self):
        if not self._db.in_transaction:
            raise MemoryConflict("caller_transaction_required")
        savepoint = "eidema_outbox_" + uuid4().hex
        self._query("SAVEPOINT " + savepoint)
        try:
            yield
        except BaseException:
            self._query("ROLLBACK TO " + savepoint)
            raise
        finally:
            self._query("RELEASE " + savepoint)

    def _has_evidence_only(self):
        return any(row[1] == "evidence_only" for row in self._query(
            "PRAGMA table_info(eidema_source_outbox_changes)"))

    def _upgrade_changes(self):
        if not self._has_evidence_only():
            self._query("ALTER TABLE eidema_source_outbox_changes ADD COLUMN evidence_only "
                        "INTEGER NOT NULL DEFAULT 0 CHECK(evidence_only IN (0,1))")

    def initialize(self, stream_id: str, scope: MemoryScope) -> None:
        """Create journal tables and permanently bind this stream to its scope."""
        _identity(stream_id)
        if not isinstance(scope, MemoryScope) or scope.kind not in ("shared", "character", "project"):
            raise MemoryValidationError("invalid_source_scope")
        _identity(scope.user_id)
        if scope.kind == "shared":
            valid = scope.character_id is None and scope.project_id is None
        elif scope.kind == "character":
            _identity(scope.character_id)
            valid = scope.project_id is None
        else:
            _identity(scope.character_id)
            _identity(scope.project_id)
            valid = True
        if not valid:
            raise MemoryValidationError("invalid_source_scope")
        values = (scope.kind, scope.user_id, scope.character_id, scope.project_id)
        with self._batch():
            self._query("""CREATE TABLE IF NOT EXISTS eidema_source_outbox_streams (
                stream_id TEXT PRIMARY KEY, scope_kind TEXT NOT NULL, user_id TEXT NOT NULL,
                character_id TEXT, project_id TEXT)""")
            self._query("""CREATE TABLE IF NOT EXISTS eidema_source_outbox_changes (
                stream_id TEXT NOT NULL REFERENCES eidema_source_outbox_streams(stream_id),
                position INTEGER NOT NULL, namespace TEXT NOT NULL, record_key TEXT NOT NULL,
                revision INTEGER NOT NULL, action TEXT NOT NULL, formation_allowed INTEGER NOT NULL,
                policy_revision TEXT NOT NULL, recorded_at_ms INTEGER, lookup_allowed INTEGER NOT NULL,
                derived_use_mask INTEGER NOT NULL, evidence_only INTEGER NOT NULL DEFAULT 0 CHECK(evidence_only IN (0,1)),
                PRIMARY KEY(stream_id,position))""")
            self._upgrade_changes()
            old = self._query("SELECT scope_kind,user_id,character_id,project_id FROM eidema_source_outbox_streams WHERE stream_id=?", (stream_id,))
            if old:
                if old[0] != values:
                    raise MemoryConflict("stream_scope_conflict")
            else:
                self._query("INSERT INTO eidema_source_outbox_streams VALUES(?,?,?,?,?)", (stream_id, *values))

    def _bound(self, stream_id):
        _identity(stream_id)
        rows = self._query("SELECT scope_kind,user_id,character_id,project_id FROM eidema_source_outbox_streams WHERE stream_id=?", (stream_id,))
        if not rows:
            raise MemoryNotFound("outbox_stream_not_found")
        return MemoryScope(*rows[0])

    def _high_water(self, stream_id):
        return self._query("SELECT COALESCE(MAX(position),0) FROM eidema_source_outbox_changes WHERE stream_id=?", (stream_id,))[0][0]

    def append(self, stream_id: str, changes: Sequence[SourceChange]) -> int:
        """Append beside the canonical Host mutation in the same transaction.

        Exact same-position metadata replay is free. Any batch failure rolls
        back only this helper's savepoint; the caller still owns its transaction.
        """
        _identity(stream_id)
        changes = _change_batch(changes)
        with self._batch():
            self._bound(stream_id)
            self._upgrade_changes()
            position = self._high_water(stream_id)
            for change in changes:
                metadata = _change_metadata(change)
                if change.position <= position:
                    old = self._query("SELECT namespace,record_key,revision,action,formation_allowed,policy_revision,recorded_at_ms,lookup_allowed,derived_use_mask,evidence_only FROM eidema_source_outbox_changes WHERE stream_id=? AND position=?", (stream_id, change.position))
                    if not old or old[0] != metadata:
                        raise MemoryConflict("feed_position_conflict")
                else:
                    if change.position != position + 1:
                        raise MemoryConflict("feed_gap_or_order")
                    self._query("INSERT INTO eidema_source_outbox_changes(stream_id,position,namespace,record_key,revision,action,formation_allowed,policy_revision,recorded_at_ms,lookup_allowed,derived_use_mask,evidence_only) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)", (stream_id, change.position, *metadata))
                    position = change.position
            return position

    def deliver(self, access: AccessScope, maintenance: Maintenance, stream_id: str,
                pipeline_version: str, *, limit: int = 100) -> SourceDelivery:
        """Deliver one bounded committed prefix through public receiver APIs.

        Receiver received_position is the only acknowledgement. A lost return
        is reconciled on the next call. caught_up covers delivery, not successful
        formation, and is valid only while the caller retains serialization.
        """
        _integer(limit, "delivery_limit", 1, 1000)
        _identity(pipeline_version)
        if self._db.in_transaction:
            raise MemoryConflict("uncommitted_source_transaction")
        scope = self._bound(stream_id)
        high_water = self._high_water(stream_id)
        maintenance.register_stream(access, stream_id, scope)
        progress = maintenance.progress(access, stream_id, pipeline_version)
        if progress.received_position > high_water:
            raise MemoryConflict("receiver_ahead_of_outbox")
        # A receiver restored/rebound to a different journal must not acknowledge
        # our head by position alone. Replay one exact acknowledged boundary;
        # older prefix integrity remains the Host immutable-journal invariant.
        # Delivery may reopen an old journal before the next Host write.
        flag = "evidence_only" if self._has_evidence_only() else "0"
        fields = ("SELECT position,namespace,record_key,revision,action,formation_allowed,"
                  "policy_revision,recorded_at_ms,lookup_allowed,derived_use_mask," + flag
                  + " FROM eidema_source_outbox_changes WHERE stream_id=? AND position")
        if progress.received_position:
            boundary = self._query(fields + "=?", (stream_id, progress.received_position))
            if not boundary:
                raise MemoryConflict("feed_position_conflict")
            maintenance.append_changes(access, stream_id, [_change(boundary[0])])
        rows = self._query(fields + ">? ORDER BY position LIMIT ?", (stream_id, progress.received_position, limit))
        changes = tuple(_change(row) for row in rows)
        if progress.received_position < high_water and not changes:
            raise MemoryConflict("feed_gap_or_order")
        if changes:
            maintenance.append_changes(access, stream_id, changes)
        progress = maintenance.progress(access, stream_id, pipeline_version)
        if progress.received_position > high_water:
            raise MemoryConflict("receiver_ahead_of_outbox")
        return SourceDelivery(stream_id, high_water, progress, len(changes), progress.received_position == high_water)
