"""Rebuildable original-record lookup and explicit pending-proposal review.

The Host supplies canonical source text under a fixed ledger reference. Candidate
text is read only from the authority table. Neither channel adopts a proposal or
participates in M1 recall. All model work borrows the store's single resource.
"""
from __future__ import annotations

from contextlib import closing
from dataclasses import dataclass, replace
import heapq
import math
import struct
from typing import Literal, Sequence
from uuid import uuid4

import numpy as np

from .candidates import Candidates, CandidateEvidence, CandidateReference
from .embeddings import normalized
from .maintenance import Maintenance, SourceInput, _integer
from .models import AccessScope, MemoryScope, SourceSpan, MemoryConflict, MemoryNotFound, MemoryValidationError
from .sources import _identity
from .store import _terms


MAX_SOURCE_CHARS = 1_000_000
SOURCE_VECTOR_SCAN_LIMIT = 100_000


@dataclass(frozen=True)
class RetrievalReference:
    document_key: str
    target_kind: Literal["source", "candidate"]
    target_version: int


@dataclass(frozen=True)
class RetrievalItem:
    reference: RetrievalReference
    scope: MemoryScope
    text: str
    condition: str | None
    state: Literal["original", "pending"]
    source: SourceSpan | None = None
    candidate: CandidateReference | None = None
    evidence: tuple[CandidateEvidence, ...] = ()
    semantic_score: float | None = None
    lexical_match: bool = False


@dataclass(frozen=True)
class RetrievalCoverage:
    eligible_targets: int
    materialized_documents: int
    indexed_documents: int
    pending_documents: int
    failed_documents: int
    unmaterialized_targets: int
    semantic: str
    embedding_version: str | None
    scanned_vectors: int = 0
    scan_limited: bool = False
    vectors_omitted: int = 0
    lexical_pool_omitted: int = 0
    semantic_pool_omitted: int = 0
    budget_omitted: int = 0
    invalidated_omitted: int = 0


@dataclass(frozen=True)
class RetrievalResult:
    items: tuple[RetrievalItem, ...]
    coverage: RetrievalCoverage


@dataclass(frozen=True)
class RetrievalIndexResult:
    attempted: int
    indexed: int
    failed: int
    stale: int
    busy: bool = False
    chunk_limited: bool = False
    documents_omitted: int = 0


class Retrieval:
    """An explicitly invoked facade over the MemoryStore owner, never a loop."""

    def __init__(self, store):
        self._store = store
        self._maintenance = Maintenance(store)
        self._candidates = Candidates(store)

    @property
    def _db(self):
        return self._store._db

    @staticmethod
    def _reference(row):
        return RetrievalReference(row["document_key"], row["target_kind"], row["target_version"])

    def _source_input(self, access, item):
        return self._maintenance._lookup_input(access, item, discoverable=True)

    def unmaterialized_sources(self, access: AccessScope, *, limit: int = 16,
                               after: tuple[str, str] | None = None
                               ) -> tuple[tuple[SourceInput, ...], tuple[str, str] | None]:
        """Page current lookup pins without raw text, ordered by binary identity.

        ``after`` is an in-process sweep position, not durable work or authority.
        At most ``limit`` missing-cache rows are scanned; ancestry may deny some
        of them. A full page advances even when no pins survive validation and
        can require one final empty page. Restart from ``None`` to rediscover
        any still-missing work. Materialization revalidates every returned pin.
        """
        self._store._access(access)
        _integer(limit, "source_limit", 1, 100)
        if after is not None:
            if not isinstance(after, tuple) or len(after) != 2:
                raise MemoryValidationError("invalid_source_cursor")
            for value in after:
                _identity(value)
        where, parameters = self._store._where(access, "s")
        if after is not None:
            # source_states' identity primary key uses the schema's BINARY
            # collation; leave its columns bare so SQLite can seek that index.
            where += " AND (q.namespace,q.record_key)>(?,?)"
            parameters += after
        with self._store._lock:
            self._store._check()
            rows = self._db.execute(
                "SELECT q.namespace,q.record_key,q.revision,q.state_version,q.policy_revision,q.recorded_at_ms "
                "FROM source_states q JOIN source_streams s ON s.stream_id=q.stream_id WHERE "
                + where + " AND " + self._maintenance._lookup_eligibility(discoverable=True)
                + " AND NOT EXISTS (SELECT 1 FROM retrieval_documents d WHERE d.target_kind='source' "
                "AND d.namespace=q.namespace AND d.record_key=q.record_key "
                "AND d.revision=q.revision AND d.target_version=q.state_version) "
                "ORDER BY q.namespace COLLATE BINARY,q.record_key COLLATE BINARY LIMIT ?",
                (*parameters, limit)).fetchall()
            inputs = []
            for row in rows:
                item = SourceInput(SourceSpan(row["namespace"], row["record_key"], row["revision"]),
                                   row["state_version"], row["policy_revision"], row["recorded_at_ms"])
                try:
                    self._source_input(access, item)
                except (MemoryNotFound, MemoryConflict):
                    continue
                inputs.append(item)
            next_after = (rows[-1]["namespace"], rows[-1]["record_key"]) if len(rows) == limit else None
            return tuple(inputs), next_after

    def materialize_source(self, access: AccessScope, item: SourceInput, text: str) -> RetrievalReference:
        """Cache one complete Host original; exact fixed-version replay is free."""
        if not isinstance(text, str) or not text or len(text) > MAX_SOURCE_CHARS:
            raise MemoryValidationError("invalid_source_text")
        with self._store._lock:
            self._store._check()
            self._source_input(access, item)
        lexical = " ".join(_terms(text))
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                current = self._source_input(access, item)
                source = item.source
                old = self._db.execute("SELECT * FROM retrieval_documents WHERE target_kind='source' AND namespace=? AND record_key=?", (source.namespace, source.record_key)).fetchone()
                if old is not None:
                    if old["target_version"] != item.state_version or old["body"] != text:
                        raise MemoryConflict("source_projection_conflict")
                    return self._reference(old)
                key = uuid4().hex
                self._db.execute("INSERT INTO retrieval_documents(document_key,target_kind,stream_id,namespace,record_key,revision,target_version,body,lexical_text) VALUES(?,'source',?,?,?,?,?,?,?)",
                                 (key, current["stream_id"], source.namespace, source.record_key, source.revision, item.state_version, text, lexical))
                return RetrievalReference(key, "source", item.state_version)

    def source_references(self, access: AccessScope, inputs: Sequence[SourceInput]) -> tuple[RetrievalReference, ...]:
        """Find existing current raw caches from fixed inputs, without bodies."""
        self._store._access(access)
        inputs = tuple(inputs)
        if len(inputs) > 1000:
            raise MemoryValidationError("invalid_source_inputs")
        with self._store._lock:
            self._store._check()
            refs = []
            for item in dict.fromkeys(inputs):
                try:
                    self._source_input(access, item)
                except (MemoryNotFound, MemoryConflict):
                    continue
                source = item.source
                row = self._db.execute("SELECT document_key,target_kind,target_version FROM retrieval_documents WHERE target_kind='source' AND namespace=? AND record_key=? AND revision=? AND target_version=?", (source.namespace, source.record_key, source.revision, item.state_version)).fetchone()
                if row is not None:
                    refs.append(self._reference(row))
            return tuple(refs)

    def materialize_candidates(self, access: AccessScope, references: Sequence[CandidateReference]) -> tuple[RetrievalReference, ...]:
        """Materialize only current authoritative pending bodies for review."""
        if not isinstance(references, (list, tuple)):
            raise MemoryValidationError("invalid_candidate_references")
        references = tuple(references)
        if not 1 <= len(references) <= 100:
            raise MemoryValidationError("invalid_candidate_references")
        if any(not isinstance(ref, CandidateReference) for ref in references) or len({ref.candidate_id for ref in references}) != len(references):
            raise MemoryValidationError("invalid_candidate_references")
        with self._store._lock:
            self._store._check()
            snapshots = []
            for ref in references:
                _integer(ref.row_version, "row_version", 1)
                candidate = self._candidates.detail(access, ref.candidate_id)
                if candidate.state != "pending" or candidate.row_version != ref.row_version:
                    raise MemoryConflict("stale_candidate_reference")
                snapshots.append(candidate)
        lexical = [" ".join(_terms(c.text + ("\n" + c.condition if c.condition else ""))) for c in snapshots]
        result = []
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                for snapshot, terms in zip(snapshots, lexical):
                    candidate = self._candidates.detail(access, snapshot.candidate_id)
                    if (candidate.state != "pending" or candidate.row_version != snapshot.row_version
                            or candidate.text != snapshot.text or candidate.condition != snapshot.condition):
                        raise MemoryConflict("stale_candidate_reference")
                    old = self._db.execute("SELECT * FROM retrieval_documents WHERE candidate_id=?", (candidate.candidate_id,)).fetchone()
                    if old is not None:
                        if old["target_version"] != candidate.row_version:
                            raise MemoryConflict("stale_candidate_reference")
                        result.append(self._reference(old))
                        continue
                    stream = self._db.execute("SELECT stream_id FROM formation_tasks WHERE task_id=?", (candidate.task_id,)).fetchone()[0]
                    key = uuid4().hex
                    self._db.execute("INSERT INTO retrieval_documents(document_key,target_kind,stream_id,candidate_id,target_version,body,condition_text,lexical_text) VALUES(?,'candidate',?,?,?,?,?,?)",
                                     (key, stream, candidate.candidate_id, candidate.row_version, candidate.text, candidate.condition, terms))
                    self._db.execute("UPDATE candidates SET index_state='ready' WHERE candidate_id=?", (candidate.candidate_id,))
                    result.append(RetrievalReference(key, "candidate", candidate.row_version))
        return tuple(result)

    @staticmethod
    def _validate_reference(ref, kind=None):
        if not isinstance(ref, RetrievalReference) or ref.target_kind not in ("source", "candidate"):
            raise MemoryValidationError("invalid_retrieval_reference")
        _identity(ref.document_key)
        _integer(ref.target_version, "target_version", 1)
        if kind is not None and ref.target_kind != kind:
            raise MemoryValidationError("wrong_retrieval_purpose")

    def _document(self, access, ref):
        self._validate_reference(ref)
        where, parameters = ("1=1", ()) if access is None else self._store._where(access, "s")
        row = self._db.execute("SELECT d.*,s.scope_kind,s.user_id,s.character_id,s.project_id FROM retrieval_documents d JOIN source_streams s ON s.stream_id=d.stream_id WHERE "
                               + where + " AND d.document_key=? AND d.target_kind=? AND d.target_version=?", (*parameters, ref.document_key, ref.target_kind, ref.target_version)).fetchone()
        if row is None:
            raise MemoryNotFound("retrieval_document_not_found")
        scope = MemoryScope(row["scope_kind"], row["user_id"], row["character_id"], row["project_id"])
        if ref.target_kind == "source":
            source = SourceSpan(row["namespace"], row["record_key"], row["revision"])
            current = self._maintenance._lookup_row(access, source, row["stream_id"], discoverable=True)
            if current["state_version"] != row["target_version"]:
                raise MemoryNotFound("retrieval_document_not_found")
            return RetrievalItem(ref, scope, row["body"], None, "original", source=source)
        if access is None:
            authority = self._db.execute("SELECT c.*,s.scope_kind,s.user_id,s.character_id,s.project_id FROM candidates c JOIN formation_tasks t ON t.task_id=c.task_id JOIN source_streams s ON s.stream_id=t.stream_id WHERE c.candidate_id=? AND t.stream_id=?", (row["candidate_id"], row["stream_id"])).fetchone()
            if authority is None:
                raise MemoryNotFound("retrieval_document_not_found")
            candidate = self._candidates._read_candidate(authority)
        else:
            candidate = self._candidates.detail(access, row["candidate_id"])
        if candidate.state != "pending" or candidate.row_version != ref.target_version:
            raise MemoryNotFound("retrieval_document_not_found")
        # Body/condition always come from authority, including final assembly.
        return RetrievalItem(ref, candidate.scope, candidate.text, candidate.condition, "pending",
                             candidate=CandidateReference(candidate.candidate_id, candidate.row_version), evidence=candidate.evidence)

    def detail(self, access: AccessScope, reference: RetrievalReference) -> RetrievalItem:
        self._store._access(access)
        with self._store._lock:
            self._store._check()
            return self._document(access, reference)

    def _coverage(self, access, kind):
        where, parameters = self._store._where(access, "s")
        if kind == "source":
            eligible = self._db.execute("SELECT count(*) FROM source_states q JOIN source_streams s ON s.stream_id=q.stream_id WHERE " + where + " AND " + self._maintenance._lookup_eligibility(discoverable=True), parameters).fetchone()[0]
        else:
            sql, parameters = self._candidates._read_query(access)
            eligible = self._db.execute("SELECT count(*) FROM (" + sql + " AND c.state='pending')", parameters).fetchone()[0]
        rows = self._db.execute("SELECT d.index_state,d.index_version,d.index_dimensions,count(*) n FROM retrieval_documents d JOIN source_streams s ON s.stream_id=d.stream_id WHERE " + where + " AND d.target_kind=? GROUP BY d.index_state,d.index_version,d.index_dimensions", (*parameters, kind)).fetchall()
        total = sum(row["n"] for row in rows)
        embedder = self._store._embedder
        # An unloaded resource does not erase or relabel durable ready caches.
        # semantic='unavailable' reports inability to execute the query channel.
        indexed = sum(row["n"] for row in rows if row["index_state"] == "ready" and (embedder is None or (row["index_version"] == embedder.version and row["index_dimensions"] == embedder.dimensions)))
        failed = sum(row["n"] for row in rows if row["index_state"] == "failed")
        unmaterialized = max(0, eligible - total)
        semantic = "unavailable" if embedder is None else ("ready" if indexed == total and not unmaterialized else "partial")
        return RetrievalCoverage(eligible, total, indexed, total-indexed-failed, failed, unmaterialized, semantic, embedder.version if embedder else None)

    def coverage(self, access: AccessScope, *, target_kind: Literal["source", "candidate"]) -> RetrievalCoverage:
        self._store._access(access)
        if target_kind not in ("source", "candidate"):
            raise MemoryValidationError("invalid_retrieval_purpose")
        with self._store._lock:
            self._store._check()
            return self._coverage(access, target_kind)

    @staticmethod
    def _model_current(store, embedder, version, dimensions):
        return store._embedder is embedder and embedder.version == version and embedder.dimensions == dimensions

    def run_index_batch(self, *, limit: int = 8, max_chunks: int = 128, retry_failed: bool = False,
                        access: AccessScope | None = None,
                        references: Sequence[RetrievalReference] | None = None) -> RetrievalIndexResult:
        _integer(limit, "index_limit", 1, 100)
        _integer(max_chunks, "max_chunks", 1, 4096)
        if not isinstance(retry_failed, bool):
            raise MemoryValidationError("invalid_retry_failed")
        if references is not None:
            self._store._access(access)
            references = tuple(references)
            if len(references) > 1000:
                raise MemoryValidationError("invalid_index_references")
            for ref in references:
                self._validate_reference(ref)
        if not self._store._index_lock.acquire(blocking=False):
            return RetrievalIndexResult(0, 0, 0, 0, busy=True)
        try:
            with self._store._lock:
                self._store._check()
                embedder = self._store._embedder
                if embedder is None:
                    return RetrievalIndexResult(0, 0, 0, 0)
                version, dimensions = embedder.version, embedder.dimensions
                states = "('pending','failed')" if retry_failed else "('pending')"
                unavailable = 0
                validation_access = access if references is not None else None
                if references is None:
                    total = self._db.execute(f"SELECT count(*) FROM retrieval_documents WHERE index_state IN {states}").fetchone()[0]
                    rows = []
                    for row in self._db.execute(f"SELECT * FROM retrieval_documents WHERE index_state IN {states} ORDER BY document_id"):
                        try:
                            self._document(None, self._reference(row))
                        except MemoryNotFound:
                            unavailable += 1
                            continue
                        rows.append(row)
                        if len(rows) == limit:
                            break
                    total -= unavailable
                else:
                    rows = []
                    for ref in dict.fromkeys(references):
                        try:
                            self._document(access, ref)
                        except MemoryNotFound:
                            unavailable += 1
                            continue
                        row = self._db.execute("SELECT * FROM retrieval_documents WHERE document_key=? AND target_version=? AND target_kind=?", (ref.document_key, ref.target_version, ref.target_kind)).fetchone()
                        if row is not None and row["index_state"] in (("pending", "failed") if retry_failed else ("pending",)):
                            rows.append(row)
                    total = len(rows)
                    rows = sorted(rows, key=lambda row: row["document_id"])[:limit]
            attempted = indexed = failed = chunks_used = 0
            stale = unavailable
            chunk_limited = False
            for row in rows:
                attempted += 1
                try:
                    with self._store._embedding_lock:
                        if not self._model_current(self._store, embedder, version, dimensions):
                            return RetrievalIndexResult(attempted, indexed, failed, stale+1, documents_omitted=total-attempted)
                        with self._store._lock:
                            self._store._check()
                            try:
                                item = self._document(validation_access, self._reference(row))
                            except MemoryNotFound:
                                stale += 1
                                continue
                        text = item.text + ("\n" + item.condition if item.condition else "")
                        chunks = list(embedder.split_passage(text))
                    if not chunks or any(not isinstance(c, str) or not c for c in chunks) or "".join(chunks) != text:
                        raise ValueError("incomplete_chunks")
                    if len(chunks) > max_chunks-chunks_used:
                        chunk_limited = True
                        if chunks_used:
                            attempted -= 1
                            break
                        raise ValueError("chunk_budget_exceeded")
                    chunks_used += len(chunks)
                    vectors = []
                    for chunk in chunks:
                        # One shared resource unit per chunk, yielding to M1
                        # queries/indexing under the owner's fairness policy.
                        with self._store._embedding_lock:
                            if not self._model_current(self._store, embedder, version, dimensions):
                                break
                            with self._store._lock:
                                self._store._check()
                                try:
                                    self._document(validation_access, self._reference(row))
                                except MemoryNotFound:
                                    break
                            unit = list(embedder.embed_passages([chunk]))
                            if len(unit) != 1:
                                raise ValueError("invalid_embedding_count")
                            vectors.append(normalized(unit[0], dimensions))
                except Exception:
                    with self._store._lock, self._store._transaction():
                        self._store._check()
                        changed = 0 if not self._model_current(self._store, embedder, version, dimensions) else self._db.execute("UPDATE retrieval_documents SET index_state='failed',index_version=?,index_dimensions=?,index_error='embedding_failed' WHERE document_id=? AND target_version=?", (version, dimensions, row["document_id"], row["target_version"])).rowcount
                        failed += changed
                        stale += not changed
                    continue
                with self._store._lock, self._store._transaction():
                    self._store._check()
                    try:
                        self._document(validation_access, self._reference(row))
                    except MemoryNotFound:
                        stale += 1
                        continue
                    if (not self._model_current(self._store, embedder, version, dimensions) or len(vectors) != len(chunks)
                            or not self._db.execute("SELECT 1 FROM retrieval_documents WHERE document_id=? AND target_version=?", (row["document_id"], row["target_version"])).fetchone()):
                        stale += 1
                        continue
                    self._db.execute("DELETE FROM retrieval_embeddings WHERE document_id=?", (row["document_id"],))
                    self._db.executemany("INSERT INTO retrieval_embeddings VALUES(?,?,?,?,?)", ((row["document_id"], version, number, dimensions, struct.pack(f"<{dimensions}f", *vector)) for number, vector in enumerate(vectors)))
                    self._db.execute("UPDATE retrieval_documents SET index_state='ready',index_version=?,index_dimensions=?,index_error=NULL WHERE document_id=?", (version, dimensions, row["document_id"]))
                    indexed += 1
            return RetrievalIndexResult(attempted, indexed, failed, stale, chunk_limited=chunk_limited, documents_omitted=total-attempted)
        finally:
            self._store._index_lock.release()

    @staticmethod
    def _budgets(limit, max_chars):
        _integer(limit, "result_limit", 1, 100)
        _integer(max_chars, "max_chars", 0, MAX_SOURCE_CHARS)

    def _assemble(self, access, references, kind, *, limit, max_chars, scores=None, lexical=()):
        items = []
        omitted = invalidated = 0
        used = 0
        seen = set()
        for ref in references:
            self._validate_reference(ref, kind)
            if ref in seen:
                continue
            seen.add(ref)
            try:
                item = self._document(access, ref)
            except MemoryNotFound:
                invalidated += 1
                continue
            size = len(item.text) + len(item.condition or "")
            if len(items) >= limit or used+size > max_chars:
                omitted += 1
                continue
            used += size
            items.append(replace(item, semantic_score=(scores or {}).get(ref.document_key), lexical_match=ref.document_key in lexical))
        coverage = replace(self._coverage(access, kind), budget_omitted=omitted, invalidated_omitted=invalidated)
        return RetrievalResult(tuple(items), coverage)

    def _revalidate(self, access, references, kind, limit, max_chars):
        self._store._access(access)
        self._budgets(limit, max_chars)
        if not isinstance(references, (list, tuple)) or len(references) > 1000:
            raise MemoryValidationError("invalid_retrieval_references")
        # DTO bodies and scores are not evidence; only immutable references are
        # read. Public revalidation makes no new query/relevance assertion.
        refs = tuple(item.reference if isinstance(item, RetrievalItem) else item for item in references)
        with self._store._lock:
            self._store._check()
            return self._assemble(access, refs, kind, limit=limit, max_chars=max_chars)

    def revalidate_sources(self, access, references, *, limit=100, max_chars=MAX_SOURCE_CHARS):
        return self._revalidate(access, references, "source", limit, max_chars)

    def revalidate_candidates(self, access, references, *, limit=100, max_chars=MAX_SOURCE_CHARS):
        return self._revalidate(access, references, "candidate", limit, max_chars)

    def lookup_sources(self, access: AccessScope, query: str, *, limit=8, max_chars=4096,
                       candidate_limit=100, max_vectors=SOURCE_VECTOR_SCAN_LIMIT, recent_context=(), query_wait_ms=250,
                       _query_embedding=None) -> RetrievalResult:
        return self._search(access, query, "source", limit, max_chars, candidate_limit, max_vectors, recent_context, query_wait_ms, _query_embedding)

    def review_candidates(self, access: AccessScope, query: str, *, limit=8, max_chars=4096,
                          candidate_limit=100, max_vectors=100_000, recent_context=(), query_wait_ms=250) -> RetrievalResult:
        return self._search(access, query, "candidate", limit, max_chars, candidate_limit, max_vectors, recent_context, query_wait_ms)

    @staticmethod
    def _vector_spec(where, parameters, version, dimensions):
        sql = (" FROM retrieval_embeddings e JOIN retrieval_documents d ON d.document_id=e.document_id"
               " JOIN source_streams s ON s.stream_id=d.stream_id WHERE " + where
               + " AND d.target_kind=? AND d.index_state='ready' AND e.embedding_version=?"
               " AND e.dimensions=? AND d.index_version=e.embedding_version AND d.index_dimensions=e.dimensions")
        return sql, (*parameters, version, dimensions)

    def _begin_source_vector_prewarm(self, access):
        self._store._access(access)
        with self._store._lock:
            self._store._check()
            model = self._store._embedder
            if model is None:
                return "model_unavailable"
            if self._store._source_vectors is None:
                from .source_vectors import SourceVectors

                if self._db.in_transaction:
                    return "writer_busy"
                with self._store._transaction():
                    cache = SourceVectors(self._db)
                self._store._source_vectors = cache
            where, parameters = self._store._where(access, "s")
            sql, params = self._vector_spec(where, (*parameters, "source"), model.version, model.dimensions)
            return self._store._source_vectors.begin(sql, params, SOURCE_VECTOR_SCAN_LIMIT, model)

    def _step_source_vector_prewarm(self, plan):
        with self._store._lock:
            self._store._check()
            return self._store._source_vectors.step(plan, self._store._embedder)

    def _discard_source_vector_prewarm(self, plan, reason):
        with self._store._lock:
            self._store._source_vectors.discard(plan, reason)

    def _source_vector_snapshot(self, kind, params, limit, embedder):
        cache = self._store._source_vectors
        if kind == "source" and cache is not None:
            return cache.current(params, limit, embedder)
        return None

    def _vector_batches(self, kind, sql, params, limit, embedder):
        snapshot = self._source_vector_snapshot(kind, params, limit, embedder)
        if snapshot is not None:
            for start in range(0, len(snapshot.rows), 256):
                yield snapshot.rows[start:start+256], snapshot.matrix[start:start+256]
            return
        dimensions = embedder.dimensions
        vector_bytes = dimensions * np.dtype("<f4").itemsize
        cursor = self._db.execute(
            "SELECT d.document_id,d.document_key,d.target_kind,d.target_version,e.vector"
            + sql + " ORDER BY d.document_id,e.chunk_no LIMIT ?", (*params, limit))
        with closing(cursor):
            while batch := cursor.fetchmany(256):
                blobs = [row["vector"] for row in batch]
                if any(len(blob) != vector_bytes for blob in blobs):
                    raise ValueError("invalid_embedding")
                yield batch, np.frombuffer(b"".join(blobs), dtype="<f4").reshape(-1, dimensions)

    def _search(self, access, query, kind, limit, max_chars, candidate_limit, max_vectors, context, query_wait_ms, _query_embedding=None):
        self._store._access(access)
        self._budgets(limit, max_chars)
        _integer(candidate_limit, "candidate_limit", 1, 1000)
        _integer(max_vectors, "max_vectors", 0, 1_000_000)
        _integer(query_wait_ms, "query_wait_ms", 0, 60_000)
        if (not isinstance(query, str) or len(query) > self._store._max_text_chars
                or not isinstance(context, (list, tuple)) or len(context) > 100
                or any(not isinstance(text, str) for text in context)
                or sum(map(len, context)) > MAX_SOURCE_CHARS):
            raise MemoryValidationError("invalid_retrieval_query")
        where, parameters = self._store._where(access, "s")
        base = " FROM retrieval_documents d JOIN source_streams s ON s.stream_id=d.stream_id WHERE " + where + " AND d.target_kind=?"
        parameters = (*parameters, kind)
        lexical = []
        references = {}
        lexical_omitted = 0
        with self._store._lock:
            self._store._check()
            if not query.strip():
                return RetrievalResult((), replace(self._coverage(access, kind), semantic="empty_query"))
            terms = list(dict.fromkeys(_terms(query, query=True)))[:64]
            if terms:
                match = " OR ".join('"' + term.replace('"', '""') + '"' for term in terms)
                fts = " FROM retrieval_fts JOIN retrieval_documents d ON d.document_id=retrieval_fts.rowid JOIN source_streams s ON s.stream_id=d.stream_id WHERE " + where + " AND d.target_kind=? AND retrieval_fts MATCH ?"
                count = self._db.execute("SELECT count(*)" + fts, (*parameters, match)).fetchone()[0]
                rows = self._db.execute("SELECT d.*" + fts + " ORDER BY bm25(retrieval_fts),d.document_id LIMIT ?", (*parameters, match, candidate_limit)).fetchall()
                lexical = [row["document_id"] for row in rows]
                references.update((row["document_id"], self._reference(row)) for row in rows)
                lexical_omitted = count-len(rows)
            embedder = self._store._embedder
            version = embedder.version if embedder else None
            dimensions = embedder.dimensions if embedder else None
            vector_sql, vector_parameters = self._vector_spec(where, parameters, version, dimensions)
            available_vectors = 0
            if embedder is not None:
                if max_vectors:
                    snapshot = self._source_vector_snapshot(kind, vector_parameters, max_vectors, embedder)
                    if snapshot is not None:
                        available_vectors = bool(snapshot.rows)
                    else:
                        available_vectors = self._db.execute(
                            "SELECT 1" + vector_sql + " LIMIT 1", vector_parameters).fetchone() is not None
                    del snapshot
                else:
                    available_vectors = self._db.execute("SELECT count(*)" + vector_sql, vector_parameters).fetchone()[0]
        error = None
        scores = {}
        scanned = semantic_omitted = 0
        vectors_omitted = available_vectors if max_vectors == 0 else 0
        # No query embedding can help an empty/pending corpus or a zero scan
        # budget. Keep lexical degradation cheap and the shared resource free.
        if embedder is not None and available_vectors and max_vectors:
            if not self._store._embedding_lock.acquire(query=True, timeout=query_wait_ms/1000):
                error = "busy"
            else:
                try:
                    if not self._model_current(self._store, embedder, version, dimensions):
                        raise ValueError("embedder_changed")
                    if _query_embedding is None:
                        prepare = getattr(embedder, "prepare_query", None)
                        prepared = prepare(query, context=context) if prepare else query
                        raw = embedder.embed_query(prepared)
                    else:
                        raw = _query_embedding(embedder, query, context)
                    query_vector = normalized(raw, dimensions)
                except Exception:
                    error = "failed"
                finally:
                    self._store._embedding_lock.release()
            if error is None:
                try:
                    with self._store._lock:
                        self._store._check()
                        if not self._model_current(self._store, embedder, version, dimensions):
                            error = "changed"
                        else:
                            seen = set()
                            query_array = np.asarray(query_vector, dtype=np.float32)
                            with closing(self._vector_batches(kind, vector_sql, vector_parameters,
                                                              max_vectors, embedder)) as batches:
                                for batch, matrix in batches:
                                    values = matrix @ query_array
                                    scanned += len(batch)
                                    new_rows = {}
                                    for row, raw in zip(batch, values):
                                        mid = row["document_id"]
                                        score = float(raw)
                                        if not math.isfinite(score):
                                            raise ValueError("invalid_embedding")
                                        seen.add(mid)
                                        scores[mid] = max(score, scores.get(mid, -2))
                                        if mid not in references:
                                            new_rows[mid] = row
                                    # Keep bounded candidates without making references
                                    # for rows that never survive the current batch.
                                    keep = heapq.nsmallest(candidate_limit, scores, key=lambda mid: (-scores[mid], mid))
                                    scores = {mid: scores[mid] for mid in keep}
                                    references = {mid: ref for mid, ref in references.items() if mid in scores or mid in lexical}
                                    for mid in keep:
                                        if mid not in references:
                                            references[mid] = self._reference(new_rows[mid])
                            semantic_omitted = len(seen)-len(scores)
                            if scanned == max_vectors:
                                total = self._db.execute("SELECT count(*)" + vector_sql, vector_parameters).fetchone()[0]
                                vectors_omitted = total-scanned
                except Exception:
                    error = "failed"
                    scores = {}
        with self._store._lock:
            self._store._check()
            if embedder is not None and not self._model_current(self._store, embedder, version, dimensions):
                error = "changed"
                scores = {}
            ordered = sorted(scores, key=lambda mid: (-scores[mid], mid))
            ordered += [mid for mid in lexical if mid not in scores]
            result = self._assemble(access, [references[mid] for mid in ordered], kind, limit=limit, max_chars=max_chars,
                                    scores={references[mid].document_key: score for mid, score in scores.items()},
                                    lexical={references[mid].document_key for mid in lexical})
            coverage = replace(result.coverage, semantic=error or result.coverage.semantic, scanned_vectors=scanned,
                               scan_limited=bool(vectors_omitted), vectors_omitted=vectors_omitted,
                               lexical_pool_omitted=lexical_omitted, semantic_pool_omitted=semantic_omitted)
            if vectors_omitted and coverage.semantic == "ready":
                coverage = replace(coverage, semantic="partial")
            if embedder is not None and not available_vectors and coverage.indexed_documents:
                # A concurrent index commit after our initial snapshot does not
                # turn a skipped query channel into a completed semantic scan.
                coverage = replace(coverage, semantic=error or "partial")
            return replace(result, coverage=coverage)
