"""Complete declared evidence delivery and content-free actual output reads.

Host callbacks run outside write transactions. Completeness means only that the
declared necessary records were delivered, never semantic sufficiency.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from datetime import datetime, timedelta, timezone
import json
from typing import Literal

from .maintenance import Maintenance, SourceInput, _integer, _validate_input
from .models import (AccessScope, SourceSpan, SourceContent, RecallReference,
                     RecallCandidate, MemoryConflict, MemoryNotFound, MemoryValidationError)
from .sources import _identity, _validate_source, locate_source_quote
from .candidates import Candidates, CandidateReference, CandidateEvidence


MAX_READ_REFERENCES = 1000


@dataclass(frozen=True)
class OutputReadSet:
    """Direct actual reads; output ancestors remain in their owning relations."""
    memories: tuple[RecallReference, ...] = ()
    sources: tuple[SourceInput, ...] = ()
    outputs: tuple[SourceSpan, ...] = ()
    candidates: tuple[CandidateReference, ...] = ()


def _read_set(value):
    if not isinstance(value, OutputReadSet):
        raise MemoryValidationError("invalid_output_read_set")
    if any(not isinstance(v, (tuple, list)) for v in (value.memories, value.sources, value.outputs, value.candidates)):
        raise MemoryValidationError("invalid_output_read_set")
    # M1's accumulated Memory history has never had a dependency-count cap.
    # Bound only the new source/output input boundary owned by this API.
    if len(value.sources) + len(value.outputs) + len(value.candidates) > MAX_READ_REFERENCES:
        raise MemoryValidationError("read_set_limit")
    memories, sources, outputs, candidates = {}, {}, set(), {}
    for ref in value.memories:
        if not isinstance(ref, (RecallReference, RecallCandidate)):
            raise MemoryValidationError("invalid_recall_use")
        _identity(ref.memory_id)
        _integer(ref.row_version, "row_version", 1)
        if ref.memory_id in memories and memories[ref.memory_id] != ref.row_version:
            raise MemoryConflict("stale_memory_version")
        memories[ref.memory_id] = ref.row_version
    for item in value.sources:
        _validate_input(item)
        key = item.source.namespace, item.source.record_key
        if key in sources and sources[key] != item:
            raise MemoryConflict("source_snapshot_conflict")
        sources[key] = item
    for source in value.outputs:
        _validate_source(source)
        if source is None:
            raise MemoryValidationError("invalid_source")
        outputs.add(SourceSpan(source.namespace, source.record_key, source.revision))
    for ref in value.candidates:
        if not isinstance(ref, CandidateReference):
            raise MemoryValidationError("invalid_candidate_reference")
        _identity(ref.candidate_id)
        _integer(ref.row_version, "row_version", 1)
        if ref.candidate_id in candidates and candidates[ref.candidate_id] != ref.row_version:
            raise MemoryConflict("stale_candidate_reference")
        candidates[ref.candidate_id] = ref.row_version
    return OutputReadSet(tuple(RecallReference(k, v) for k, v in sorted(memories.items())),
                         tuple(sources[k] for k in sorted(sources)),
                         tuple(sorted(outputs, key=lambda s: (s.namespace, s.record_key, s.revision))),
                         tuple(CandidateReference(k, v) for k, v in sorted(candidates.items())))


@dataclass(frozen=True)
class RecordedTime:
    status: Literal["known", "unknown", "out_of_range"]
    utc: str | None = None


def format_recorded_time(recorded_at_ms: int | None) -> RecordedTime:
    """Render the Host record clock, without event inference or local timezone."""
    if recorded_at_ms is None:
        return RecordedTime("unknown")
    _integer(recorded_at_ms, "recorded_at_ms")
    try:
        value = datetime(1970, 1, 1, tzinfo=timezone.utc) + timedelta(milliseconds=recorded_at_ms)
    except OverflowError:
        return RecordedTime("out_of_range")
    precision = "milliseconds" if recorded_at_ms % 1000 else "seconds"
    return RecordedTime("known", value.isoformat(timespec=precision).replace("+00:00", "Z"))


@dataclass(frozen=True)
class EvidenceLimits:
    max_sources: int
    max_chars: int
    max_bytes: int
    max_tokens: int
    max_references: int = 100
    read_sources: int = 1000
    read_chars: int = 1_000_000
    read_bytes: int = 4_000_000
    max_groups: int = 1000


@dataclass(frozen=True)
class EvidenceGroup:
    reference: CandidateReference | RecallReference | SourceInput
    status: Literal["complete", "omitted", "unavailable"]
    code: str | None
    sources: tuple[SourceSpan, ...] = ()
    highlights: tuple[CandidateEvidence, ...] = ()
    group_id: str | None = None


@dataclass(frozen=True)
class EvidenceResult:
    payload: str
    groups: tuple[EvidenceGroup, ...]
    read_set: OutputReadSet
    source_count: int
    chars: int
    utf8_bytes: int
    tokens: int
    record_inputs: tuple[SourceInput, ...]


class EvidenceDelivery:
    """Assemble only authoritative declared sources; never run or send a model."""

    def __init__(self, store):
        self._store = store
        self._maintenance = Maintenance(store)
        self._candidates = Candidates(store)

    def _plan(self, access, reference, purpose, review_pending, include_notes=False):
        db = self._store._db
        snapshots = {}
        if isinstance(reference, CandidateReference):
            if not review_pending or purpose != "lookup":
                raise MemoryValidationError("pending_requires_lookup_review")
            candidate = self._candidates.detail(access, reference.candidate_id)
            if candidate.state != "pending" or candidate.row_version != reference.row_version:
                raise MemoryConflict("stale_candidate_reference")
            edges = candidate.evidence
            task_id = candidate.task_id
        elif isinstance(reference, RecallReference):
            self._store._validate_recall_references(access, {reference.memory_id: reference.row_version}, purpose)
            origin = db.execute("SELECT candidate_id FROM origins WHERE memory_id=?", (reference.memory_id,)).fetchone()
            if include_notes:
                memory = self._store._memory(self._store._get(access, reference.memory_id))
                if memory.retention == "explicit":
                    # Explicit retention delivers the independently saved body,
                    # including user-accepted candidates. Source interfaces
                    # resolve retained candidate provenance separately.
                    entry = {"text":memory.text, "scope":memory.scope.kind, "kind":memory.kind}
                    if memory.condition:
                        entry["condition"] = memory.condition
                    return (), (), entry
            if origin is not None and origin[0] is not None:
                # Publication/acceptance retains this one evidence graph. The
                # coordinate-only memory_sources view is for provenance sets,
                # not the roles, duplicates or order of citation delivery.
                candidate = self._candidates.detail(access, origin[0])
                edges, task_id = candidate.evidence, candidate.task_id
            else:
                edges = tuple(CandidateEvidence("support", 0, SourceSpan(*r)) for r in db.execute("SELECT namespace,record_key,revision,start_cp,end_cp FROM memory_sources WHERE memory_id=? ORDER BY namespace,record_key,revision,start_cp,end_cp", (reference.memory_id,)))
                task_id = None
        elif isinstance(reference, SourceInput):
            _validate_input(reference)
            edges, task_id = (), None
            snapshots[reference.source] = reference
        else:
            raise MemoryValidationError("invalid_evidence_reference")
        if task_id is not None:
            for row in db.execute("SELECT namespace,record_key,revision,state_version,policy_revision,recorded_at_ms FROM formation_inputs WHERE task_id=?", (task_id,)):
                source = SourceSpan(*row[:3])
                snapshots[source] = SourceInput(source, *row[3:])
        necessary = tuple(dict.fromkeys(SourceSpan(e.source.namespace, e.source.record_key, e.source.revision) for e in edges))
        if isinstance(reference, SourceInput):
            necessary = (reference.source,)
        if not necessary:
            raise MemoryNotFound("evidence_sources_unavailable")
        inputs = []
        for source in necessary:
            item = snapshots.get(source)
            if item is None:
                if task_id is not None:
                    raise MemoryConflict("evidence_snapshot_missing")
                row = self._maintenance._lookup_row(access, source)
                item = SourceInput(source, row["state_version"], row["policy_revision"], row["recorded_at_ms"])
            self._maintenance._lookup_input(access, item)
            inputs.append(item)
        return tuple(inputs), tuple(edges), None

    @staticmethod
    def _allowed(authorized):
        try:
            allowed = authorized is not None and authorized() is True
        except Exception:
            raise MemoryConflict("evidence_authorization_failed") from None
        if not allowed:
            raise MemoryConflict("evidence_not_authorized")

    @staticmethod
    def _payload(records, groups, notes=None):
        try:
            aliases = {item.source: "s" + str(i) for i, item in enumerate(records)}
            note_aliases = {reference:index for index, reference in enumerate(notes or {})}
            visible = [{"source_id": aliases[item.source], **content} for item, content in records.items()]
            visible_groups = []
            for index, (inputs, edges, note) in enumerate(groups):
                visible_groups.append({"group_id": "g" + str(index), "sources": [aliases[i.source] for i in inputs],
                    "highlights": [{"source_id": aliases[SourceSpan(e.source.namespace, e.source.record_key, e.source.revision)],
                                    "role": e.role, "group": e.group, "start_cp": e.source.start_cp,
                                    "end_cp": e.source.end_cp} for e in edges]})
                if notes is not None:
                    visible_groups[-1]["entries"] = [note_aliases[note]] if note is not None else []
            payload = {"completeness": "declared_material_only", "records": visible, "groups": visible_groups}
            if notes is not None:
                payload["entries"] = list(notes.values())
            return json.dumps(payload, ensure_ascii=False,
                              separators=(", ", ": ") if notes is not None else (",", ":"), sort_keys=True)
        except Exception:
            raise MemoryValidationError("evidence_render_failed") from None

    @staticmethod
    def _measure(payload, count_tokens):
        try:
            size = len(payload.encode("utf-8"))
            tokens = count_tokens(payload)
            _integer(tokens, "token_count")
        except Exception:
            raise MemoryValidationError("evidence_token_count_failed") from None
        return len(payload), size, tokens

    def assemble(self, access: AccessScope, references, *, purpose: str = "lookup",
                 review_pending: bool = False, limits: EvidenceLimits, reader,
                 authorized, count_tokens, now_ms: int, include_notes: bool = False) -> EvidenceResult:
        """Deliver indivisible groups in caller order with exact payload budgets.

        Only complete groups and their records/highlights enter JSON. Omitted
        group statuses are Host diagnostics outside that consumer payload.
        """
        self._store._access(access)
        self._store._purpose_bit(purpose)
        _integer(now_ms, "now_ms")
        if purpose != "lookup":
            raise MemoryConflict("raw_read_set_lookup_only")
        if (not isinstance(review_pending, bool) or type(include_notes) is not bool
                or not isinstance(limits, EvidenceLimits) or not callable(count_tokens)):
            raise MemoryValidationError("invalid_evidence_options")
        for name in EvidenceLimits.__dataclass_fields__:
            _integer(getattr(limits, name), name, 0 if name.startswith("max_") else 1,
                     1000 if name in ("max_references", "max_sources", "read_sources", "max_groups") else 2**63-1)
        if not isinstance(references, (list, tuple)) or len(references) > limits.max_references:
            raise MemoryValidationError("evidence_reference_limit")
        references = tuple(references)
        for ref in references:
            if isinstance(ref, CandidateReference):
                _identity(ref.candidate_id)
                _integer(ref.row_version, "row_version", 1)
            elif isinstance(ref, RecallReference):
                _identity(ref.memory_id)
                _integer(ref.row_version, "row_version", 1)
            elif isinstance(ref, SourceInput):
                _validate_input(ref)
            else:
                raise MemoryValidationError("invalid_evidence_reference")
        self._allowed(authorized)
        plans, results = [], []
        with self._store._lock:
            self._store._check()
            for ref in references:
                try:
                    plans.append(self._plan(access, ref, purpose, review_pending, include_notes))
                    results.append(None)
                except (MemoryConflict, MemoryNotFound, MemoryValidationError) as error:
                    plans.append(None)
                    results.append(EvidenceGroup(ref, "unavailable", str(error)))
        cached, failures, records, selected, selected_plans = {}, {}, {}, [], []
        notes = {} if include_notes else None
        read_count = read_chars = read_bytes = 0
        payload = self._payload({}, [], notes)
        measured = self._measure(payload, count_tokens)
        if any(v > bound for v, bound in zip(measured, (limits.max_chars, limits.max_bytes, limits.max_tokens))):
            raise MemoryValidationError("delivery_metadata_budget_exceeded")
        for index, (ref, plan) in enumerate(zip(references, plans)):
            if plan is None:
                continue
            inputs, edges, entry = plan
            if len(selected) >= limits.max_groups:
                results[index] = EvidenceGroup(ref, "omitted", "group_budget")
                continue
            new = [item for item in inputs if item not in records]
            if len(records) + len(new) > limits.max_sources:
                results[index] = EvidenceGroup(ref, "omitted", "source_budget")
                continue
            error_code = None
            for item in inputs:
                if item in failures:
                    error_code = failures[item]
                    break
                if item in cached:
                    continue
                if read_count >= limits.read_sources or read_chars >= limits.read_chars or read_bytes >= limits.read_bytes:
                    error_code = "reader_budget"
                    break
                self._allowed(authorized)
                with self._store._lock:
                    self._store._check()
                    self._maintenance._lookup_input(access, item)
                read_count += 1
                try:
                    content = reader.read(item, max_chars=limits.read_chars-read_chars, max_bytes=limits.read_bytes-read_bytes)
                except Exception:
                    error_code = "source_reader_failed"
                    failures[item] = error_code
                    break
                try:
                    # Account for returned body input even if its metadata is
                    # invalid or its group is later omitted. A Reader ignoring
                    # its remaining bound cannot unlock another full read.
                    if isinstance(content, SourceContent) and isinstance(content.text, str):
                        read_chars += len(content.text)
                        read_bytes += len(content.text.encode("utf-8"))
                    if (not isinstance(content, SourceContent) or content.source != item.source
                            or not isinstance(content.text, str) or not content.text
                            or not isinstance(content.speaker_role, str) or len(content.speaker_role) > 64
                            or (content.speaker_ref is not None and (not isinstance(content.speaker_ref, str) or len(content.speaker_ref) > 256))):
                        raise ValueError()
                    if read_chars > limits.read_chars or read_bytes > limits.read_bytes:
                        raise ValueError()
                    cached[item] = {"text": content.text,
                                    "speaker_role": content.speaker_role, "speaker_ref": content.speaker_ref,
                                    "recorded_time": asdict(format_recorded_time(item.recorded_at_ms))}
                except (ValueError, TypeError, UnicodeError, MemoryValidationError):
                    error_code = "invalid_source_content"
                    failures[item] = error_code
                    break
            if error_code:
                results[index] = EvidenceGroup(ref, "omitted" if error_code == "reader_budget" else "unavailable", error_code)
                continue
            try:
                by_source = {item.source: cached[item]["text"] for item in inputs}
                for edge in edges:
                    span = edge.source
                    if span.start_cp is None:
                        continue
                    whole = SourceSpan(span.namespace, span.record_key, span.revision)
                    text = by_source[whole]
                    if span.end_cp > len(text) or locate_source_quote(whole, text, text[span.start_cp:span.end_cp]) != span:
                        raise MemoryValidationError("evidence_coordinate_mismatch")
            except MemoryValidationError as error:
                results[index] = EvidenceGroup(ref, "unavailable", str(error))
                continue
            group = inputs, edges, ref if entry is not None else None
            proposed = dict(records)
            proposed.update((item, cached[item]) for item in inputs)
            proposed_notes = dict(notes) if notes is not None else None
            if entry is not None:
                proposed_notes[ref] = entry
            proposed_payload = self._payload(proposed, [*selected, group], proposed_notes)
            proposed_size = self._measure(proposed_payload, count_tokens)
            if any(v > bound for v, bound in zip(proposed_size, (limits.max_chars, limits.max_bytes, limits.max_tokens))):
                results[index] = EvidenceGroup(ref, "omitted", "payload_budget")
                continue
            records, notes, payload, measured = proposed, proposed_notes, proposed_payload, proposed_size
            selected.append(group)
            selected_plans.append((ref, plan))
            results[index] = EvidenceGroup(ref, "complete", None, tuple(item.source for item in inputs), edges, "g" + str(len(selected)-1))
        self._allowed(authorized)
        with self._store._lock:
            self._store._check()
            for ref, plan in selected_plans:
                if self._plan(access, ref, purpose, review_pending, include_notes) != plan:
                    raise MemoryConflict("evidence_snapshot_changed")
            reads = self._store.capture_read_set(access, memories=tuple(notes or ()),
                sources=tuple(records), now_ms=now_ms, purpose=purpose)
        return EvidenceResult(payload, tuple(results), reads, len(records), *measured, tuple(records))
