"""Optional Host-driven scheduling; no transport, thread or model is installed.

The borrowed Host database contains scheduling checkpoints only. Source/task,
attempt, accounting and candidate truth remain in the existing Store facades.
The Host serializes ticks and source consumption, including across processes.
"""
from __future__ import annotations

from contextlib import contextmanager
from dataclasses import dataclass, replace
import json
import threading
from typing import Callable, Sequence

from .candidates import Candidates
from .delivery import SourceDelivery
from .executor import ExecutorLimits, FormationExecutor, StepReport
from .maintenance import Maintenance, SourceInput, _integer, _target_use_mask
from .models import AccessScope, MemoryConflict, MemoryNotFound, MemoryValidationError
from .sources import _identity


@dataclass(frozen=True)
class RuntimeConfig:
    enabled: bool = False
    quiet_ms: int = 1000
    max_wait_ms: int = 5000
    batch_events: int = 8
    sync_limit: int = 100


@dataclass(frozen=True)
class RuntimeLane:
    key: str
    access: AccessScope
    stream_id: str
    pipeline_version: str
    executor: FormationExecutor
    target_uses: Sequence[str] | None = None
    context: Callable[[RuntimeLane], Sequence[SourceInput] | None] | None = None
    max_events: int = 100
    max_sources: int = 100
    materialize_raw: bool = False
    failure_policy: str = "hold"


@dataclass(frozen=True)
class RuntimeReport:
    stage: str
    lane_key: str | None = None
    code: str | None = None
    unit: str | None = None
    delivery: SourceDelivery | None = None
    step: StepReport | None = None
    received_position: int | None = None
    processed_position: int | None = None
    postprocessed_position: int | None = None
    post_task_id: str | None = None
    post_offset: int = 0
    # Mechanical completion is deliberately independent of semantic review.
    semantic_review: str = "not_evaluated"
    observations: tuple[tuple[str, str, str | None], ...] = ()
    post_reformation_task_id: str | None = None
    # Existing Host clock. None means await a new event/trusted recovery.
    wake_at_ms: int | None = None
    # Transient finite authority sweep; independent of a usable Host clock.
    scan_remaining: int = 0
    source_fault: tuple[str, str] | None = None


class MaintenanceRuntime:
    """One bounded, explicitly woken opportunity on a serialized Host owner.

    Construction is pure. Call initialize explicitly, then tick(window_id=...).
    A disabled tick still synchronizes authority metadata for every visited lane.
    The Host retains ownership/lifetime of both connections and every adapter.
    """

    def __init__(self, host_connection, store, lanes, *, runtime_id, sync, clock,
                 config=RuntimeConfig()):
        self.connection, self.store, self.lanes = host_connection, store, tuple(lanes)
        self.runtime_id, self.sync, self.clock, self.config = runtime_id, sync, clock, config
        self.maintenance, self.candidates = Maintenance(store), Candidates(store)
        self._tick_lock = threading.Lock()
        self._scan_remaining = 0
        self._scan_wake_at = None
        self._scan_fault = None

    def request_scan(self):
        """Start a finite rescan after a new Host event or binding extension.

        Only next_lane is durable. A restart starts a new complete circle from
        that checkpoint; these counters never acknowledge source or core work.
        """
        self._scan_remaining = 0
        self._scan_wake_at = None
        self._scan_fault = None

    def _query(self, sql, values=()):
        cursor = self.connection.cursor()
        cursor.row_factory = None
        try:
            cursor.execute(sql, values)
            return cursor.fetchall()
        finally:
            cursor.close()

    def _outside_transaction(self):
        if self.connection.in_transaction:
            raise MemoryConflict("runtime_outer_transaction")

    @contextmanager
    def _transaction(self):
        self._outside_transaction()
        self._query("BEGIN IMMEDIATE")
        try:
            yield
            self.connection.commit()
        except BaseException:
            self.connection.rollback()
            raise

    def _binding(self):
        _identity(self.runtime_id)
        if not isinstance(self.config, RuntimeConfig) or type(self.config.enabled) is not bool:
            raise MemoryValidationError("invalid_runtime_config")
        for name in ("quiet_ms", "max_wait_ms"):
            _integer(getattr(self.config, name), name)
        _integer(self.config.batch_events, "batch_events", 1, 1000)
        _integer(self.config.sync_limit, "sync_limit", 1, 1000)
        if not self.lanes or not callable(self.sync) or not callable(self.clock):
            raise MemoryValidationError("invalid_runtime_adapters")
        keys, identities, bound = set(), set(), []
        for lane in self.lanes:
            if not isinstance(lane, RuntimeLane):
                raise MemoryValidationError("invalid_runtime_lane")
            for value in (lane.key, lane.stream_id, lane.pipeline_version):
                _identity(value)
            self.store._access(lane.access)
            if (not isinstance(lane.executor, FormationExecutor) or lane.executor.store is not self.store
                    or lane.executor._work_class not in ("warm", "cold")
                    or not isinstance(lane.executor.limits, ExecutorLimits)):
                raise MemoryValidationError("invalid_runtime_executor")
            _integer(lane.executor.limits.post_limit, "post_limit", 1, 64)
            _integer(lane.max_events, "max_events", 1, 1000)
            _integer(lane.max_sources, "max_sources", 1, 1000)
            if (type(lane.materialize_raw) is not bool or lane.failure_policy not in ("hold", "abandon")
                    or lane.context is not None and not callable(lane.context)):
                raise MemoryValidationError("invalid_runtime_lane")
            mask = _target_use_mask(lane.target_uses)
            identity = (lane.stream_id, lane.pipeline_version)
            if lane.key in keys or identity in identities:
                raise MemoryConflict("duplicate_runtime_lane")
            keys.add(lane.key)
            identities.add(identity)
            # Persist identity/policy binding, never callback objects or bodies.
            bound.append((lane.key, lane.access.user_id, lane.access.character_id, lane.access.project_id,
                          lane.stream_id, lane.pipeline_version, lane.executor._work_class, mask))
        return json.dumps(bound, separators=(",", ":"), ensure_ascii=True)

    def initialize(self):
        """Create/reopen only Host metadata, without touching any callback."""
        self._outside_transaction()
        binding = self._binding()
        for lane in self.lanes:
            self.maintenance.progress(lane.access, lane.stream_id, lane.pipeline_version)
        with self._transaction():
            self._query("CREATE TABLE IF NOT EXISTS eidema_runtime (runtime_id TEXT PRIMARY KEY,binding TEXT NOT NULL,next_lane INTEGER NOT NULL,last_clock_ms INTEGER)")
            self._query("CREATE TABLE IF NOT EXISTS eidema_runtime_lanes (runtime_id TEXT NOT NULL,lane_key TEXT NOT NULL,observed_received INTEGER NOT NULL DEFAULT 0,first_dirty_ms INTEGER,last_change_ms INTEGER,postprocessed_position INTEGER NOT NULL DEFAULT 0,post_task_id TEXT,post_offset INTEGER NOT NULL DEFAULT 0,PRIMARY KEY(runtime_id,lane_key))")
            if "post_reformation_task_id" not in {r[1] for r in self._query("PRAGMA table_info(eidema_runtime_lanes)")}:
                self._query("ALTER TABLE eidema_runtime_lanes ADD COLUMN post_reformation_task_id TEXT")
            rows = self._query("SELECT binding FROM eidema_runtime WHERE runtime_id=?", (self.runtime_id,))
            if rows and rows[0][0] != binding:
                previous, current = json.loads(rows[0][0]), json.loads(binding)
                if len(current) < len(previous) or current[:len(previous)] != previous:
                    raise MemoryConflict("runtime_binding_conflict")
                self._query("UPDATE eidema_runtime SET binding=? WHERE runtime_id=?", (binding, self.runtime_id))
            self._query("INSERT OR IGNORE INTO eidema_runtime(runtime_id,binding,next_lane) VALUES(?,?,0)", (self.runtime_id, binding))
            for lane in self.lanes:
                self._query("INSERT OR IGNORE INTO eidema_runtime_lanes(runtime_id,lane_key) VALUES(?,?)", (self.runtime_id, lane.key))
        self.request_scan()

    def _runtime(self, binding):
        rows = self._query("SELECT binding,next_lane,last_clock_ms FROM eidema_runtime WHERE runtime_id=?", (self.runtime_id,))
        if not rows:
            raise MemoryConflict("runtime_not_initialized")
        if rows[0][0] != binding:
            raise MemoryConflict("runtime_binding_conflict")
        return rows[0]

    def _lane_state(self, lane):
        row = self._query("SELECT observed_received,first_dirty_ms,last_change_ms,postprocessed_position,post_task_id,post_offset,post_reformation_task_id FROM eidema_runtime_lanes WHERE runtime_id=? AND lane_key=?", (self.runtime_id, lane.key))
        if not row:
            raise MemoryConflict("runtime_binding_conflict")
        return dict(zip(("observed_received", "first_dirty_ms", "last_change_ms", "postprocessed_position", "post_task_id", "post_offset", "post_reformation_task_id"), row[0]))

    def _observe(self, lane, state, progress, now):
        if state["observed_received"] > progress.received_position or state["postprocessed_position"] > progress.processed_position:
            raise MemoryConflict("runtime_receiver_checkpoint_conflict")
        if now is None:
            return state
        first, last = state["first_dirty_ms"], state["last_change_ms"]
        # The anchor belongs to the previously observed backlog. If that head
        # was consumed, a later arrival starts a new quiet/max-wait interval.
        if progress.processed_position >= state["observed_received"]:
            first = last = None
        if progress.received_position > state["observed_received"]:
            last = now
        if progress.received_position <= progress.processed_position:
            first = last = None
        elif first is None:
            first = last = now
        with self._transaction():
            self._query("UPDATE eidema_runtime_lanes SET observed_received=?,first_dirty_ms=?,last_change_ms=? WHERE runtime_id=? AND lane_key=?",
                        (progress.received_position, first, last, self.runtime_id, lane.key))
        return dict(state, observed_received=progress.received_position, first_dirty_ms=first, last_change_ms=last)

    def _synchronize(self, lane):
        self._outside_transaction()
        try:
            receipt = self.sync(lane, limit=self.config.sync_limit)
        except Exception:
            raise MemoryConflict("source_sync_failed") from None
        self._outside_transaction()
        if not isinstance(receipt, SourceDelivery):
            raise MemoryValidationError("invalid_runtime_delivery")
        progress = self.maintenance.progress(lane.access, lane.stream_id, lane.pipeline_version)
        for value in (receipt.committed_position, receipt.delivered):
            _integer(value, "delivery_position")
        if (receipt.stream_id != lane.stream_id or receipt.receiver != progress
                or receipt.delivered > self.config.sync_limit
                or receipt.committed_position < progress.received_position
                or type(receipt.caught_up) is not bool
                or receipt.caught_up != (receipt.committed_position == progress.received_position)):
            raise MemoryConflict("runtime_delivery_mismatch")
        return receipt, progress

    @staticmethod
    def _gate(lane):
        try:
            if lane.executor.authorized is None or lane.executor.authorized() is not True:
                return "denied", "execution_not_authorized"
        except Exception:
            return "denied", "authorization_check_failed"
        try:
            if lane.executor.ready is not None and lane.executor.ready() is not True:
                return "deferred", "resource_busy"
        except Exception:
            return "deferred", "resource_check_failed"
        return None

    def _report(self, lane, state, delivery, progress, stage, code=None, **fields):
        # Read only scoped state metadata. Never fetch a generated body just to
        # tell the Host whether mechanical completion still leaves review work.
        semantic_review = "unavailable"
        try:
            with self.store._lock:
                self.store._check()
                self.maintenance._stream(lane.access, lane.stream_id)
                pending = self.store._db.execute("SELECT EXISTS(SELECT 1 FROM candidates c JOIN formation_tasks t ON t.task_id=c.task_id WHERE t.stream_id=? AND t.pipeline_version=? AND c.state='pending' AND c.text IS NOT NULL)",
                    (lane.stream_id, lane.pipeline_version)).fetchone()[0]
                semantic_review = "pending" if pending else "none"
        except Exception:
            pass
        return RuntimeReport(stage, lane.key, code, delivery=delivery,
            received_position=progress.received_position, processed_position=progress.processed_position,
            postprocessed_position=state["postprocessed_position"], post_task_id=state["post_task_id"],
            post_offset=state["post_offset"], post_reformation_task_id=state["post_reformation_task_id"], semantic_review=semantic_review, **fields)

    def _postwork(self, lane, state, task, delivery, progress):
        if state["post_task_id"] not in (None, task.task_id):
            raise MemoryConflict("runtime_post_checkpoint_conflict")
        attempt = self.maintenance.current_attempt(lane.access, task.task_id)
        refs = self.candidates.result(lane.access, attempt.attempt_id).candidates if attempt is not None and attempt.outcome == "candidates" else ()
        offset = state["post_offset"]
        if offset > len(refs):
            raise MemoryConflict("runtime_post_checkpoint_conflict")
        chunk = refs[offset:offset + lane.executor.limits.post_limit]
        # Always retry the same ordinal chunk with fresh row versions until all
        # its mechanical work finishes. StepReport.remaining excludes some
        # unfinished indexes and therefore cannot be a durable ACK.
        with self._transaction():
            self._query("UPDATE eidema_runtime_lanes SET post_task_id=? WHERE runtime_id=? AND lane_key=?", (task.task_id, self.runtime_id, lane.key))
        state = dict(state, post_task_id=task.task_id)
        step = None
        try:
            step = lane.executor.resume(lane.access, task.task_id, references=tuple(chunk))
            if not step.post_pending and step.stage in ("done", "abandoned"):
                offset += len(chunk)
                complete = offset >= len(refs)
                position = task.cursor_after if complete and task.advances_cursor else state["postprocessed_position"]
                reformation_ack = task.task_id if complete and not task.advances_cursor else state["post_reformation_task_id"]
                with self._transaction():
                    self._query("UPDATE eidema_runtime_lanes SET postprocessed_position=?,post_task_id=?,post_offset=?,post_reformation_task_id=? WHERE runtime_id=? AND lane_key=?",
                        (position, None if complete else task.task_id,
                         0 if complete else offset, reformation_ack, self.runtime_id, lane.key))
                state = dict(state, postprocessed_position=position, post_reformation_task_id=reformation_ack,
                             post_task_id=None if complete else task.task_id, post_offset=0 if complete else offset)
        except Exception:
            return self._report(lane, state, delivery, progress, "postprocessing", "postprocessing_failed", unit="postprocessing", step=step)
        return self._report(lane, state, delivery, progress, "postprocessing", step.code, unit="postprocessing", step=step)

    def _budget_code(self, window_id, now):
        try:
            budget = self.maintenance.budget_status(window_id)
        except MemoryNotFound:
            return "budget_not_found"
        if not budget.window.start_ms <= now < budget.window.end_ms:
            return "outside_budget_window"
        if budget.calls >= budget.window.max_calls:
            return "budget_exhausted"
        return None

    def _wake_time(self, when, window_id, now):
        # An elapsed cadence/coalescing clock cannot repair a budget gate.
        return when if self._budget_code(window_id, now) is None else None

    def _work_metadata(self, lane, state, *, before_gate=False):
        """Scoped Store facts only; no authority/body ticket survives a gate."""
        resolved = (self.maintenance.task(lane.access, state["post_task_id"]),) if state["post_task_id"] else self.maintenance.list_resolved_tasks(lane.access, lane.stream_id, lane.pipeline_version,
            after_position=state["postprocessed_position"], limit=1)
        if not resolved:
            resolved = self.maintenance.list_resolved_maintenance_tasks(lane.access, lane.stream_id, lane.pipeline_version,
                after_task_id=state["post_reformation_task_id"], limit=1)
        if before_gate and resolved:
            return resolved, None, False
        reformation_available = True if before_gate else callable(getattr(lane.executor.provider,"prepare_reformation",None))
        selected = self.maintenance.active_task(lane.access,lane.stream_id,lane.pipeline_version,work_class=lane.executor._work_class,allow_reformation=reformation_available)
        active = selected if selected is not None and self.maintenance.task_current(lane.access, selected.task_id) else None
        waiting = lane.executor._work_class == "warm" and self.maintenance.reformation_pending(lane.access, lane.stream_id, lane.pipeline_version)
        return resolved, active, waiting

    def _visit(self, lane, state, delivery, progress, now, window_id):
        resolved, active, reformation_waiting = self._work_metadata(lane, state, before_gate=True)
        if not resolved and active is None and not reformation_waiting and progress.received_position <= progress.processed_position:
            return self._report(lane, state, delivery, progress, "idle", "no_events")
        gate = self._gate(lane)
        self._outside_transaction()
        if gate:
            return self._report(lane, state, delivery, progress, *gate)
        # The trusted gate can deliver changed authority metadata. Re-read its
        # Store consequences before any postwork, abandonment or content unit.
        resolved, active, reformation_waiting = self._work_metadata(lane, state)
        if resolved:
            return self._postwork(lane, state, resolved[0], delivery, progress)
        if active is not None and active.state in ("failed", "truncated", "unknown", "reserved"):
            attempt = self.maintenance.current_attempt(lane.access, active.task_id)
            if lane.failure_policy == "abandon" and active.state != "reserved" and attempt is not None:
                try:
                    self.maintenance.abandon_task(lane.access, active.task_id, expected_attempt_id=attempt.attempt_id)
                    progress = self.maintenance.progress(lane.access, lane.stream_id, lane.pipeline_version)
                except Exception:
                    return self._report(lane, state, delivery, progress, "blocked", "abandonment_failed", unit="abandonment")
                return self._report(lane, state, delivery, progress, "abandoned", "formation_coverage_gap", unit="abandonment")
            return self._report(lane, state, delivery, progress, "held", active.state)
        reformation_available = callable(getattr(lane.executor.provider,"prepare_reformation",None))
        reformation = reformation_available and reformation_waiting
        repair_due = reformation and self.maintenance._reformation_due(lane.access, lane.stream_id, lane.pipeline_version)
        if active is None and repair_due and self.maintenance._finalize_reformation(lane.access, lane.stream_id, lane.pipeline_version):
            return self._report(lane, state, delivery, progress, "formation", "no_events", unit="formation", wake_at_ms=now)
        if progress.received_position <= progress.processed_position and not reformation and active is None:
            if reformation_waiting:
                return self._report(lane,state,delivery,progress,"deferred","reformation_provider_unsupported")
            return self._report(lane, state, delivery, progress, "idle", "no_events")
        if lane.executor._work_class == "cold":
            cadence = self.maintenance.cold_status(now, max_runs=lane.executor.max_runs)
            if cadence.remaining == 0:
                return self._report(lane, state, delivery, progress, "cadence", "cold_quota_exhausted",
                    wake_at_ms=self._wake_time(cadence.earliest_ms, window_id, now))
        elif active is None and not repair_due and not (progress.received_position-progress.processed_position >= self.config.batch_events
                or now-state["last_change_ms"] >= self.config.quiet_ms
                or now-state["first_dirty_ms"] >= self.config.max_wait_ms):
            due = min(state["last_change_ms"]+self.config.quiet_ms,
                      state["first_dirty_ms"]+self.config.max_wait_ms)
            return self._report(lane, state, delivery, progress, "coalescing", "warm_not_due",
                wake_at_ms=self._wake_time(due, window_id, now))
        budget_code = self._budget_code(window_id, now)
        if budget_code is not None:
            return self._report(lane, state, delivery, progress, "budget", budget_code)
        try:
            context = lane.context(lane) if active is None and not repair_due and lane.context is not None else None
        except Exception:
            return self._report(lane, state, delivery, progress, "blocked", "context_selection_failed")
        self._outside_transaction()
        step = None
        try:
            step = lane.executor.step(lane.access, lane.stream_id, lane.pipeline_version, window_id=window_id,
                reservation_key="initial", retry=False, max_attempts=1, max_events=lane.max_events,
                max_sources=lane.max_sources, materialize_raw=lane.materialize_raw,
                context_inputs=context, target_uses=lane.target_uses)
            progress = self.maintenance.progress(lane.access, lane.stream_id, lane.pipeline_version)
        except Exception:
            return self._report(lane, state, delivery, progress, "formation", "formation_failed", unit="formation", step=step)
        return self._report(lane, state, delivery, progress, "formation", step.code, unit="formation", step=step)

    def tick(self, *, window_id):
        """Synchronize <=64 lanes and perform at most one existing-core unit."""
        self._outside_transaction()
        binding = self._binding()
        _identity(window_id)
        if not self._tick_lock.acquire(blocking=False):
            return RuntimeReport("busy", code="runtime_busy")
        try:
            _, start, previous_clock = self._runtime(binding)
            clock_code, now = None, None
            try:
                now = self.clock()
                _integer(now, "now_ms")
                if previous_clock is not None and now < previous_clock:
                    clock_code, now = "clock_rollback", None
            except Exception:
                clock_code, now = "invalid_runtime_clock", None
            if now is not None:
                with self._transaction():
                    self._query("UPDATE eidema_runtime SET last_clock_ms=? WHERE runtime_id=?", (now, self.runtime_id))
            observations, last = [], RuntimeReport("idle", code="no_events")
            paged = len(self.lanes) > 64
            if paged and self._scan_remaining == 0:
                self._scan_remaining = len(self.lanes)
            # A later page may lose the Host clock. Old time hints are then
            # unusable; finite metadata continuation is a separate fact.
            wake_at = self._scan_wake_at if paged and now is not None else None
            source_fault = self._scan_fault if paged else None
            visit_limit = min(64, self._scan_remaining) if paged else len(self.lanes)
            for offset in range(visit_limit):
                index = (start+offset) % len(self.lanes)
                lane = self.lanes[index]
                with self._transaction():
                    self._query("UPDATE eidema_runtime SET next_lane=? WHERE runtime_id=?", ((index+1) % len(self.lanes), self.runtime_id))
                state = self._lane_state(lane)
                try:
                    delivery, progress = self._synchronize(lane)
                except Exception as error:
                    code = str(error) if isinstance(error, (MemoryConflict, MemoryValidationError)) and str(error) in {"source_sync_failed", "invalid_runtime_delivery", "runtime_delivery_mismatch", "runtime_outer_transaction"} else "source_sync_failed"
                    last = RuntimeReport("backlog", lane.key, code)
                    source_fault = source_fault or (lane.key, code)
                    observations.append((lane.key, last.stage, last.code))
                    continue
                try:
                    state = self._observe(lane, state, progress, now)
                    if not delivery.caught_up:
                        last = self._report(lane, state, delivery, progress, "backlog", "source_delivery_pending")
                    elif clock_code:
                        last = self._report(lane, state, delivery, progress, "blocked", clock_code)
                    elif not self.config.enabled:
                        last = self._report(lane, state, delivery, progress, "disabled", "generation_disabled")
                    else:
                        last = self._visit(lane, state, delivery, progress, now, window_id)
                except Exception as error:
                    code = str(error) if isinstance(error, (MemoryConflict, MemoryValidationError)) and str(error) in {"runtime_receiver_checkpoint_conflict", "runtime_post_checkpoint_conflict", "runtime_outer_transaction"} else "lane_contract_failed"
                    last = self._report(lane, state, delivery, progress, "blocked", code)
                observations.append((lane.key, last.stage, last.code))
                opportunity = last.wake_at_ms
                # Preserve progress from every visited lane, even if the final
                # report belongs to a different idle/blocked lane. A newly
                # settled unknown call advances once; its held attempt does not.
                progressed = (delivery.delivered > 0
                    or last.step is not None and last.step.generated
                    or last.unit == "postprocessing" and last.step is not None and last.step.index_followup == "progress"
                    or last.processed_position is not None and last.processed_position > progress.processed_position
                    or last.postprocessed_position is not None and last.postprocessed_position > state["postprocessed_position"]
                    or last.post_offset > state["post_offset"]
                    or last.post_reformation_task_id is not None and last.post_reformation_task_id != state["post_reformation_task_id"])
                if now is not None and progressed:
                    opportunity = now
                if opportunity is not None:
                    wake_at = opportunity if wake_at is None else min(wake_at, opportunity)
                if last.unit is not None:
                    break
            if paged:
                # Count every actual visit, including sync failures and a core
                # unit that ended the page early. No second persistent cursor.
                self._scan_remaining -= offset+1
                remaining = self._scan_remaining
                if remaining:
                    self._scan_wake_at, self._scan_fault = wake_at, source_fault
                else:
                    self._scan_wake_at = self._scan_fault = None
            else:
                remaining = 0
            return replace(last, observations=tuple(observations), wake_at_ms=wake_at,
                           scan_remaining=remaining, source_fault=source_fault)
        finally:
            self._tick_lock.release()
