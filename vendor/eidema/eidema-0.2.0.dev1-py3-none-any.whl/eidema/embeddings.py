"""Replaceable local embeddings. Importing Eidema never loads a model."""
from __future__ import annotations

import math
from pathlib import Path
from typing import Protocol, Sequence


class Embedder(Protocol):
    version: str
    dimensions: int

    def split_passage(self, text: str) -> Sequence[str]:
        """Return nonempty contiguous chunks whose concatenation equals text."""
        ...

    def embed_passages(self, texts: Sequence[str]) -> Sequence[Sequence[float]]:
        ...

    def embed_query(self, query: str) -> Sequence[float]:
        ...

    def prepare_query(self, query: str, *, context: Sequence[str] = ()) -> str:
        """Fit current input first, then optional context, to the model tokenizer."""
        ...


def normalized(vector: Sequence[float], dimensions: int) -> list[float]:
    values = [float(v) for v in vector]
    if len(values) != dimensions or not all(math.isfinite(v) for v in values):
        raise ValueError("invalid_embedding")
    norm = math.sqrt(sum(v * v for v in values))
    if norm == 0:
        raise ValueError("zero_embedding")
    return [v / norm for v in values]


def prepare_embedding_query(tokenizer, query: str, *, max_tokens: int,
                            context: Sequence[str] = (), prefix: str = "query: ") -> str:
    """Fit actual tokenizer input, current query before optional context.

    Fast-tokenizer offsets avoid assumptions about bytes, scripts or code.
    The final measurement covers special tokens and boundary retokenization.
    Hosts sharing a model can reuse this without constructing another adapter.
    """
    def fits(text):
        return len(tokenizer.encode(prefix + text, truncation=False)) <= max_tokens

    if not fits(""):
        raise ValueError("query_prefix_exceeds_budget")

    def fit(text):
        if fits(text):
            return text
        encoded = tokenizer(prefix + text, add_special_tokens=True,
                            truncation=False, return_offsets_mapping=True)
        offsets = encoded["offset_mapping"][:max_tokens]
        end = max((end for start, end in offsets if end > start), default=len(prefix))
        bounded = text[:max(0, end - len(prefix))]
        while bounded and not fits(bounded):
            bounded = bounded[:-1]
        return bounded

    prepared = fit(query)
    if prepared != query:
        return prepared
    for recent in context:
        if not isinstance(recent, str) or not recent.strip():
            continue
        combined = prepared + "\n" + recent
        bounded = fit(combined)
        if len(bounded) > len(prepared):
            prepared = bounded
        if bounded != combined:
            break
    return prepared


class LocalE5Embedder:
    """An explicitly provided, already local multilingual-e5-compatible model.

    ``version`` identifies model weights AND tokenization/configuration. Change it
    whenever those change. No Hub lookup, download, or remote code is allowed.
    Host constructs this off its conversation event loop.
    """

    def __init__(self, model_path: str | Path, *, version: str,
                 max_tokens: int = 512, batch_size: int = 8):
        path = Path(model_path).resolve()
        if not path.is_dir():
            raise ValueError("local_model_directory_required")
        if not version or max_tokens < 16 or batch_size < 1:
            raise ValueError("invalid_embedding_configuration")
        from sentence_transformers import SentenceTransformer
        self._model = SentenceTransformer(str(path), local_files_only=True,
                                          trust_remote_code=False, device="cpu")
        self._tokenizer = self._model.tokenizer
        self.version = version
        self.dimensions = self._model.get_sentence_embedding_dimension()
        self._max_tokens = min(max_tokens, self._model.max_seq_length)
        self._batch_size = batch_size

    def _fits(self, text: str) -> bool:
        return len(self._tokenizer.encode(text, truncation=False)) <= self._max_tokens

    def split_passage(self, text: str) -> list[str]:
        # Binary-search codepoint boundaries; retain every character exactly.
        chunks = []
        start = 0
        while start < len(text):
            lo, hi = start + 1, min(len(text), start + self._max_tokens * 4)
            best = start
            while lo <= hi:
                mid = (lo + hi) // 2
                if self._fits("passage: " + text[start:mid]):
                    best, lo = mid, mid + 1
                else:
                    hi = mid - 1
            if best == start:
                raise ValueError("embedding_character_too_long")
            chunks.append(text[start:best])
            start = best
        return chunks

    def embed_passages(self, texts: Sequence[str]) -> list[list[float]]:
        inputs = ["passage: " + text for text in texts]
        if not all(self._fits(text) for text in inputs):
            raise ValueError("passage_too_long")
        return self._model.encode(inputs, batch_size=self._batch_size,
                                  normalize_embeddings=True,
                                  show_progress_bar=False).tolist()

    def embed_query(self, query: str) -> list[float]:
        text = "query: " + query
        if not self._fits(text):
            raise ValueError("query_too_long")
        return self._model.encode(text, normalize_embeddings=True,
                                  show_progress_bar=False).tolist()

    def prepare_query(self, query: str, *, context: Sequence[str] = ()) -> str:
        """Bound the actual prefixed input, including tokenizer special tokens.

        Keep the leading current input before spending remaining capacity on
        optional recent context. Token offsets avoid assumptions about bytes,
        scripts or code syntax; the final check also covers boundary retokenizing.
        """
        return prepare_embedding_query(self._tokenizer, query, max_tokens=self._max_tokens,
                                       context=context)
