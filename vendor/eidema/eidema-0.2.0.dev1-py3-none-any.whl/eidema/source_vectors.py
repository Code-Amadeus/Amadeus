"""A Store-local, bounded, read-only acceleration of the exact source scan."""

from dataclasses import dataclass, field
from time import perf_counter

import numpy as np


CAPACITY_BYTES = 64 * 1024 * 1024
PAGE = 256
DTYPE = np.dtype("<f4")
RESULT_FIELDS = "SELECT d.document_id,d.document_key,d.target_kind,d.target_version,"
_PHYSICAL_PAGE = (
    "SELECT document_id,chunk_no FROM retrieval_embeddings "
    "WHERE (document_id,chunk_no)>(?,?) ORDER BY document_id,chunk_no LIMIT ?"
)
_WINDOW = (
    " AND (e.document_id,e.chunk_no)>(?,?) AND (e.document_id,e.chunk_no)<=(?,?)"
    " ORDER BY e.document_id,e.chunk_no"
)


@dataclass(frozen=True)
class _Snapshot:
    stamp: tuple
    keys: tuple
    rows: tuple
    matrix: np.ndarray


@dataclass
class _Preparation:
    stamp: tuple
    sql: str
    model: object
    matrix: np.ndarray | None
    previous: _Snapshot | None
    old_keys: dict
    peak_bytes: int
    cursor: tuple = (0, -1)
    rows: list = field(default_factory=list)
    visited: int = 0
    loaded: int = 0
    reused: int = 0
    pages_ms: list = field(default_factory=list)
    status: str = "working"

    def receipt(self):
        return dict(status=self.status, pages_ms=self.pages_ms, physical_rows=self.visited,
                    blobs_loaded=self.loaded, vectors_reused=self.reused,
                    peak_bytes=self.peak_bytes, scratch_released=self.matrix is None)


class SourceVectors:
    """Owned by one Store connection. All calls run under that Store lock."""

    def __init__(self, db):
        self._db = db
        self.snapshot = None
        self.preparing = None
        self.last_decline = None
        self._install_index_clock()

    def _install_index_clock(self):
        # TEMP state belongs to the existing writer and rolls back with the
        # original vector writes. External commits change main.data_version.
        db = self._db
        db.execute("CREATE TEMP TABLE source_vector_clock "
                   "(document_id INTEGER PRIMARY KEY,generation INTEGER NOT NULL)")
        db.execute("INSERT INTO source_vector_clock VALUES(0,0)")
        advance = "UPDATE source_vector_clock SET generation=generation+1 WHERE document_id=0; "
        for event, labels in (("INSERT", ("new",)), ("UPDATE", ("old", "new")), ("DELETE", ("old",))):
            mark = "".join(
                f"INSERT INTO source_vector_clock VALUES({label}.document_id,"
                "(SELECT generation FROM source_vector_clock WHERE document_id=0)) "
                "ON CONFLICT(document_id) DO UPDATE SET generation=excluded.generation; "
                for label in labels
            )
            db.execute(f"CREATE TEMP TRIGGER source_vector_{event.lower()} AFTER {event} "
                       f"ON main.retrieval_embeddings BEGIN {advance}{mark}END")
        db.execute("CREATE TEMP TRIGGER source_vector_document AFTER UPDATE OF "
                   "document_key,index_state,index_version,index_dimensions,stream_id,target_version,target_kind "
                   f"ON main.retrieval_documents BEGIN {advance}END")
        db.execute("CREATE TEMP TRIGGER source_vector_scope AFTER UPDATE OF "
                   "user_id,character_id,project_id,scope_kind "
                   f"ON main.source_streams BEGIN {advance}END")

    def stamp(self, params, limit, model):
        generation = self._db.execute(
            "SELECT generation FROM source_vector_clock WHERE document_id=0").fetchone()[0]
        files = self._db.execute("PRAGMA main.data_version").fetchone()[0]
        return (params, limit, id(model), model.dimensions, generation, files)

    def current(self, params, limit, model):
        snapshot = self.snapshot
        if (snapshot is not None and not self._db.in_transaction
                and snapshot.stamp == self.stamp(params, limit, model)):
            return snapshot
        return None

    def discard(self, plan, reason):
        if self.preparing is plan:
            plan.status = reason
            plan.matrix = plan.previous = None
            plan.old_keys.clear()
            plan.rows.clear()
            self.preparing = None

    def reset(self):
        if self.preparing is not None:
            self.discard(self.preparing, "reset")
        self.snapshot = self.last_decline = None

    def begin(self, sql, params, limit, model):
        if self._db.in_transaction:
            return "writer_busy"
        stamp = self.stamp(params, limit, model)
        if self.snapshot is not None and self.snapshot.stamp == stamp:
            return "already_ready"
        if self.last_decline is not None and self.last_decline[0] == stamp:
            return self.last_decline[1]
        if self.preparing is not None:
            return "already_running"
        previous = self.snapshot
        # Reuse rows only across same-connection index changes in this scope.
        if previous is not None and (previous.stamp[:4] != stamp[:4]
                or previous.stamp[5] != stamp[5] or previous.stamp[4] > stamp[4]
                or previous.matrix.nbytes * 2 >= CAPACITY_BYTES):
            self.snapshot = previous = None
        resident = previous.matrix.nbytes if previous is not None else 0
        count = min(limit, (CAPACITY_BYTES - resident) // (model.dimensions * DTYPE.itemsize))
        if count <= 0:
            return "capacity"
        old_keys = {}
        if previous is not None:
            dirty = {row[0] for row in self._db.execute(
                "SELECT document_id FROM source_vector_clock WHERE document_id<>0 AND generation>?",
                (previous.stamp[4],))}
            old_keys = {key: index for index, key in enumerate(previous.keys) if key[0] not in dirty}
        matrix = np.empty((count, model.dimensions), dtype=DTYPE)
        plan = _Preparation(stamp, sql.replace(" JOIN ", " CROSS JOIN "), model, matrix,
                            previous, old_keys, resident + matrix.nbytes)
        self.preparing = plan
        return plan

    @staticmethod
    def _key(row):
        return (row["document_id"], row["target_version"], row["chunk_no"], row["vector_row"])

    def _fill(self, plan, rows):
        offset = len(plan.rows)
        if offset + len(rows) > len(plan.matrix):
            return False
        missing = []
        for slot, row in enumerate(rows, offset):
            key = self._key(row)
            prior = plan.old_keys.get(key)
            if prior is None:
                missing.append((slot, key[-1]))
            else:
                plan.matrix[slot] = plan.previous.matrix[prior]
        if missing:
            marks = ",".join("?" for _ in missing)
            data = dict(self._db.execute(
                f"SELECT rowid,vector FROM retrieval_embeddings WHERE rowid IN ({marks})",
                tuple(rowid for _, rowid in missing)))
            for slot, rowid in missing:
                content = data[rowid]
                if len(content) != plan.model.dimensions * DTYPE.itemsize:
                    raise ValueError("invalid_embedding")
                plan.matrix[slot] = np.frombuffer(content, dtype=DTYPE)
        plan.rows.extend(rows)
        plan.loaded += len(missing)
        plan.reused += len(rows) - len(missing)
        return True

    def _decline(self, plan, reason):
        self.last_decline = (plan.stamp, reason)
        self.discard(plan, reason)
        # Retained changes are useful only while an old resident is reusable.
        self.snapshot = None
        self._db.execute("DELETE FROM source_vector_clock WHERE document_id<>0")

    def step(self, plan, model):
        if self.preparing is not plan:
            return plan.status
        start = perf_counter()
        params, limit = plan.stamp[:2]
        try:
            if model is not plan.model or self.stamp(params, limit, model) != plan.stamp:
                self.discard(plan, "generation_changed")
                return plan.status
            physical = self._db.execute(_PHYSICAL_PAGE, (*plan.cursor, PAGE)).fetchall()
            plan.visited += len(physical)
            if plan.visited > limit:
                self._decline(plan, "scan_budget")
                return plan.status
            if physical:
                upper = tuple(physical[-1])
                rows = self._db.execute(RESULT_FIELDS + "e.rowid AS vector_row,e.chunk_no"
                    + plan.sql + _WINDOW, (*params, *plan.cursor, *upper)).fetchall()
                if not self._fill(plan, rows):
                    self._decline(plan, "capacity")
                    return plan.status
                plan.cursor = upper
            if len(physical) < PAGE:
                if self.stamp(params, limit, model) != plan.stamp:
                    self.discard(plan, "generation_changed")
                    return plan.status
                # No existing view references the builder's array.
                matrix = plan.matrix
                matrix.resize((len(plan.rows), model.dimensions), refcheck=False)
                self.snapshot = _Snapshot(plan.stamp, tuple(map(self._key, plan.rows)),
                                          tuple(plan.rows), matrix)
                self._db.execute("DELETE FROM source_vector_clock WHERE document_id<>0")
                self.discard(plan, "ready")
            return plan.status
        except BaseException:
            self.discard(plan, "failed")
            raise
        finally:
            plan.pages_ms.append((perf_counter() - start) * 1000)
