"""Opt-in whole-group source admission at the qualified formation read seam.

The trusted reader owns current committed-use evidence and source projection.
No old report body/identity is consumed here. Ordinary flat execution is unchanged.
"""
from .executor import FormationExecutor, SourceCapacityExceeded, _Stop
from .models import SourceContent, MemoryConflict, MemoryNotFound, MemoryValidationError


class GroupedCompanionExecutor(FormationExecutor):
    """Recheck companions for ACTUAL incrementals, under existing core gates.

    reader must expose used_companions and validate_used_companions in addition
    to read. All already-frozen inputs are mandatory. At most two distinct
    batch nominations (including already frozen nominated context) enter. Groups
    use proven proposal order, with incrementals visited in frozen task ordinal
    (feed coalescing order). This is not a semantic ranking policy.
    """
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.last_admission = None
        self._newly_prepared = False

    def _prepare_task(self, access, stream_id, pipeline_version, **planning):
        # Runs only for this opt-in executor, under the existing formation
        # lock and after permission/resource gates. A frozen task never grows.
        previous = self.maintenance.active_task(access, stream_id, pipeline_version,
            work_class=planning["work_class"], allow_reformation=planning["allow_reformation"])
        task = super()._prepare_task(access, stream_id, pipeline_version, **planning)
        self._newly_prepared = task is not None and (previous is None or previous.task_id != task.task_id)
        return task

    def _prepare_source_inputs(self, access, task, **planning):
        if not self._newly_prepared or task.attempts or not task.advances_cursor:
            self.last_admission = None
            return super()._prepare_source_inputs(access, task, **planning)
        report = dict(mandatory=len(task.inputs), selected=0, groups=[],
                      chars=0, utf8_bytes=0, releases=0, code="pending")
        self.last_admission = report
        cached, selected, proposals = {}, [], []
        chars = size = 0

        def gates():
            self._allowed()
            self._resource()
            self._check_budget(self.maintenance.budget_status(planning["window_id"]), self._now())
            self._current(access, task)

        def read(pin, remaining_chars, remaining_bytes):
            gates()
            content = self.reader.read(pin, max_chars=remaining_chars, max_bytes=remaining_bytes)
            if (not isinstance(content, SourceContent) or content.source != pin.source
                    or not isinstance(content.text, str) or not content.text):
                raise MemoryValidationError("invalid_source_content")
            if len(content.text) > remaining_chars or len(content.text.encode("utf-8")) > remaining_bytes:
                raise MemoryValidationError("invalid_source_capacity_receipt")
            gates()
            return content

        def capacity(error, pin, remaining_chars, remaining_bytes):
            if (error.pin != pin or type(error.chars) is not int or error.chars < 1
                    or type(error.utf8_bytes) is not int or error.utf8_bytes < 1
                    or (error.chars <= remaining_chars and error.utf8_bytes <= remaining_bytes)):
                raise MemoryValidationError("invalid_source_capacity_receipt")

        try:
            # This includes EVERY incremental in the real frozen batch, not a
            # caller estimate or just the revision that motivated one group.
            for pin in task.inputs:
                try:
                    content = read(pin, self.limits.source_chars-chars, self.limits.source_bytes-size)
                except SourceCapacityExceeded as error:
                    capacity(error, pin, self.limits.source_chars-chars, self.limits.source_bytes-size)
                    report.update(code="mandatory_capacity_exceeded", chars=chars+error.chars,
                                  utf8_bytes=size+error.utf8_bytes)
                    raise _Stop("blocked", "source_limit_exceeded") from None
                cached[pin] = content
                chars += len(content.text)
                size += len(content.text.encode("utf-8"))
            base_context = tuple(pin for pin, role in zip(task.inputs, task.input_roles) if role == "context")
            # Establish a batch-wide nomination window BEFORE capacity/fresh
            # filtering. Pins already frozen as context still consume their
            # nomination place on restart; cache membership grants no new slot.
            incrementals = {pin for pin, role in zip(task.inputs, task.input_roles) if role == "incremental"}
            nominated, bounded = set(), []
            for incoming, role in zip(task.inputs, task.input_roles):
                if role != "incremental":
                    continue
                gates()
                proposal = self.reader.used_companions(access, incoming, target_uses=task.target_uses)
                if proposal.status != "ready":
                    continue
                proposals.append(proposal)
                for group in proposal.groups:
                    members = set(group)-incrementals
                    receipt = dict(size=len(group), fresh=0, admitted=False)
                    report["groups"].append(receipt)
                    if len(nominated | members) > 2:
                        receipt["reason"] = "nomination_count"
                        continue
                    nominated.update(members)
                    bounded.append((group, receipt))
            report["nominated"] = len(nominated)
            for group, receipt in bounded:
                fresh = tuple(pin for pin in group if pin not in cached)
                receipt["fresh"] = len(fresh)
                if len(cached)+len(fresh) > planning["max_sources"]:
                    receipt["reason"] = "source_count"
                    continue
                trial, trial_chars, trial_bytes = {}, 0, 0
                try:
                    for pin in fresh:
                        content = read(pin, self.limits.source_chars-chars-trial_chars,
                                       self.limits.source_bytes-size-trial_bytes)
                        trial[pin] = content
                        trial_chars += len(content.text)
                        trial_bytes += len(content.text.encode("utf-8"))
                except SourceCapacityExceeded as error:
                    capacity(error, pin, self.limits.source_chars-chars-trial_chars, self.limits.source_bytes-size-trial_bytes)
                    receipt["reason"] = "source_capacity"
                    # Never carry a partial group into the frozen task,
                    # provider, or its full readset. Cache is step-local.
                    trial.clear()
                    content = None
                    continue
                cached.update(trial)
                chars += trial_chars
                size += trial_bytes
                selected.extend(fresh)
                receipt.update(admitted=True, reason="complete")
            for proposal in proposals:
                gates()
                self.reader.validate_used_companions(access, proposal)
            gates()
            if selected:
                original = task
                self.maintenance.release_unattempted(access, task.task_id)
                report["releases"] = 1
                self._allowed()
                task = self.maintenance.prepare(access, original.stream_id, original.pipeline_version,
                    max_events=planning["max_events"], max_sources=planning["max_sources"],
                    max_attempts=planning["max_attempts"], context_inputs=(*base_context, *selected),
                    work_class="warm", target_uses=planning["target_uses"],
                    allow_reformation=callable(getattr(self.provider, "prepare_reformation", None)))
                expected = {pin: role for pin, role in zip(original.inputs, original.input_roles)}
                expected.update((pin, "context") for pin in selected)
                if (task is None or task.cursor_before != original.cursor_before
                        or task.cursor_after != original.cursor_after
                        or dict(zip(task.inputs, task.input_roles)) != expected):
                    raise _Stop("deferred", "companion_source_snapshot_changed")
                for proposal in proposals:
                    self.reader.validate_used_companions(access, proposal)
                gates()
            report.update(selected=len(selected), chars=chars, utf8_bytes=size, code="admitted")

            def read_current(pin, **limits):
                # The normal executor applies its current/authorization gates
                # before and after each return and validates SourceContent.
                return cached[pin]
            return task, read_current
        except (OSError, MemoryConflict, MemoryNotFound, MemoryValidationError, UnicodeError) as error:
            report.update(code="admission_failed", error_type=type(error).__name__)
            raise _Stop("failed", "source_reader_failed") from None
