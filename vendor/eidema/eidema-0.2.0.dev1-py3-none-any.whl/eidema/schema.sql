CREATE TABLE IF NOT EXISTS store_state (
    singleton INTEGER PRIMARY KEY CHECK(singleton=1),
    schema_version INTEGER NOT NULL,
    change_seq INTEGER NOT NULL DEFAULT 0,
    cleanup_pending INTEGER NOT NULL DEFAULT 0
);
INSERT OR IGNORE INTO store_state(singleton,schema_version) VALUES(1,19);
CREATE TABLE IF NOT EXISTS memories (
    memory_id TEXT PRIMARY KEY,
    root_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    scope_kind TEXT NOT NULL CHECK(scope_kind IN ('character','project','shared')),
    character_id TEXT,
    project_id TEXT,
    text TEXT,
    kind TEXT NOT NULL,
    condition_text TEXT,
    state TEXT NOT NULL CHECK(state IN ('active','superseded','retracted')),
    status_reason TEXT CHECK(status_reason IN ('preference_changed','corrected_by_user')),
    replaced_by TEXT,
    row_version INTEGER NOT NULL,
    created_at_ms INTEGER NOT NULL,
    updated_at_ms INTEGER NOT NULL,
    index_state TEXT NOT NULL CHECK(index_state IN ('pending','ready','failed')),
    index_version TEXT,
    index_error TEXT,
    retention TEXT NOT NULL DEFAULT 'explicit' CHECK(retention IN ('explicit','dependent')),
    invalid_reason TEXT,
    use_mask INTEGER NOT NULL DEFAULT 3 CHECK(use_mask BETWEEN 0 AND 3),
    authorization_id TEXT REFERENCES derived_authorizations(authorization_id),
    authorization_generation INTEGER,
    CHECK((retention='explicit' AND text IS NOT NULL AND invalid_reason IS NULL AND authorization_id IS NULL AND authorization_generation IS NULL)
       OR (retention='dependent' AND authorization_id IS NOT NULL AND authorization_generation IS NOT NULL AND use_mask>0
           AND ((invalid_reason IS NULL AND text IS NOT NULL) OR (invalid_reason IS NOT NULL AND text IS NULL AND condition_text IS NULL))))
);
CREATE INDEX IF NOT EXISTS memory_scope ON memories(user_id,character_id,project_id,state);
CREATE INDEX IF NOT EXISTS memory_root ON memories(root_id);
CREATE TABLE IF NOT EXISTS receipts (
    memory_id TEXT PRIMARY KEY REFERENCES memories(memory_id) ON DELETE CASCADE,
    retained_text TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS origins (
    memory_id TEXT PRIMARY KEY REFERENCES memories(memory_id) ON DELETE CASCADE,
    namespace TEXT,
    record_key TEXT,
    revision INTEGER,
    start_cp INTEGER,
    end_cp INTEGER,
    candidate_id TEXT REFERENCES candidates(candidate_id),
    CHECK((candidate_id IS NULL AND namespace IS NOT NULL AND record_key IS NOT NULL AND revision IS NOT NULL)
       OR (candidate_id IS NOT NULL AND namespace IS NULL AND record_key IS NULL AND revision IS NULL AND start_cp IS NULL AND end_cp IS NULL))
);
CREATE INDEX IF NOT EXISTS origins_source ON origins(namespace,record_key,revision,memory_id);
CREATE INDEX IF NOT EXISTS origins_candidate ON origins(candidate_id,memory_id) WHERE candidate_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS operations (
    user_id TEXT NOT NULL,
    operation_id TEXT NOT NULL,
    item_id TEXT NOT NULL,
    operation_kind TEXT NOT NULL,
    memory_id TEXT,
    outcome TEXT NOT NULL,
    fingerprint TEXT,
    candidate_id TEXT REFERENCES candidates(candidate_id),
    reviewed_at_ms INTEGER,
    formation_task_id TEXT REFERENCES formation_tasks(task_id),
    PRIMARY KEY(user_id,operation_id,item_id)
);
CREATE TABLE IF NOT EXISTS forgotten (
    memory_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS exclusions (
    exclusion_id INTEGER PRIMARY KEY,
    user_id TEXT NOT NULL,
    namespace TEXT NOT NULL,
    record_key TEXT NOT NULL,
    revision INTEGER NOT NULL,
    start_cp INTEGER,
    end_cp INTEGER
);
CREATE INDEX IF NOT EXISTS exclusions_source ON exclusions(user_id,namespace,record_key,revision);
CREATE TABLE IF NOT EXISTS search_documents (
    document_id INTEGER PRIMARY KEY,
    memory_id TEXT NOT NULL UNIQUE REFERENCES memories(memory_id) ON DELETE CASCADE,
    row_version INTEGER NOT NULL,
    text TEXT NOT NULL
);
CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
    text, content='search_documents', content_rowid='document_id', tokenize='unicode61'
);
CREATE TRIGGER IF NOT EXISTS search_insert AFTER INSERT ON search_documents BEGIN
    INSERT INTO memory_fts(rowid,text) VALUES(new.document_id,new.text);
END;
CREATE TRIGGER IF NOT EXISTS search_delete AFTER DELETE ON search_documents BEGIN
    INSERT INTO memory_fts(memory_fts,rowid,text) VALUES('delete',old.document_id,old.text);
END;
CREATE TRIGGER IF NOT EXISTS search_update AFTER UPDATE ON search_documents BEGIN
    INSERT INTO memory_fts(memory_fts,rowid,text) VALUES('delete',old.document_id,old.text);
    INSERT INTO memory_fts(rowid,text) VALUES(new.document_id,new.text);
END;
CREATE TABLE IF NOT EXISTS embeddings (
    memory_id TEXT NOT NULL REFERENCES memories(memory_id) ON DELETE CASCADE,
    row_version INTEGER NOT NULL,
    embedding_version TEXT NOT NULL,
    chunk_no INTEGER NOT NULL,
    dimensions INTEGER NOT NULL,
    vector BLOB NOT NULL,
    PRIMARY KEY(memory_id,embedding_version,chunk_no)
);

-- Generated output dependencies are not source evidence or user operations.
-- Outputs are whole immutable source revisions; content lives only in the Host.
CREATE TABLE IF NOT EXISTS recall_uses (
    user_id TEXT NOT NULL,
    memory_id TEXT NOT NULL REFERENCES memories(memory_id) ON DELETE CASCADE,
    row_version INTEGER NOT NULL,
    namespace TEXT NOT NULL,
    record_key TEXT NOT NULL,
    revision INTEGER NOT NULL,
    PRIMARY KEY(user_id,namespace,record_key,revision,memory_id)
);
CREATE INDEX IF NOT EXISTS recall_uses_memory ON recall_uses(memory_id);
CREATE INDEX IF NOT EXISTS recall_uses_source ON recall_uses(user_id,namespace,record_key,revision,memory_id);

-- Schema12: a sealed complete output read set. No content or permission copy.
-- A tombstone survives permission ABA and removal of Memory edges by forget.
CREATE TABLE IF NOT EXISTS output_bindings (
    user_id TEXT NOT NULL,
    namespace TEXT NOT NULL,
    record_key TEXT NOT NULL,
    revision INTEGER NOT NULL,
    invalid_reason TEXT,
    privacy_invalidated INTEGER NOT NULL DEFAULT 0 CHECK(privacy_invalidated IN (0,1)),
    PRIMARY KEY(user_id,namespace,record_key,revision)
);
CREATE TABLE IF NOT EXISTS output_source_reads (
    user_id TEXT NOT NULL,
    namespace TEXT NOT NULL,
    record_key TEXT NOT NULL,
    revision INTEGER NOT NULL,
    source_namespace TEXT NOT NULL,
    source_record_key TEXT NOT NULL,
    source_revision INTEGER NOT NULL,
    state_version INTEGER NOT NULL,
    policy_revision TEXT NOT NULL,
    recorded_at_ms INTEGER,
    PRIMARY KEY(user_id,namespace,record_key,revision,source_namespace,source_record_key),
    FOREIGN KEY(user_id,namespace,record_key,revision) REFERENCES output_bindings(user_id,namespace,record_key,revision)
);
CREATE INDEX IF NOT EXISTS output_source_reads_source ON output_source_reads(user_id,source_namespace,source_record_key,source_revision);
CREATE TABLE IF NOT EXISTS output_parent_reads (
    user_id TEXT NOT NULL,
    namespace TEXT NOT NULL,
    record_key TEXT NOT NULL,
    revision INTEGER NOT NULL,
    parent_namespace TEXT NOT NULL,
    parent_record_key TEXT NOT NULL,
    parent_revision INTEGER NOT NULL,
    PRIMARY KEY(user_id,namespace,record_key,revision,parent_namespace,parent_record_key,parent_revision),
    FOREIGN KEY(user_id,namespace,record_key,revision) REFERENCES output_bindings(user_id,namespace,record_key,revision)
);
CREATE INDEX IF NOT EXISTS output_parent_reads_parent ON output_parent_reads(user_id,parent_namespace,parent_record_key,parent_revision);

-- Schema14: exact pending-body versions, distinct from delivered source reads.
CREATE TABLE IF NOT EXISTS output_candidate_reads (
    user_id TEXT NOT NULL,
    namespace TEXT NOT NULL,
    record_key TEXT NOT NULL,
    revision INTEGER NOT NULL,
    candidate_id TEXT NOT NULL REFERENCES candidates(candidate_id),
    row_version INTEGER NOT NULL CHECK(row_version>=1),
    PRIMARY KEY(user_id,namespace,record_key,revision,candidate_id),
    FOREIGN KEY(user_id,namespace,record_key,revision) REFERENCES output_bindings(user_id,namespace,record_key,revision)
);
CREATE INDEX IF NOT EXISTS output_candidate_reads_candidate ON output_candidate_reads(candidate_id,row_version,user_id);

-- Schema 3: Host metadata only. Canonical text and candidate bodies never enter
-- this ledger. Identities belong permanently to one registered source stream.
CREATE TABLE IF NOT EXISTS source_streams (
    stream_id TEXT PRIMARY KEY,
    scope_kind TEXT NOT NULL CHECK(scope_kind IN ('character','project','shared')),
    user_id TEXT NOT NULL,
    character_id TEXT,
    project_id TEXT,
    received_position INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS source_states (
    namespace TEXT NOT NULL,
    record_key TEXT NOT NULL,
    stream_id TEXT NOT NULL REFERENCES source_streams(stream_id),
    revision INTEGER NOT NULL,
    action TEXT NOT NULL CHECK(action IN ('upsert','withdraw')),
    formation_allowed INTEGER NOT NULL CHECK(formation_allowed IN (0,1)),
    policy_revision TEXT NOT NULL,
    recorded_at_ms INTEGER,
    state_version INTEGER NOT NULL,
    lookup_allowed INTEGER NOT NULL DEFAULT 0 CHECK(lookup_allowed IN (0,1)),
    derived_use_mask INTEGER NOT NULL DEFAULT 0 CHECK(derived_use_mask BETWEEN 0 AND 3),
    evidence_only INTEGER NOT NULL DEFAULT 0 CHECK(evidence_only IN (0,1)),
    PRIMARY KEY(namespace,record_key)
);
CREATE INDEX IF NOT EXISTS source_states_stream ON source_states(stream_id,action,lookup_allowed);
CREATE TABLE IF NOT EXISTS source_changes (
    stream_id TEXT NOT NULL REFERENCES source_streams(stream_id),
    position INTEGER NOT NULL,
    namespace TEXT NOT NULL,
    record_key TEXT NOT NULL,
    revision INTEGER NOT NULL,
    action TEXT NOT NULL CHECK(action IN ('upsert','withdraw')),
    formation_allowed INTEGER NOT NULL CHECK(formation_allowed IN (0,1)),
    policy_revision TEXT NOT NULL,
    recorded_at_ms INTEGER,
    state_version INTEGER NOT NULL,
    lookup_allowed INTEGER NOT NULL DEFAULT 0 CHECK(lookup_allowed IN (0,1)),
    derived_use_mask INTEGER NOT NULL DEFAULT 0 CHECK(derived_use_mask BETWEEN 0 AND 3),
    evidence_only INTEGER NOT NULL DEFAULT 0 CHECK(evidence_only IN (0,1)),
    PRIMARY KEY(stream_id,position)
);
CREATE TABLE IF NOT EXISTS formation_cursors (
    stream_id TEXT NOT NULL REFERENCES source_streams(stream_id),
    pipeline_version TEXT NOT NULL,
    position INTEGER NOT NULL,
    PRIMARY KEY(stream_id,pipeline_version)
);
-- One identity-only reason per enabled pipeline and real exclusion transaction.
-- A candidate's tag records that it was live before that transaction purged it.
CREATE TABLE IF NOT EXISTS reformation_config (
    stream_id TEXT NOT NULL REFERENCES source_streams(stream_id),
    pipeline_version TEXT NOT NULL,
    enabled INTEGER NOT NULL CHECK(enabled IN (0,1)),
    prefer_reformation INTEGER NOT NULL DEFAULT 1 CHECK(prefer_reformation IN (0,1)),
    PRIMARY KEY(stream_id,pipeline_version)
);
CREATE TABLE IF NOT EXISTS reformation_events (
    event_id INTEGER PRIMARY KEY AUTOINCREMENT,
    stream_id TEXT NOT NULL REFERENCES source_streams(stream_id),
    pipeline_version TEXT NOT NULL,
    reason TEXT NOT NULL CHECK(reason='source_excluded'),
    candidate_cursor TEXT NOT NULL DEFAULT '',
    state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','done'))
);
CREATE INDEX IF NOT EXISTS reformation_pending ON reformation_events(stream_id,pipeline_version,event_id) WHERE state='pending';
CREATE TABLE IF NOT EXISTS reformation_blocks (
    event_id INTEGER NOT NULL REFERENCES reformation_events(event_id),
    candidate_id TEXT NOT NULL REFERENCES candidates(candidate_id),
    reason TEXT NOT NULL CHECK(reason='source_limit_exceeded'),
    required_sources INTEGER NOT NULL,
    PRIMARY KEY(event_id,candidate_id)
);
CREATE TABLE IF NOT EXISTS formation_tasks (
    task_id TEXT PRIMARY KEY,
    stream_id TEXT NOT NULL REFERENCES source_streams(stream_id),
    pipeline_version TEXT NOT NULL,
    cursor_before INTEGER NOT NULL,
    cursor_after INTEGER NOT NULL,
    state TEXT NOT NULL CHECK(state IN ('pending','reserved','failed','truncated','unknown','stale','done','abandoned')),
    max_attempts INTEGER NOT NULL,
    current_attempt_id TEXT,
    work_class TEXT NOT NULL DEFAULT 'warm' CHECK(work_class IN ('warm','cold')),
    target_use_mask INTEGER NOT NULL DEFAULT 0 CHECK(target_use_mask BETWEEN 0 AND 3),
    reformation_event_id INTEGER REFERENCES reformation_events(event_id),
    reformation_candidate_id TEXT,
    reformation_key TEXT,
    maintenance_completion_order INTEGER
);
CREATE UNIQUE INDEX IF NOT EXISTS formation_one_active ON formation_tasks(stream_id,work_class) WHERE state NOT IN ('done','stale','abandoned') AND (reformation_event_id IS NULL OR state<>'pending');
CREATE INDEX IF NOT EXISTS formation_unresolved_tasks ON formation_tasks(stream_id,work_class) WHERE state NOT IN ('done','stale','abandoned');
CREATE INDEX IF NOT EXISTS formation_reformation_ready ON formation_tasks(stream_id,pipeline_version) WHERE reformation_event_id IS NOT NULL AND state='pending';
CREATE INDEX IF NOT EXISTS formation_reformation_resolved ON formation_tasks(stream_id,pipeline_version,reformation_event_id,reformation_candidate_id) WHERE reformation_event_id IS NOT NULL AND state IN ('done','abandoned');
CREATE UNIQUE INDEX IF NOT EXISTS formation_reformation_key ON formation_tasks(reformation_key) WHERE reformation_key IS NOT NULL;
CREATE INDEX IF NOT EXISTS formation_resolved_ranges ON formation_tasks(stream_id,pipeline_version,cursor_after) WHERE state IN ('done','abandoned');
CREATE INDEX IF NOT EXISTS formation_abandoned_ranges ON formation_tasks(stream_id,pipeline_version,cursor_before,cursor_after,task_id) WHERE state='abandoned';
CREATE TABLE IF NOT EXISTS formation_inputs (
    task_id TEXT NOT NULL REFERENCES formation_tasks(task_id),
    ordinal INTEGER NOT NULL,
    namespace TEXT NOT NULL,
    record_key TEXT NOT NULL,
    revision INTEGER NOT NULL,
    state_version INTEGER NOT NULL,
    policy_revision TEXT NOT NULL,
    recorded_at_ms INTEGER,
    input_role TEXT NOT NULL DEFAULT 'incremental' CHECK(input_role IN ('incremental','context')),
    PRIMARY KEY(task_id,ordinal),
    UNIQUE(task_id,namespace,record_key)
);
CREATE TABLE IF NOT EXISTS formation_processed_sources (
    stream_id TEXT NOT NULL REFERENCES source_streams(stream_id),
    pipeline_version TEXT NOT NULL,
    namespace TEXT NOT NULL,
    record_key TEXT NOT NULL,
    state_version INTEGER NOT NULL,
    PRIMARY KEY(stream_id,pipeline_version,namespace,record_key)
);
CREATE TABLE IF NOT EXISTS maintenance_budgets (
    window_id TEXT PRIMARY KEY,
    start_ms INTEGER NOT NULL,
    end_ms INTEGER NOT NULL,
    max_calls INTEGER NOT NULL,
    max_input_tokens INTEGER NOT NULL,
    max_output_tokens INTEGER NOT NULL,
    max_cost_units INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS maintenance_clock (
    singleton INTEGER PRIMARY KEY CHECK(singleton=1),
    last_reservation_ms INTEGER NOT NULL DEFAULT 0
);
INSERT OR IGNORE INTO maintenance_clock(singleton) VALUES(1);
CREATE TABLE IF NOT EXISTS formation_attempts (
    attempt_id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL REFERENCES formation_tasks(task_id),
    reservation_key TEXT NOT NULL,
    window_id TEXT NOT NULL REFERENCES maintenance_budgets(window_id),
    reserved_input_tokens INTEGER NOT NULL,
    reserved_output_tokens INTEGER NOT NULL,
    reserved_cost_units INTEGER NOT NULL,
    actual_input_tokens INTEGER,
    actual_output_tokens INTEGER,
    actual_cost_units INTEGER,
    outcome TEXT NOT NULL CHECK(outcome IN ('reserved','failed','truncated','unknown','stale','no_candidates','candidates')),
    reserved_at_ms INTEGER NOT NULL,
    cold_dispatched_at_ms INTEGER,
    UNIQUE(task_id,reservation_key),
    CHECK((actual_input_tokens IS NULL AND actual_output_tokens IS NULL AND actual_cost_units IS NULL)
       OR (actual_input_tokens IS NOT NULL AND actual_output_tokens IS NOT NULL AND actual_cost_units IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS formation_attempts_window ON formation_attempts(window_id);

-- Schema 4: pending proposals are deliberately outside M1 search/FTS/vectors.
-- Read sets remain authoritative in formation_inputs; evidence is per item.
CREATE INDEX IF NOT EXISTS formation_inputs_source ON formation_inputs(namespace,record_key,task_id);
CREATE INDEX IF NOT EXISTS source_changes_identity ON source_changes(stream_id,namespace,record_key,revision);
CREATE TABLE IF NOT EXISTS candidate_submissions (
    attempt_id TEXT PRIMARY KEY REFERENCES formation_attempts(attempt_id),
    fingerprint TEXT
);
CREATE TABLE IF NOT EXISTS candidates (
    candidate_id TEXT PRIMARY KEY,
    task_id TEXT NOT NULL REFERENCES formation_tasks(task_id),
    attempt_id TEXT NOT NULL REFERENCES candidate_submissions(attempt_id),
    item_key TEXT NOT NULL,
    text TEXT,
    kind TEXT NOT NULL CHECK(kind IN ('fact','preference','instruction','event','proposal','hypothesis')),
    condition_text TEXT,
    created_at_ms INTEGER NOT NULL,
    row_version INTEGER NOT NULL DEFAULT 1,
    state TEXT NOT NULL DEFAULT 'pending' CHECK(state IN ('pending','invalidated','accepted','rejected','published')),
    invalid_reason TEXT,
    index_state TEXT NOT NULL DEFAULT 'pending' CHECK(index_state IN ('pending','ready','inactive')),
    reformation_event_id INTEGER REFERENCES reformation_events(event_id),
    UNIQUE(attempt_id,item_key),
    CHECK((state='pending' AND text IS NOT NULL AND invalid_reason IS NULL AND index_state IN ('pending','ready'))
       OR (state='invalidated' AND text IS NULL AND condition_text IS NULL AND invalid_reason IS NOT NULL AND index_state='inactive')
       OR (state IN ('accepted','rejected','published') AND text IS NULL AND condition_text IS NULL AND invalid_reason IS NULL AND index_state='inactive'))
);
CREATE INDEX IF NOT EXISTS candidates_pending ON candidates(state,index_state,created_at_ms,candidate_id);
CREATE INDEX IF NOT EXISTS candidates_task ON candidates(task_id);
CREATE INDEX IF NOT EXISTS candidates_reformation ON candidates(reformation_event_id,candidate_id) WHERE reformation_event_id IS NOT NULL;
CREATE TABLE IF NOT EXISTS candidate_evidence (
    candidate_id TEXT NOT NULL REFERENCES candidates(candidate_id),
    ordinal INTEGER NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('support','transition')),
    group_no INTEGER NOT NULL CHECK(group_no=0),
    namespace TEXT NOT NULL,
    record_key TEXT NOT NULL,
    revision INTEGER NOT NULL,
    start_cp INTEGER NOT NULL,
    end_cp INTEGER NOT NULL CHECK(end_cp>start_cp AND start_cp>=0),
    PRIMARY KEY(candidate_id,ordinal)
);
CREATE INDEX IF NOT EXISTS candidate_evidence_source ON candidate_evidence(namespace,record_key,revision,candidate_id);

CREATE TABLE IF NOT EXISTS candidate_comparisons (
    candidate_id TEXT PRIMARY KEY REFERENCES candidates(candidate_id) ON DELETE CASCADE,
    comparison_kind TEXT NOT NULL CHECK(comparison_kind IN ('reported_change','reported_correction','coexisting','unresolved')),
    left_ordinal INTEGER NOT NULL,
    right_ordinal INTEGER NOT NULL,
    CHECK(left_ordinal<>right_ordinal),
    FOREIGN KEY(candidate_id,left_ordinal) REFERENCES candidate_evidence(candidate_id,ordinal),
    FOREIGN KEY(candidate_id,right_ordinal) REFERENCES candidate_evidence(candidate_id,ordinal)
);

-- Schema 6: a reviewed memory references the candidate's one evidence graph.
-- This is provenance, never a second copy of memory content or lifecycle state.
CREATE UNIQUE INDEX IF NOT EXISTS operations_candidate ON operations(candidate_id) WHERE candidate_id IS NOT NULL;
CREATE VIEW IF NOT EXISTS memory_sources AS
    SELECT memory_id,namespace,record_key,revision,start_cp,end_cp FROM origins WHERE candidate_id IS NULL
    UNION
    SELECT o.memory_id,e.namespace,e.record_key,e.revision,e.start_cp,e.end_cp
    FROM origins o JOIN candidate_evidence e ON e.candidate_id=o.candidate_id;

-- Comparison inputs are provenance, not assertions owned by that comparison.
-- Ordinary retirement and full-provenance privacy/forget remain distinct.
CREATE VIEW IF NOT EXISTS memory_retirement_sources AS
    SELECT s.* FROM memory_sources s
    WHERE NOT EXISTS (
        SELECT 1 FROM origins o JOIN candidate_comparisons c ON c.candidate_id=o.candidate_id
        WHERE o.memory_id=s.memory_id
    );

-- Schema 5: deletable, purpose-separated caches. Source/candidate authority
-- remains in the ledger above. IDs are never reused, even after privacy purge.
CREATE TABLE IF NOT EXISTS retrieval_documents (
    document_id INTEGER PRIMARY KEY AUTOINCREMENT,
    document_key TEXT NOT NULL UNIQUE,
    target_kind TEXT NOT NULL CHECK(target_kind IN ('source','candidate')),
    stream_id TEXT NOT NULL REFERENCES source_streams(stream_id),
    namespace TEXT,
    record_key TEXT,
    revision INTEGER,
    candidate_id TEXT REFERENCES candidates(candidate_id) ON DELETE CASCADE,
    target_version INTEGER NOT NULL,
    body TEXT NOT NULL,
    condition_text TEXT,
    lexical_text TEXT NOT NULL,
    index_state TEXT NOT NULL DEFAULT 'pending' CHECK(index_state IN ('pending','ready','failed')),
    index_version TEXT,
    index_dimensions INTEGER,
    index_error TEXT,
    CHECK((target_kind='source' AND namespace IS NOT NULL AND record_key IS NOT NULL
           AND revision IS NOT NULL AND candidate_id IS NULL AND condition_text IS NULL)
       OR (target_kind='candidate' AND namespace IS NULL AND record_key IS NULL
           AND revision IS NULL AND candidate_id IS NOT NULL))
);
CREATE UNIQUE INDEX IF NOT EXISTS retrieval_source ON retrieval_documents(namespace,record_key) WHERE target_kind='source';
CREATE UNIQUE INDEX IF NOT EXISTS retrieval_candidate ON retrieval_documents(candidate_id) WHERE target_kind='candidate';
CREATE INDEX IF NOT EXISTS retrieval_scope ON retrieval_documents(stream_id,target_kind,index_state,document_id);
CREATE VIRTUAL TABLE IF NOT EXISTS retrieval_fts USING fts5(
    lexical_text, content='retrieval_documents', content_rowid='document_id', tokenize='unicode61'
);
CREATE TABLE IF NOT EXISTS retrieval_embeddings (
    document_id INTEGER NOT NULL REFERENCES retrieval_documents(document_id) ON DELETE CASCADE,
    embedding_version TEXT NOT NULL,
    chunk_no INTEGER NOT NULL,
    dimensions INTEGER NOT NULL,
    vector BLOB NOT NULL,
    PRIMARY KEY(document_id,chunk_no)
);
CREATE TRIGGER IF NOT EXISTS retrieval_insert AFTER INSERT ON retrieval_documents BEGIN
    INSERT INTO retrieval_fts(rowid,lexical_text) VALUES(new.document_id,new.lexical_text);
END;
CREATE TRIGGER IF NOT EXISTS retrieval_delete AFTER DELETE ON retrieval_documents BEGIN
    INSERT INTO retrieval_fts(retrieval_fts,rowid,lexical_text) VALUES('delete',old.document_id,old.lexical_text);
    UPDATE candidates SET index_state='pending' WHERE candidate_id=old.candidate_id AND state='pending' AND index_state='ready';
    UPDATE store_state SET cleanup_pending=1;
END;
CREATE TRIGGER IF NOT EXISTS retrieval_vector_delete AFTER DELETE ON retrieval_embeddings BEGIN
    UPDATE store_state SET cleanup_pending=1;
END;
CREATE TRIGGER IF NOT EXISTS retrieval_source_change AFTER UPDATE ON source_states
WHEN old.state_version<>new.state_version BEGIN
    DELETE FROM retrieval_documents WHERE target_kind='source' AND namespace=old.namespace AND record_key=old.record_key;
END;
CREATE TRIGGER IF NOT EXISTS retrieval_candidate_change AFTER UPDATE ON candidates
WHEN new.state<>'pending' OR old.row_version<>new.row_version OR old.text IS NOT new.text OR old.condition_text IS NOT new.condition_text BEGIN
    DELETE FROM retrieval_documents WHERE candidate_id=old.candidate_id;
END;
CREATE TRIGGER IF NOT EXISTS retrieval_exclusion AFTER INSERT ON exclusions BEGIN
    DELETE FROM retrieval_documents WHERE target_kind='source' AND namespace=new.namespace AND record_key=new.record_key
      AND stream_id IN (SELECT stream_id FROM source_streams WHERE user_id=new.user_id);
END;

-- Schema 7: Host approval identifies immutable pipeline configuration only.
-- Generation is revocation authority; enabling never resurrects earlier rows.
CREATE TABLE IF NOT EXISTS derived_authorizations (
    authorization_id TEXT PRIMARY KEY,
    stream_id TEXT NOT NULL REFERENCES source_streams(stream_id),
    policy_id TEXT NOT NULL,
    policy_version TEXT NOT NULL,
    pipeline_version TEXT NOT NULL,
    generation INTEGER NOT NULL CHECK(generation>=1),
    enabled INTEGER NOT NULL DEFAULT 0 CHECK(enabled IN (0,1)),
    UNIQUE(stream_id,policy_id,policy_version)
);
CREATE INDEX IF NOT EXISTS memory_authorization ON memories(authorization_id,authorization_generation) WHERE retention='dependent';

-- Schema 16: declared coordinates of isolated quote failures, never evidence.
-- An ordinal refers only to the immutable input set of this attempt's task.
CREATE TABLE IF NOT EXISTS formation_quote_failures (
    attempt_id TEXT NOT NULL REFERENCES candidate_submissions(attempt_id),
    item_key TEXT NOT NULL,
    error_code TEXT NOT NULL CHECK(error_code IN ('quote_not_found','quote_not_unique')),
    input_ordinal INTEGER NOT NULL CHECK(input_ordinal>=0),
    declared_role_mask INTEGER NOT NULL CHECK(declared_role_mask BETWEEN 1 AND 3),
    PRIMARY KEY(attempt_id,item_key,input_ordinal)
);

-- Consumed recommendation provenance, distinct from text actually shown.
-- Ancestor rows are a bounded materialized closure; direct marks the selected
-- old failed group. Strictly earlier parent tasks make cycles impossible.
CREATE TABLE IF NOT EXISTS formation_gap_handoffs (
    task_id TEXT NOT NULL REFERENCES formation_tasks(task_id),
    parent_task_id TEXT NOT NULL REFERENCES formation_tasks(task_id),
    item_key TEXT NOT NULL,
    direct INTEGER NOT NULL CHECK(direct IN (0,1)),
    PRIMARY KEY(task_id,parent_task_id,item_key),
    CHECK(task_id<>parent_task_id)
);
CREATE INDEX IF NOT EXISTS formation_gap_handoffs_parent ON formation_gap_handoffs(parent_task_id,task_id);
CREATE VIEW IF NOT EXISTS formation_authority_inputs AS
    SELECT task_id,namespace,record_key,revision,state_version,policy_revision,recorded_at_ms FROM formation_inputs
    UNION
    SELECT h.task_id,i.namespace,i.record_key,i.revision,i.state_version,i.policy_revision,i.recorded_at_ms
    FROM formation_gap_handoffs h JOIN formation_inputs i ON i.task_id=h.parent_task_id;

-- Derived terminal order, not a scheduler, body store or accounting ledger.
CREATE UNIQUE INDEX IF NOT EXISTS formation_maintenance_resolved
    ON formation_tasks(stream_id,pipeline_version,maintenance_completion_order)
    WHERE maintenance_completion_order IS NOT NULL AND state IN ('done','abandoned');
