"""Opt-in source-exclusion work; identities only, never replayed model text.

An exclusion tags the previously live reports in its owning transaction. One
event is then paged through the candidate index, at most max_events per prepare.
The existing immutable evidence and original input pins are the sole root list.
"""
from dataclasses import dataclass
from hashlib import sha256
import json
from uuid import uuid4

from .models import MemoryConflict, MemoryNotFound, MemoryScope, SourceSpan, MemoryValidationError


@dataclass(frozen=True)
class ReformationEvent:
    event_id: int
    stream_id: str
    pipeline_version: str
    reason: str
    state: str
    candidate_cursor: str
    remaining: int
    blocked_groups: int = 0


@dataclass(frozen=True)
class ReformationBlock:
    event_id: int
    candidate_id: str
    reason: str
    required_sources: int


def list_blocks(m, access, stream_id, pipeline_version, *, limit=100):
    from .maintenance import _integer
    from .sources import _identity
    _identity(pipeline_version)
    _integer(limit, "block_limit", 1, 1000)
    with m._store._lock:
        m._store._check()
        m._stream(access, stream_id)
        return tuple(ReformationBlock(*row) for row in m._db.execute("SELECT b.event_id,b.candidate_id,b.reason,b.required_sources FROM reformation_blocks b JOIN reformation_events e ON e.event_id=b.event_id WHERE e.stream_id=? AND e.pipeline_version=? ORDER BY b.event_id,b.candidate_id LIMIT ?", (stream_id,pipeline_version,limit)))


def configure(m, access, stream_id, pipeline_version, *, enabled=False):
    from .sources import _identity
    _identity(pipeline_version)
    if type(enabled) is not bool:
        raise MemoryValidationError("invalid_reformation_config")
    with m._store._lock:
        m._store._check()
        with m._store._transaction():
            m._stream(access, stream_id)
            m._db.execute("INSERT INTO reformation_config(stream_id,pipeline_version,enabled) VALUES(?,?,?) ON CONFLICT(stream_id,pipeline_version) DO UPDATE SET enabled=excluded.enabled", (stream_id, pipeline_version, int(enabled)))


def enabled(m, stream_id, pipeline_version):
    row = m._db.execute("SELECT enabled FROM reformation_config WHERE stream_id=? AND pipeline_version=?", (stream_id, pipeline_version)).fetchone()
    return bool(row and row[0])


def capture(m, access, sources):
    """Called before privacy purge, after exclusion facts, in its transaction.

    Tagging shares the indexed affected-read-set relation with that purge. No
    generated content is opened and no per-report work is run in this mutation.
    Already rejected/withdrawn/invalid reports cannot acquire this live marker.
    """
    db = m._db
    keys = tuple(dict.fromkeys((s.namespace,s.record_key) for s in sources))
    if not keys:
        return
    pins = tuple(value for key in keys for value in key)
    affected = "WITH affected(namespace,record_key) AS (VALUES " + ",".join("(?,?)" for _ in keys) + ") "
    # Source identities drive the existing indexed read-set lookup. CROSS JOIN
    # keeps unrelated config/pending indexes from becoming the outer scan.
    relation = """FROM affected a CROSS JOIN formation_inputs i
                CROSS JOIN formation_tasks t CROSS JOIN candidates c
                CROSS JOIN reformation_config r CROSS JOIN source_streams s
                WHERE i.namespace=a.namespace AND i.record_key=a.record_key
                AND t.task_id=i.task_id AND c.task_id=t.task_id
                AND r.stream_id=t.stream_id AND r.pipeline_version=t.pipeline_version
                AND s.stream_id=t.stream_id AND s.user_id=? AND r.enabled=1
                AND t.work_class='warm' AND c.reformation_event_id IS NULL
                AND (c.state='pending' OR (c.state='published'
                    AND EXISTS(SELECT 1 FROM origins o JOIN memories d ON d.memory_id=o.memory_id
                        JOIN derived_authorizations auth ON auth.authorization_id=d.authorization_id
                        WHERE o.candidate_id=c.candidate_id AND d.retention='dependent'
                        AND d.state='active' AND d.invalid_reason IS NULL AND auth.enabled=1
                        AND d.authorization_generation=auth.generation)))
                AND EXISTS(SELECT 1 FROM candidate_evidence e WHERE e.candidate_id=c.candidate_id)
                AND NOT EXISTS(SELECT 1 FROM candidate_evidence e JOIN exclusions x
                    ON x.namespace=e.namespace AND x.record_key=e.record_key
                    WHERE e.candidate_id=c.candidate_id AND x.user_id=s.user_id)"""
    configs = db.execute(affected + "SELECT DISTINCT r.stream_id,r.pipeline_version " + relation, (*pins,access.user_id)).fetchall()
    for config in configs:
        event_id = db.execute("INSERT INTO reformation_events(stream_id,pipeline_version,reason) VALUES(?,?,'source_excluded')", (config["stream_id"], config["pipeline_version"])).lastrowid
        db.execute(affected + "UPDATE candidates SET reformation_event_id=? WHERE candidate_id IN (SELECT c.candidate_id " + relation + " AND t.stream_id=? AND t.pipeline_version=?)", (*pins,event_id,access.user_id,config["stream_id"],config["pipeline_version"]))


def list_events(m, access, stream_id, pipeline_version, *, limit=100):
    from .maintenance import _integer
    from .sources import _identity
    _identity(pipeline_version)
    _integer(limit, "event_limit", 1, 1000)
    with m._store._lock:
        m._store._check()
        m._stream(access, stream_id)
        return tuple(ReformationEvent(r["event_id"], r["stream_id"], r["pipeline_version"], r["reason"], r["state"], r["candidate_cursor"], m._db.execute("SELECT count(*) FROM candidates WHERE reformation_event_id=? AND candidate_id>?", (r["event_id"], r["candidate_cursor"])).fetchone()[0], m._db.execute("SELECT count(*) FROM reformation_blocks WHERE event_id=?", (r["event_id"],)).fetchone()[0]) for r in m._db.execute("SELECT * FROM reformation_events WHERE stream_id=? AND pipeline_version=? ORDER BY event_id DESC LIMIT ?", (stream_id, pipeline_version, limit)))


def pending(m, access, stream_id, pipeline_version):
    with m._store._lock:
        m._store._check()
        m._stream(access, stream_id)
        return enabled(m, stream_id, pipeline_version) and (m._db.execute("SELECT 1 FROM reformation_events WHERE stream_id=? AND pipeline_version=? AND state='pending' LIMIT 1", (stream_id, pipeline_version)).fetchone() is not None or m._db.execute("SELECT 1 FROM formation_tasks WHERE stream_id=? AND pipeline_version=? AND reformation_event_id IS NOT NULL AND state='pending' LIMIT 1", (stream_id,pipeline_version)).fetchone() is not None)


def due(m, access, stream_id, pipeline_version):
    """One shared cause choice; metadata paging also yields to ordinary work."""
    with m._store._lock:
        m._store._check()
        stream = m._stream(access, stream_id)
        config = m._db.execute("SELECT enabled,prefer_reformation FROM reformation_config WHERE stream_id=? AND pipeline_version=?", (stream_id,pipeline_version)).fetchone()
        return bool(config and config["enabled"] and (config["prefer_reformation"] or stream["received_position"] <= m._cursor(stream_id,pipeline_version)) and m._db.execute("SELECT 1 FROM reformation_events WHERE stream_id=? AND pipeline_version=? AND state='pending' LIMIT 1", (stream_id,pipeline_version)).fetchone())


def _finish_scanned_event(m, event):
    """Only an exhausted candidate cursor and terminal tasks close a cause."""
    if m._db.execute("SELECT 1 FROM candidates WHERE reformation_event_id=? AND candidate_id>? LIMIT 1", (event["event_id"], event["candidate_cursor"])).fetchone():
        return False
    if m._db.execute("SELECT 1 FROM formation_tasks WHERE stream_id=? AND work_class='warm' AND state NOT IN ('done','stale','abandoned') AND reformation_event_id=? LIMIT 1", (event["stream_id"], event["event_id"])).fetchone():
        return False
    m._db.execute("UPDATE reformation_events SET state='done' WHERE event_id=?", (event["event_id"],))
    return True


def finalize(m, access, stream_id, pipeline_version):
    """One metadata-only planning unit; the runtime owns prior postwork ACKs."""
    from .sources import _identity
    _identity(pipeline_version)
    with m._store._lock:
        m._store._check()
        with m._store._transaction():
            m._stream(access, stream_id)
            if not due(m, access, stream_id, pipeline_version):
                return False
            event = m._db.execute("SELECT * FROM reformation_events WHERE stream_id=? AND pipeline_version=? AND state='pending' ORDER BY event_id LIMIT 1", (stream_id, pipeline_version)).fetchone()
            if event is None or not _finish_scanned_event(m, event):
                return False
            m._db.execute("UPDATE reformation_config SET prefer_reformation=0 WHERE stream_id=? AND pipeline_version=?", (stream_id, pipeline_version))
            return True


def prepare(m, access, stream, pipeline_version, target_mask, *, max_events, max_sources, max_attempts):
    from .maintenance import SourceInput
    db, stream_id = m._db, stream["stream_id"]
    if not enabled(m, stream_id, pipeline_version):
        return None
    event = db.execute("SELECT * FROM reformation_events WHERE stream_id=? AND pipeline_version=? AND state='pending' ORDER BY event_id LIMIT 1", (stream_id, pipeline_version)).fetchone()
    if event is None:
        return None
    scope = MemoryScope(stream["scope_kind"], stream["user_id"], stream["character_id"], stream["project_id"])
    retirements = m._store.source_retirements(access)
    candidates = db.execute("SELECT c.candidate_id,c.task_id,c.state,t.target_use_mask FROM candidates c JOIN formation_tasks t ON t.task_id=c.task_id WHERE c.reformation_event_id=? AND c.candidate_id>? ORDER BY c.candidate_id LIMIT ?", (event["event_id"], event["candidate_cursor"], max_events)).fetchall()
    for candidate in candidates:
        roots = db.execute("SELECT DISTINCT i.* FROM candidate_evidence e JOIN formation_inputs i ON i.task_id=? AND i.namespace=e.namespace AND i.record_key=e.record_key AND i.revision=e.revision WHERE e.candidate_id=? ORDER BY i.namespace,i.record_key LIMIT ?", (candidate["task_id"], candidate["candidate_id"], max_sources+1)).fetchall()
        # An oversized group stays observable without blocking later groups or
        # ordinary deltas. This cause is resolved as blocked, never as success.
        if len(roots) > max_sources:
            required = db.execute("SELECT count(*) FROM (SELECT DISTINCT namespace,record_key,revision FROM candidate_evidence WHERE candidate_id=?)", (candidate["candidate_id"],)).fetchone()[0]
            db.execute("INSERT OR IGNORE INTO reformation_blocks(event_id,candidate_id,reason,required_sources) VALUES(?,?,'source_limit_exceeded',?)", (event["event_id"], candidate["candidate_id"], required))
            db.execute("UPDATE reformation_events SET candidate_cursor=? WHERE event_id=?", (candidate["candidate_id"], event["event_id"]))
            continue
        inputs = tuple(SourceInput(SourceSpan(r["namespace"], r["record_key"], r["revision"]), r["state_version"], r["policy_revision"], r["recorded_at_ms"]) for r in roots)
        allowed_mask = target_mask
        good = bool(inputs) and candidate["target_use_mask"] == target_mask
        if candidate["state"] == "published":
            original = db.execute("SELECT d.use_mask FROM origins o JOIN memories d ON d.memory_id=o.memory_id JOIN derived_authorizations a ON a.authorization_id=d.authorization_id WHERE o.candidate_id=? AND d.retention='dependent' AND d.state='active' AND d.invalid_reason='source_excluded' AND a.enabled=1 AND a.generation=d.authorization_generation", (candidate["candidate_id"],)).fetchone()
            good = good and original is not None
            allowed_mask = original[0] & (target_mask or 3) if original else 0
            good = good and bool(allowed_mask)
        evidence_count = db.execute("SELECT count(*) FROM (SELECT DISTINCT namespace,record_key,revision FROM candidate_evidence WHERE candidate_id=?)", (candidate["candidate_id"],)).fetchone()[0]
        good = good and evidence_count == len(inputs)
        for item in inputs:
            try:
                m._reformation_input(access, item, scope, allowed_mask, retirements)
            except (MemoryConflict, MemoryNotFound, MemoryValidationError):
                good = False
        db.execute("UPDATE reformation_events SET candidate_cursor=? WHERE event_id=?", (candidate["candidate_id"], event["event_id"]))
        if not good:
            continue
        key = sha256(json.dumps([event["event_id"], stream_id, pipeline_version, allowed_mask, [(i.source.namespace,i.source.record_key,i.source.revision,i.state_version,i.policy_revision,i.recorded_at_ms) for i in inputs]], separators=(",", ":")).encode()).hexdigest()
        if db.execute("SELECT 1 FROM formation_tasks WHERE reformation_key=?", (key,)).fetchone():
            continue
        task_id, position = uuid4().hex, m._cursor(stream_id, pipeline_version)
        db.execute("INSERT INTO formation_tasks(task_id,stream_id,pipeline_version,cursor_before,cursor_after,state,max_attempts,work_class,target_use_mask,reformation_event_id,reformation_candidate_id,reformation_key) VALUES(?,?,?,?,?,'pending',?,'warm',?,?,?,?)", (task_id,stream_id,pipeline_version,position,position,max_attempts,allowed_mask,event["event_id"],candidate["candidate_id"],key))
        for ordinal, item in enumerate(inputs):
            db.execute("INSERT INTO formation_inputs(task_id,ordinal,namespace,record_key,revision,state_version,policy_revision,recorded_at_ms,input_role) VALUES(?,?,?,?,?,?,?,?,'context')", (task_id,ordinal,item.source.namespace,item.source.record_key,item.source.revision,item.state_version,item.policy_revision,item.recorded_at_ms))
        return m._task(m._task_row(access, task_id))
    if len(candidates) < max_events:
        # The loop may have advanced the cursor without creating a task.
        event = db.execute("SELECT * FROM reformation_events WHERE event_id=?", (event["event_id"],)).fetchone()
        _finish_scanned_event(m, event)
    return None
