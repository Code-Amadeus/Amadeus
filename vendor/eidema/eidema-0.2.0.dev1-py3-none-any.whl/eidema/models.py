"""Host-authored identities and immutable, serializable memory results."""
from dataclasses import dataclass
from typing import Literal


class MemoryError(Exception):
    """Base error. Messages contain codes, never memory bodies."""


class MemoryConflict(MemoryError):
    pass


class MemoryNotFound(MemoryError):
    pass


class MemoryValidationError(MemoryError):
    pass


@dataclass(frozen=True)
class AccessScope:
    user_id: str
    character_id: str
    project_id: str | None = None


@dataclass(frozen=True)
class MemoryScope:
    kind: Literal["character", "project", "shared"]
    user_id: str
    character_id: str | None = None
    project_id: str | None = None


@dataclass(frozen=True)
class SourceSpan:
    namespace: str
    record_key: str
    revision: int
    start_cp: int | None = None
    end_cp: int | None = None


@dataclass(frozen=True)
class SourceContent:
    """A complete canonical record returned by the trusted Host Reader."""
    source: SourceSpan
    text: str
    speaker_role: str = "unknown"
    speaker_ref: str | None = None


@dataclass(frozen=True)
class SourceRetirement:
    source: SourceSpan
    reason: str


@dataclass(frozen=True)
class Memory:
    memory_id: str
    root_id: str
    scope: MemoryScope
    text: str | None
    kind: str
    condition: str | None
    state: str
    status_reason: str | None
    replaced_by: str | None
    row_version: int
    created_at_ms: int
    updated_at_ms: int
    index_state: str
    source: SourceSpan | None = None
    source_candidate_id: str | None = None
    retention: Literal["explicit", "dependent"] = "explicit"
    invalid_reason: str | None = None
    uses: tuple[str, ...] = ("lookup", "ordinary")


@dataclass(frozen=True)
class MemoryDetail:
    memory: Memory
    history: tuple[Memory, ...]


@dataclass(frozen=True)
class ForgetTarget:
    memory_id: str
    row_version: int


@dataclass(frozen=True)
class ForgetPreview:
    targets: tuple[ForgetTarget, ...]
    memories: tuple[Memory, ...]
    source_exclusions: tuple[SourceSpan, ...]
    dependent_targets: tuple[ForgetTarget, ...] = ()
    # Current, access-visible effects only. These never expand confirmation or
    # deletion roots. Output coordinates do not authorize displaying Host text.
    invalidated_memories: tuple[Memory, ...] = ()
    invalidated_outputs: tuple[SourceSpan, ...] = ()


@dataclass(frozen=True)
class OperationResult:
    status: str
    memory_id: str | None
    row_version: int | None
    replayed: bool
    index_state: str | None
    cleanup_pending: bool = False


@dataclass(frozen=True)
class MutationPreview:
    source_spans: tuple[SourceSpan, ...]
    memory_ids: tuple[str, ...] = ()
    replay: OperationResult | None = None


@dataclass(frozen=True)
class SourcePolicySnapshot:
    exclusions: tuple[SourceSpan, ...]
    retirements: tuple[SourceRetirement, ...]
    change_seq: int


@dataclass(frozen=True)
class RecallReference:
    """Content-free versioned dependency carried across Host model calls."""
    memory_id: str
    row_version: int


@dataclass(frozen=True)
class RecallCandidate:
    memory_id: str
    row_version: int
    text: str
    kind: str
    condition: str | None
    scope: MemoryScope
    source: SourceSpan | None
    score: float = 0.0
    semantic_score: float | None = None
    lexical_match: bool = False
    retention: Literal["explicit", "dependent"] = "explicit"


@dataclass(frozen=True)
class RecallCoverage:
    semantic: str  # ready / partial / unavailable / failed / busy
    active_memories: int
    indexed_memories: int
    pending_memories: int
    failed_memories: int
    scanned_vectors: int = 0
    scan_limited: bool = False
    budget_omitted: int = 0
    semantic_threshold: float | None = None


@dataclass(frozen=True)
class RecallResult:
    candidates: tuple[RecallCandidate, ...]
    coverage: RecallCoverage
    change_seq: int


@dataclass(frozen=True)
class StoreStatus:
    active_memories: int
    indexed_memories: int
    pending_memories: int
    failed_memories: int
    semantic: str
    embedding_version: str | None
    cleanup_pending: bool
    change_seq: int


@dataclass(frozen=True)
class IndexResult:
    attempted: int
    indexed: int
    failed: int
    stale: int
    busy: bool = False
