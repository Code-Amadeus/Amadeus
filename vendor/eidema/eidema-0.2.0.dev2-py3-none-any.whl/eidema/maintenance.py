"""Content-free committed sources and explicitly driven, bounded formation work.

The Host owns canonical text, feed order, identity and external-call permission.
This facade borrows the store's sole connection, owner and transaction lock.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
from typing import Literal, Sequence
from uuid import uuid4

from .models import AccessScope, MemoryScope, SourceSpan, MemoryConflict, MemoryNotFound, MemoryValidationError
from .sources import _identity, _validate_source


_MAX_INTEGER = 2**63 - 1
_MAX_BATCH = 1000
_COLD_WINDOW_MS = 86_400_000


def _integer(value, name, minimum=0, maximum=_MAX_INTEGER):
    if not isinstance(value, int) or isinstance(value, bool) or not minimum <= value <= maximum:
        raise MemoryValidationError("invalid_" + name)


def _target_use_mask(uses):
    if uses is None:
        return None
    if not isinstance(uses, (list, tuple)):
        raise MemoryValidationError("invalid_target_uses")
    uses = tuple(uses)
    if any(not isinstance(p, str) or p not in ("lookup", "ordinary") for p in uses):
        raise MemoryValidationError("invalid_target_uses")
    return sum({1 if p == "lookup" else 2 for p in uses})


@dataclass(frozen=True)
class SourceChange:
    position: int
    source: SourceSpan
    action: Literal["upsert", "withdraw"]
    formation_allowed: bool
    policy_revision: str
    recorded_at_ms: int | None = None
    lookup_allowed: bool = False
    derived_use_mask: int = 0
    evidence_only: bool = False


def _change_batch(changes):
    """The same metadata contract at the Host journal and receiver boundary."""
    if not isinstance(changes, (list, tuple)) or len(changes) > _MAX_BATCH:
        raise MemoryValidationError("invalid_change_batch")
    changes = tuple(changes)
    previous = None
    for change in changes:
        if not isinstance(change, SourceChange):
            raise MemoryValidationError("invalid_source_change")
        _integer(change.position, "position", 1)
        _validate_source(change.source)
        if change.source is None or change.source.start_cp is not None:
            raise MemoryValidationError("whole_source_required")
        _integer(change.source.revision, "source_revision", 1)
        if (change.action not in ("upsert", "withdraw") or not isinstance(change.formation_allowed, bool)
                or not isinstance(change.lookup_allowed, bool)
                or not isinstance(change.evidence_only, bool)
                or (change.evidence_only and change.formation_allowed)):
            raise MemoryValidationError("invalid_source_change")
        _integer(change.derived_use_mask, "derived_use_mask", 0, 3)
        _identity(change.policy_revision)
        if change.recorded_at_ms is not None:
            _integer(change.recorded_at_ms, "recorded_at_ms")
        if previous is not None and change.position != previous + 1:
            raise MemoryConflict("feed_gap_or_order")
        previous = change.position
    return changes


def _change_metadata(change):
    source = change.source
    return (source.namespace, source.record_key, source.revision, change.action,
            int(change.formation_allowed), change.policy_revision, change.recorded_at_ms,
            int(change.lookup_allowed), change.derived_use_mask, int(change.evidence_only))


@dataclass(frozen=True)
class SourceInput:
    source: SourceSpan
    state_version: int
    policy_revision: str
    recorded_at_ms: int | None


def _validate_input(item):
    if not isinstance(item, SourceInput):
        raise MemoryValidationError("invalid_source_input")
    _validate_source(item.source)
    if item.source is None or item.source.start_cp is not None:
        raise MemoryValidationError("whole_source_required")
    _integer(item.source.revision, "source_revision", 1)
    _integer(item.state_version, "state_version", 1)
    _identity(item.policy_revision)
    if item.recorded_at_ms is not None:
        _integer(item.recorded_at_ms, "recorded_at_ms")


def _context_inputs(value):
    if value is None:
        return None
    if not isinstance(value, (list, tuple)) or len(value) > _MAX_BATCH:
        raise MemoryValidationError("invalid_context_inputs")
    unique = {}
    for item in value:
        _validate_input(item)
        key = item.source.namespace, item.source.record_key
        if key in unique and unique[key] != item:
            raise MemoryConflict("context_snapshot_conflict")
        unique[key] = item
    return tuple(unique[key] for key in sorted(unique))


@dataclass(frozen=True)
class StreamProgress:
    stream_id: str
    pipeline_version: str
    received_position: int
    processed_position: int


@dataclass(frozen=True)
class FormationTask:
    task_id: str
    stream_id: str
    pipeline_version: str
    cursor_before: int
    cursor_after: int
    inputs: tuple[SourceInput, ...]
    state: str
    max_attempts: int
    attempts: int
    input_roles: tuple[Literal["incremental", "context"], ...] = ()
    work_class: Literal["warm", "cold"] = "warm"
    target_uses: tuple[Literal["lookup", "ordinary"], ...] = ()
    reason: str = "source_delta"
    reformation_event_id: int | None = None
    reformation_candidate_id: str | None = None

    @property
    def advances_cursor(self) -> bool:
        return self.reason == "source_delta"


@dataclass(frozen=True)
class QuoteFailureGroup:
    """An unverified failed item's declared inputs; never a candidate."""
    item_key: str
    error_code: str
    inputs: tuple[SourceInput, ...]
    declared_role_masks: tuple[int, ...]


@dataclass(frozen=True)
class QuoteFailureContext:
    task_id: str
    status: Literal["recorded", "unrecorded", "unavailable"]
    groups: tuple[QuoteFailureGroup, ...] = ()
    omitted_groups: int = 0


@dataclass(frozen=True)
class Usage:
    input_tokens: int = 0
    output_tokens: int = 0
    cost_units: int = 0


@dataclass(frozen=True)
class BudgetWindow:
    window_id: str
    start_ms: int
    end_ms: int
    max_calls: int
    max_usage: Usage


@dataclass(frozen=True)
class BudgetStatus:
    window: BudgetWindow
    calls: int
    usage: Usage
    over_budget: bool


@dataclass(frozen=True)
class ColdStatus:
    used: int
    remaining: int
    max_runs: int
    pending_reservations: int
    earliest_ms: int | None


@dataclass(frozen=True)
class Attempt:
    attempt_id: str
    task_id: str
    reservation_key: str
    window_id: str
    reserved: Usage
    actual: Usage | None
    outcome: str


@dataclass(frozen=True)
class AttemptReservation:
    attempt: Attempt
    replayed: bool


@dataclass(frozen=True)
class AttemptResult:
    attempt: Attempt
    task: FormationTask
    budget: BudgetStatus
    committed: bool
    replayed: bool


def _usage(value):
    if not isinstance(value, Usage):
        raise MemoryValidationError("invalid_usage")
    for field in ("input_tokens", "output_tokens", "cost_units"):
        _integer(getattr(value, field), field)


def _usage_tuple(value):
    return value.input_tokens, value.output_tokens, value.cost_units


class Maintenance:
    """Manual source ingestion, formation preparation and shared accounting.

    Constructing a facade does not recover or invalidate in-flight attempts.
    Only acquiring a new MemoryStore owner performs crash recovery.
    """

    def __init__(self, store):
        self._store = store

    @property
    def _db(self):
        return self._store._db

    def _stream(self, access, stream_id):
        self._store._access(access)
        _identity(stream_id)
        row = self._db.execute("SELECT * FROM source_streams WHERE stream_id=?", (stream_id,)).fetchone()
        if row is None:
            raise MemoryNotFound("stream_not_found")
        self._store._scope(access, MemoryScope(row["scope_kind"], row["user_id"], row["character_id"], row["project_id"]))
        return row

    def register_stream(self, access: AccessScope, stream_id: str, scope: MemoryScope) -> None:
        _identity(stream_id)
        self._store._scope(access, scope)
        values = (scope.kind, scope.user_id, scope.character_id, scope.project_id)
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                row = self._db.execute("SELECT scope_kind,user_id,character_id,project_id FROM source_streams WHERE stream_id=?", (stream_id,)).fetchone()
                if row is not None:
                    if tuple(row) != values:
                        raise MemoryConflict("stream_scope_conflict")
                    return
                self._db.execute("INSERT INTO source_streams(stream_id,scope_kind,user_id,character_id,project_id) VALUES(?,?,?,?,?)", (stream_id, *values))

    def append_changes(self, access: AccessScope, stream_id: str, changes: Sequence[SourceChange]) -> int:
        """Atomically accept a bounded continuous prefix; exact replay is free."""
        changes = _change_batch(changes)
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                received = self._stream(access, stream_id)["received_position"]
                for change in changes:
                    source = change.source
                    metadata = _change_metadata(change)
                    if change.position <= received:
                        replay = self._db.execute("SELECT namespace,record_key,revision,action,formation_allowed,policy_revision,recorded_at_ms,lookup_allowed,derived_use_mask,evidence_only FROM source_changes WHERE stream_id=? AND position=?", (stream_id, change.position)).fetchone()
                        if replay is None or tuple(replay) != metadata:
                            raise MemoryConflict("feed_position_conflict")
                        continue
                    if change.position != received + 1:
                        raise MemoryConflict("feed_gap_or_order")
                    current = self._db.execute("SELECT * FROM source_states WHERE namespace=? AND record_key=?", (source.namespace, source.record_key)).fetchone()
                    if current is not None:
                        if current["stream_id"] != stream_id:
                            raise MemoryConflict("source_stream_conflict")
                        if source.revision < current["revision"]:
                            raise MemoryConflict("source_revision_rollback")
                        if current["action"] == "withdraw" and change.action == "upsert" and source.revision == current["revision"]:
                            raise MemoryConflict("source_revision_withdrawn")
                    state = (source.revision, change.action, int(change.formation_allowed), change.policy_revision)
                    lookup_grants = (int(change.lookup_allowed), change.derived_use_mask, int(change.evidence_only))
                    snapshot = (*state, change.recorded_at_ms, *lookup_grants)
                    unchanged = current is not None and tuple(current[k] for k in (
                        "revision", "action", "formation_allowed", "policy_revision",
                        "recorded_at_ms", "lookup_allowed", "derived_use_mask", "evidence_only")) == snapshot
                    version = current["state_version"] if unchanged else change.position
                    if not unchanged:
                        from .candidates import _invalidate_source_change
                        _invalidate_source_change(self._store, access, current, change)
                        self._db.execute("INSERT INTO source_states(namespace,record_key,stream_id,revision,action,formation_allowed,policy_revision,recorded_at_ms,state_version,lookup_allowed,derived_use_mask,evidence_only) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(namespace,record_key) DO UPDATE SET revision=excluded.revision,action=excluded.action,formation_allowed=excluded.formation_allowed,policy_revision=excluded.policy_revision,recorded_at_ms=excluded.recorded_at_ms,state_version=excluded.state_version,lookup_allowed=excluded.lookup_allowed,derived_use_mask=excluded.derived_use_mask,evidence_only=excluded.evidence_only", (source.namespace, source.record_key, stream_id, *state, change.recorded_at_ms, version, *lookup_grants))
                    self._db.execute("INSERT INTO source_changes(stream_id,position,namespace,record_key,revision,action,formation_allowed,policy_revision,recorded_at_ms,lookup_allowed,derived_use_mask,evidence_only,state_version) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)", (stream_id, change.position, *metadata, version))
                    received = change.position
                self._db.execute("UPDATE source_streams SET received_position=? WHERE stream_id=?", (received, stream_id))
            if self._store._cleanup_pending():
                self._store.cleanup()
            return received

    def progress(self, access: AccessScope, stream_id: str, pipeline_version: str) -> StreamProgress:
        _identity(pipeline_version)
        with self._store._lock:
            self._store._check()
            stream = self._stream(access, stream_id)
            return StreamProgress(stream_id, pipeline_version, stream["received_position"], self._cursor(stream_id, pipeline_version))

    @staticmethod
    def _lookup_eligibility(*, discoverable=False):
        # Whole-record lookup cannot bypass any excluded/retired fragment.
        # q=source_states and s=its bound source_streams in owning callers.
        eligibility = """q.action='upsert' AND q.lookup_allowed=1
            AND NOT EXISTS (SELECT 1 FROM exclusions e WHERE e.user_id=s.user_id
                AND e.namespace=q.namespace AND e.record_key=q.record_key)
            AND NOT EXISTS (SELECT 1 FROM memory_retirement_sources o JOIN memories m ON m.memory_id=o.memory_id
                WHERE o.namespace=q.namespace AND o.record_key=q.record_key AND o.revision=q.revision
                AND m.user_id=s.user_id AND m.retention='explicit' AND m.state IN ('superseded','retracted'))
            AND NOT EXISTS (SELECT 1 FROM recall_uses u JOIN memories m ON m.memory_id=u.memory_id
                WHERE u.user_id=s.user_id AND u.namespace=q.namespace AND u.record_key=q.record_key
                AND u.revision=q.revision AND (m.state IN ('superseded','retracted') OR m.invalid_reason IS NOT NULL))
            AND NOT EXISTS (SELECT 1 FROM output_bindings b WHERE b.user_id=s.user_id
                AND b.namespace=q.namespace AND b.record_key=q.record_key AND b.revision=q.revision
                AND b.invalid_reason IS NOT NULL)"""

        if discoverable:
            eligibility += " AND q.evidence_only=0"
        return eligibility

    def _lookup_row(self, access, source, stream_id=None, *, check_parents=True, discoverable=False):
        _validate_source(source)
        if source is None or source.start_cp is not None:
            raise MemoryValidationError("whole_source_required")
        _integer(source.revision, "source_revision", 1)
        if access is None:
            _identity(stream_id)
            where, parameters = "s.stream_id=?", (stream_id,)
        else:
            self._store._access(access)
            where, parameters = self._store._where(access, "s")
        row = self._db.execute("SELECT q.* FROM source_states q JOIN source_streams s ON s.stream_id=q.stream_id WHERE "
                               + where + " AND q.namespace=? AND q.record_key=? AND q.revision=? AND "
                               + self._lookup_eligibility(discoverable=discoverable),
                               (*parameters, source.namespace, source.record_key, source.revision)).fetchone()
        if row is None or (stream_id is not None and row["stream_id"] != stream_id):
            raise MemoryNotFound("lookup_source_not_found")
        try:
            stream = self._source_stream(access, row["stream_id"])
            scope = MemoryScope(stream["scope_kind"], stream["user_id"], stream["character_id"], stream["project_id"])
            if check_parents:
                self._source_scope(access, row, scope, purpose="lookup")
        except (MemoryValidationError, MemoryConflict, MemoryNotFound):
            raise MemoryNotFound("lookup_source_not_found") from None
        return row

    def _lookup_input(self, access, item, *, check_parents=True, stream_id=None, discoverable=False):
        """One exact raw snapshot validator, shared by delivery and caches."""
        _validate_input(item)
        row = self._lookup_row(access, item.source, stream_id,
                               check_parents=check_parents, discoverable=discoverable)
        if (row["state_version"], row["policy_revision"], row["recorded_at_ms"]) != (item.state_version, item.policy_revision, item.recorded_at_ms):
            raise MemoryConflict("stale_source_input")
        return row

    def lookup_input(self, access: AccessScope, stream_id: str, source: SourceSpan, *,
                     discoverable: bool = False) -> SourceInput:
        """Pin one exact authorized source, or require independent discovery eligibility."""
        if not isinstance(discoverable, bool):
            raise MemoryValidationError("invalid_source_lookup_options")
        with self._store._lock:
            self._store._check()
            self._stream(access, stream_id)
            row = self._lookup_row(access, source, stream_id, discoverable=discoverable)
            return SourceInput(source, row["state_version"], row["policy_revision"], row["recorded_at_ms"])

    def _source_scope(self, access, row, scope=None, *, current_parents=True, purpose=None, check_parents=True):
        """Check one source and known output parents using authority metadata.

        Parent lookup/ordinary purposes are not formation permission. Their
        current version, availability and scope still constrain any analysis.
        """
        stream = self._source_stream(access, row["stream_id"])
        if scope is not None and not self._store._scope_contains(stream, scope):
            raise MemoryValidationError("source_scope_expansion")
        if check_parents:
            self._store._output_dependencies(access, (SourceSpan(row["namespace"], row["record_key"], row["revision"]),),
                purpose, owner=stream["user_id"], derived_scope=scope, require_current=current_parents)

    def _source_stream(self, access, stream_id):
        if access is not None:
            return self._stream(access, stream_id)
        row = self._db.execute("SELECT * FROM source_streams WHERE stream_id=?", (stream_id,)).fetchone()
        if row is None:
            raise MemoryNotFound("stream_not_found")
        return row

    def _planning_allows(self, access, row, scope, target_mask):
        self._source_scope(access, row, scope)
        if row["derived_use_mask"] & target_mask != target_mask:
            return False
        for purpose, bit in (("lookup", 1), ("ordinary", 2)):
            if target_mask & bit:
                try:
                    self._source_scope(access, row, scope, purpose=purpose)
                except MemoryConflict as error:
                    # The identical current/version/scope check already passed
                    # above, under the same Store lock/transaction ownership.
                    # No callback intervenes: only this added purpose gate can
                    # now report stale_memory_version. Other errors stay errors.
                    if str(error) not in ("stale_memory_version", "raw_read_set_lookup_only", "candidate_read_set_lookup_only"):
                        raise
                    return False
        return True

    def _formation_row(self, access, source, retirements=None):
        _validate_source(source)
        if source is None or source.start_cp is not None:
            raise MemoryValidationError("whole_source_required")
        _integer(source.revision, "source_revision", 1)
        self._store._access(access)
        where, params = self._store._where(access, "s")
        row = self._db.execute("SELECT q.* FROM source_states q JOIN source_streams s ON s.stream_id=q.stream_id WHERE "
                               + where + " AND q.namespace=? AND q.record_key=? AND q.revision=? AND q.action='upsert' AND q.formation_allowed=1",
                               (*params, source.namespace, source.record_key, source.revision)).fetchone()
        if retirements is None:
            retirements = self._store.source_retirements(access)
        if row is None or not self._policy_allows(access, source, retirements):
            raise MemoryNotFound("formation_source_not_found")
        return row

    def formation_input(self, access: AccessScope, source: SourceSpan) -> SourceInput:
        """Pin formation eligibility without source text or raw lookup access."""
        with self._store._lock:
            self._store._check()
            row = self._formation_row(access, source)
            self._source_scope(access, row)
            return SourceInput(source, row["state_version"], row["policy_revision"], row["recorded_at_ms"])

    def used_companions(self, access, incoming, commits, *, target_uses=("lookup",)):
        """Nominate <=2 current co-supports of causally prior committed use.

        ``commits`` is a trusted Host transaction-order reader, not root seeds.
        No retired root identity/body or rejected-source list is returned.
        """
        from .companions import nominate
        return nominate(self, access, incoming, commits, target_uses=target_uses)

    def revalidate_used_companions(self, access, proposal, commits):
        """Recheck frozen pins, full groups and purpose before consumption."""
        from .companions import revalidate
        return revalidate(self, access, proposal, commits)

    def _cursor(self, stream_id, pipeline_version):
        row = self._db.execute("SELECT position FROM formation_cursors WHERE stream_id=? AND pipeline_version=?", (stream_id, pipeline_version)).fetchone()
        return row[0] if row else 0

    def _policy_allows(self, access, source, retirements):
        try:
            self._store._check_origin(access, source)
        except MemoryValidationError as exc:
            if str(exc) != "excluded_source":
                raise
            return False
        # Retirements are revision-specific lifecycle facts. Forget exclusions
        # above have their existing conservative cross-revision semantics.
        return not any(retirement.source.namespace == source.namespace
                       and retirement.source.record_key == source.record_key
                       and retirement.source.revision == source.revision for retirement in retirements)

    def _task_row(self, access, task_id):
        _identity(task_id)
        row = self._db.execute("SELECT * FROM formation_tasks WHERE task_id=?", (task_id,)).fetchone()
        if row is None:
            raise MemoryNotFound("task_not_found")
        self._stream(access, row["stream_id"])
        return row

    def _task(self, row):
        # Interpret the durable identity only here, at the task owner.
        if row["reformation_event_id"] is not None:
            reason = "source_excluded_reformation"
        elif row["reformation_key"] is None:
            reason = "source_delta"
        elif row["reformation_key"].startswith("quote-gap-repair-v1:"):
            reason = "quote_gap_repair"
        else:
            raise MemoryValidationError("unknown_formation_purpose")
        inputs = self._db.execute("SELECT * FROM formation_inputs WHERE task_id=? ORDER BY ordinal", (row["task_id"],)).fetchall()
        count = self._db.execute("SELECT count(*) FROM formation_attempts WHERE task_id=?", (row["task_id"],)).fetchone()[0]
        return FormationTask(row["task_id"], row["stream_id"], row["pipeline_version"], row["cursor_before"], row["cursor_after"],
                             tuple(SourceInput(SourceSpan(r["namespace"], r["record_key"], r["revision"]), r["state_version"], r["policy_revision"], r["recorded_at_ms"]) for r in inputs),
                             row["state"], row["max_attempts"], count, tuple(r["input_role"] for r in inputs), row["work_class"],
                             tuple(p for p, bit in (("lookup", 1), ("ordinary", 2)) if row["target_use_mask"] & bit),
                             reason,
                             row["reformation_event_id"], row["reformation_candidate_id"])

    def configure_reformation(self, access, stream_id, pipeline_version, *, enabled=False):
        """Opt in before explicit exclusions; never backfill old ordinary work."""
        from .reformation import configure
        return configure(self, access, stream_id, pipeline_version, enabled=enabled)

    def list_reformation_events(self, access, stream_id, pipeline_version, *, limit=100):
        from .reformation import list_events
        return list_events(self, access, stream_id, pipeline_version, limit=limit)

    def reformation_pending(self, access, stream_id, pipeline_version):
        from .reformation import pending
        return pending(self, access, stream_id, pipeline_version)

    def _reformation_due(self, access, stream_id, pipeline_version):
        from .reformation import due
        return due(self, access, stream_id, pipeline_version)

    def _finalize_reformation(self, access, stream_id, pipeline_version):
        from .reformation import finalize
        return finalize(self, access, stream_id, pipeline_version)

    def _active_row(self, stream_id, work_class, allow_reformation):
        # An unreserved repair is durable ready work, not ownership of the
        # sole execution slot. Already reserved/unknown work keeps that slot.
        return self._db.execute("SELECT * FROM formation_tasks WHERE stream_id=? AND work_class=? AND state NOT IN ('done','stale','abandoned') AND (? OR reformation_event_id IS NULL OR state<>'pending') ORDER BY CASE WHEN reformation_event_id IS NOT NULL AND state='pending' THEN 1 ELSE 0 END,rowid LIMIT 1", (stream_id,work_class,int(allow_reformation))).fetchone()

    def active_task(self, access, stream_id, pipeline_version, *, work_class="warm", allow_reformation=True):
        _identity(pipeline_version)
        if work_class not in ("warm","cold") or type(allow_reformation) is not bool:
            raise MemoryValidationError("invalid_task_selection")
        with self._store._lock:
            self._store._check()
            self._stream(access,stream_id)
            from .reformation import enabled
            row=self._active_row(stream_id,work_class,allow_reformation and enabled(self,stream_id,pipeline_version))
            return self._task(row) if row is not None and row["pipeline_version"]==pipeline_version else None

    def list_reformation_blocks(self, access, stream_id, pipeline_version, *, limit=100):
        from .reformation import list_blocks
        return list_blocks(self, access, stream_id, pipeline_version, limit=limit)

    def list_resolved_reformation_tasks(self, access, stream_id, pipeline_version, *, after_task_id=None, limit=100):
        """Page non-interval tasks independently from the ordinary source cursor."""
        _identity(pipeline_version)
        _integer(limit, "task_limit", 1, 1000)
        with self._store._lock:
            self._store._check()
            self._stream(access, stream_id)
            where, args = "", ()
            if after_task_id is not None:
                row = self._task_row(access, after_task_id)
                if (row["stream_id"], row["pipeline_version"]) != (stream_id, pipeline_version) or row["reformation_event_id"] is None:
                    raise MemoryConflict("reformation_cursor_conflict")
                where, args = " AND (reformation_event_id,reformation_candidate_id)>(?,?)", (row["reformation_event_id"], row["reformation_candidate_id"])
            return tuple(self._task(row) for row in self._db.execute("SELECT * FROM formation_tasks WHERE stream_id=? AND pipeline_version=? AND reformation_event_id IS NOT NULL AND state IN ('done','abandoned')" + where + " ORDER BY reformation_event_id,reformation_candidate_id LIMIT ?", (stream_id, pipeline_version, *args, limit)))

    def task(self, access: AccessScope, task_id: str) -> FormationTask:
        with self._store._lock:
            self._store._check()
            return self._task(self._task_row(access, task_id))

    def list_tasks(self, access: AccessScope, stream_id: str, pipeline_version: str, *, limit: int = 100) -> tuple[FormationTask, ...]:
        """Discover recent durable work without opening sources or models."""
        _identity(pipeline_version)
        _integer(limit, "task_limit", 1, 1000)
        with self._store._lock:
            self._store._check()
            self._stream(access, stream_id)
            return tuple(self._task(row) for row in self._db.execute("SELECT * FROM formation_tasks WHERE stream_id=? AND pipeline_version=? ORDER BY rowid DESC LIMIT ?", (stream_id, pipeline_version, limit)))

    def list_resolved_tasks(self, access: AccessScope, stream_id: str, pipeline_version: str, *,
                            after_position: int = 0, limit: int = 100) -> tuple[FormationTask, ...]:
        """Page terminal intervals in immutable strictly increasing cursor order.

        Done and abandoned intervals are both resolved, not equally successful.
        The last cursor_after is the next after_position; no bodies are opened.
        """
        _identity(pipeline_version)
        _integer(after_position, "after_position")
        _integer(limit, "task_limit", 1, 1000)
        with self._store._lock:
            self._store._check()
            self._stream(access, stream_id)
            rows = self._db.execute("SELECT * FROM formation_tasks WHERE stream_id=? AND pipeline_version=? AND reformation_event_id IS NULL AND reformation_key IS NULL AND state IN ('done','abandoned') AND cursor_after>? ORDER BY cursor_after LIMIT ?",
                                    (stream_id, pipeline_version, after_position, limit))
            return tuple(self._task(row) for row in rows)

    def list_abandoned_tasks(self, access: AccessScope, stream_id: str, pipeline_version: str, *,
                             after_task_id: str | None = None, limit: int = 100) -> tuple[FormationTask, ...]:
        """Page formation coverage gaps; the last task ID is the next cursor.

        Ordering uses immutable interval/identity, independent of SQLite rowids
        and cleanup. A cursor must belong to this exact abandoned ledger.
        """
        _identity(pipeline_version)
        _integer(limit, "task_limit", 1, 1000)
        with self._store._lock:
            self._store._check()
            self._stream(access, stream_id)
            where, params = "", ()
            if after_task_id is not None:
                row = self._task_row(access, after_task_id)
                if (row["stream_id"], row["pipeline_version"], row["state"]) != (stream_id, pipeline_version, "abandoned"):
                    raise MemoryConflict("abandoned_cursor_conflict")
                where = " AND (cursor_before,cursor_after,task_id)>(?,?,?)"
                params = (row["cursor_before"], row["cursor_after"], after_task_id)
            rows = self._db.execute("SELECT * FROM formation_tasks WHERE stream_id=? AND pipeline_version=? AND state='abandoned'"
                                    + where + " ORDER BY cursor_before,cursor_after,task_id LIMIT ?",
                                    (stream_id, pipeline_version, *params, limit))
            return tuple(self._task(row) for row in rows)

    def abandon_task(self, access: AccessScope, task_id: str, *, expected_attempt_id: str) -> FormationTask:
        """Explicitly resolve an unsuccessful task, preserving its coverage gap.

        This neither refunds accounting nor changes the attempt's known/unknown
        outcome. It cannot cancel in-flight work or retry an external call.
        """
        _identity(expected_attempt_id)
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                row = self._task_row(access, task_id)
                task = self._task(row)
                if row["current_attempt_id"] != expected_attempt_id:
                    raise MemoryConflict("task_attempt_conflict")
                if task.state == "abandoned":
                    return task
                if task.state not in ("failed", "truncated", "unknown"):
                    raise MemoryConflict("task_not_abandonable")
                attempt = self._attempt_row(access, expected_attempt_id)
                if attempt["outcome"] != task.state:
                    raise MemoryConflict("task_attempt_conflict")
                self._advance(task, terminal_state="abandoned")
                return self._task(self._task_row(access, task_id))

    def release_unattempted(self, access: AccessScope, task_id: str) -> None:
        """Explicitly replan only work that has never consumed an attempt."""
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                task = self._task(self._task_row(access, task_id))
                if task.attempts or task.state != "pending":
                    raise MemoryConflict("task_not_unattempted")
                if task.reformation_event_id is not None:
                    # A source-exclusion task already pins a complete immutable
                    # group. Releasing it is an idempotent free replan of that
                    # same work, rather than losing its consumed event page.
                    return
                self._db.execute("UPDATE formation_tasks SET state='stale' WHERE task_id=?", (task_id,))

    def current_attempt(self, access: AccessScope, task_id: str) -> Attempt | None:
        with self._store._lock:
            self._store._check()
            row = self._task_row(access, task_id)
            return self._attempt(self._attempt_row(access, row["current_attempt_id"])) if row["current_attempt_id"] else None

    def find_attempt(self, access: AccessScope, task_id: str, reservation_key: str) -> Attempt | None:
        _identity(reservation_key)
        with self._store._lock:
            self._store._check()
            self._task_row(access, task_id)
            row = self._db.execute("SELECT * FROM formation_attempts WHERE task_id=? AND reservation_key=?", (task_id, reservation_key)).fetchone()
            return self._attempt(row) if row else None

    def quote_failure_context(self, access: AccessScope, task_id: str, *,
                              max_sources: int = 100) -> QuoteFailureContext:
        """Recheck one explicitly chosen abandoned warm task's declarations.

        The caller may choose the task through list_abandoned_tasks pagination.
        No scheduling, text read, new version substitution, or candidate occurs.
        Inputs are only optional background-formation material. A bare returned
        pin does not carry this task's full-read-set recommendation authority;
        the consuming Host must recheck this task at its use boundary.
        """
        _identity(task_id)
        _integer(max_sources, "max_sources", 1, _MAX_BATCH)
        with self._store._lock:
            self._store._check()
            task = self._task(self._task_row(access, task_id))
            if (task.state != "abandoned" or task.work_class != "warm"
                    or task.reason != "source_delta" or not self._inputs_current(access, task)):
                return QuoteFailureContext(task_id, "unavailable")
            submission = self._db.execute("SELECT s.attempt_id,s.fingerprint FROM candidate_submissions s JOIN formation_attempts a ON a.attempt_id=s.attempt_id WHERE a.task_id=?", (task_id,)).fetchone()
            if submission is None or submission["fingerprint"] is None:
                return QuoteFailureContext(task_id, "unavailable")
            rows = self._db.execute("SELECT item_key,error_code,input_ordinal,declared_role_mask FROM formation_quote_failures WHERE attempt_id=? ORDER BY item_key,input_ordinal", (submission["attempt_id"],)).fetchall()
            if not rows:
                return QuoteFailureContext(task_id, "unrecorded")
            grouped = {}
            for row in rows:
                grouped.setdefault((row["item_key"], row["error_code"]), []).append(row)
            groups, unique, omitted = [], set(), 0
            for (item_key, error_code), edges in grouped.items():
                pins = tuple(task.inputs[row["input_ordinal"]] for row in edges)
                identities = {pin.source for pin in pins}
                if len(unique | identities) > max_sources:
                    omitted += 1
                    continue
                unique.update(identities)
                groups.append(QuoteFailureGroup(item_key, error_code, pins,
                              tuple(row["declared_role_mask"] for row in edges)))
            return QuoteFailureContext(task_id, "recorded", tuple(groups), omitted)

    def prepare_quote_gap_repair(self, access: AccessScope, source_task_id: str, item_key: str, *,
                                 max_sources: int = 100) -> FormationTask:
        """Explicit Host choice of one recorded group; no provider work.

        This is keyed work in the existing warm lane, not a source exclusion
        or new user turn. One task/attempt per original failed item identity.
        A cancelled unattempted task can be selected again only explicitly.
        """
        from json import dumps
        _identity(source_task_id)
        _identity(item_key)
        _integer(max_sources, "max_sources", 1, _MAX_BATCH)
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                parent = self._task(self._task_row(access, source_task_id))
                current = self.quote_failure_context(access, source_task_id, max_sources=_MAX_BATCH)
                if current.status == "unrecorded":
                    raise MemoryConflict("quote_gap_sources_unrecorded")
                if current.status != "recorded":
                    raise MemoryConflict("quote_gap_source_unavailable")
                group = next((group for group in current.groups if group.item_key == item_key), None)
                if group is None:
                    raise MemoryNotFound("quote_gap_group_not_found")
                if len(group.inputs) > max_sources:
                    raise MemoryValidationError("source_limit_exceeded")
                stream = self._stream(access, parent.stream_id)
                scope = MemoryScope(stream["scope_kind"], stream["user_id"], stream["character_id"], stream["project_id"])
                mask = _target_use_mask(parent.target_uses)
                if not mask:
                    raise MemoryConflict("quote_gap_purpose_unrecorded")
                retirements = self._store.source_retirements(access)
                for pin in group.inputs:
                    self._reformation_input(access, pin, scope, mask, retirements)
                key = "quote-gap-repair-v1:" + dumps([source_task_id, item_key], ensure_ascii=True, separators=(",", ":"))
                existing = self._db.execute("SELECT * FROM formation_tasks WHERE reformation_key=?", (key,)).fetchone()
                if existing is not None:
                    task = self._task(existing)
                    if task.inputs != group.inputs:
                        raise MemoryConflict("quote_gap_group_changed")
                    if task.state != "stale" or task.attempts:
                        return task
                active = self._active_row(parent.stream_id, "warm", True)
                if active is not None and (existing is None or active["task_id"] != existing["task_id"]):
                    raise MemoryConflict("stream_task_active")
                if existing is not None:
                    self._db.execute("UPDATE formation_tasks SET state='pending' WHERE task_id=?", (existing["task_id"],))
                    return self._task(self._task_row(access, existing["task_id"]))
                task_id, position = uuid4().hex, self._cursor(parent.stream_id, parent.pipeline_version)
                self._db.execute("INSERT INTO formation_tasks(task_id,stream_id,pipeline_version,cursor_before,cursor_after,state,max_attempts,work_class,target_use_mask,reformation_key) VALUES(?,?,?,?,?,'pending',1,'warm',?,?)",
                                 (task_id, parent.stream_id, parent.pipeline_version, position, position, mask, key))
                for ordinal, pin in enumerate(group.inputs):
                    self._db.execute("INSERT INTO formation_inputs(task_id,ordinal,namespace,record_key,revision,state_version,policy_revision,recorded_at_ms,input_role) VALUES(?,?,?,?,?,?,?,?,'context')",
                                     (task_id, ordinal, pin.source.namespace, pin.source.record_key, pin.source.revision,
                                      pin.state_version, pin.policy_revision, pin.recorded_at_ms))
                self._freeze_gap_parent(task_id, source_task_id, (item_key,))
                return self._task(self._task_row(access, task_id))

    def list_resolved_maintenance_tasks(self, access, stream_id, pipeline_version, *, after_task_id=None, limit=100):
        """Bounded indexed terminal order; old opaque task ACKs stay valid.

        The terminal transaction assigns the derived per-lane order, so idle
        work touches neither ordinary history nor already consumed repairs.
        Legacy reformation paging remains unchanged.
        """
        _identity(pipeline_version)
        _integer(limit, "task_limit", 1, _MAX_BATCH)
        with self._store._lock:
            self._store._check()
            self._stream(access, stream_id)
            after = 0
            if after_task_id is not None:
                row = self._task_row(access, after_task_id)
                if ((row["stream_id"], row["pipeline_version"]) != (stream_id, pipeline_version)
                        or self._task(row).advances_cursor or row["state"] not in ("done", "abandoned")):
                    raise MemoryConflict("reformation_cursor_conflict")
                if row["maintenance_completion_order"] is None:
                    raise MemoryConflict("reformation_cursor_conflict")
                after = row["maintenance_completion_order"]
            return tuple(self._task(row) for row in self._db.execute("SELECT * FROM formation_tasks INDEXED BY formation_maintenance_resolved WHERE stream_id=? AND pipeline_version=? AND maintenance_completion_order IS NOT NULL AND state IN ('done','abandoned') AND maintenance_completion_order>? ORDER BY maintenance_completion_order LIMIT ?", (stream_id, pipeline_version, after, limit)))

    def task_current(self, access: AccessScope, task_id: str) -> bool:
        with self._store._lock:
            self._store._check()
            return self._current(access, self._task(self._task_row(access, task_id)))

    def _current(self, access, task):
        if task.reason == "quote_gap_repair":
            if task.state == "stale":
                return False
        elif task.reformation_event_id is not None:
            from .reformation import enabled
            if not enabled(self, task.stream_id, task.pipeline_version):
                return False
        elif self._cursor(task.stream_id, task.pipeline_version) != task.cursor_before:
            return False
        return self._inputs_current(access, task)

    def _inputs_current(self, access, task):
        """Current actual inputs plus consumed recommendation authority."""
        if not self._own_inputs_current(access, task):
            return False
        parents = self._db.execute("SELECT DISTINCT parent_task_id FROM formation_gap_handoffs WHERE task_id=?", (task.task_id,)).fetchall()
        return all(self._own_inputs_current(access, self._task(self._task_row(access, row[0]))) for row in parents)

    def _authority_inputs(self, task_id):
        return tuple(SourceInput(SourceSpan(row["namespace"], row["record_key"], row["revision"]), row["state_version"], row["policy_revision"], row["recorded_at_ms"])
                     for row in self._db.execute("SELECT * FROM formation_authority_inputs WHERE task_id=? ORDER BY namespace,record_key,revision,state_version", (task_id,)))

    def _own_inputs_current(self, access, task):
        """Check the entire fixed read set, independently of its resolved cursor."""
        stream = self._stream(access, task.stream_id)
        scope = MemoryScope(stream["scope_kind"], stream["user_id"], stream["character_id"], stream["project_id"])
        retirements = self._store.source_retirements(access)
        target_mask = _target_use_mask(task.target_uses)
        for item, role in zip(task.inputs, task.input_roles):
            try:
                if not task.advances_cursor:
                    row = self._reformation_input(access, item, scope, target_mask, retirements)
                else:
                    row = self._formation_row(access, item.source, retirements)
                    if not self._planning_allows(access, row, scope, target_mask):
                        return False
            except (MemoryValidationError, MemoryNotFound, MemoryConflict):
                return False
            if ((role == "incremental" and row["stream_id"] != task.stream_id)
                    or (row["state_version"], row["policy_revision"], row["recorded_at_ms"])
                    != (item.state_version, item.policy_revision, item.recorded_at_ms)):
                return False
        return True

    def _reformation_input(self, access, item, scope, target_mask, retirements):
        """The same original-root qualification at planning/read/send/commit."""
        row = self._formation_row(access, item.source, retirements)
        if ((row["state_version"], row["policy_revision"], row["recorded_at_ms"])
                != (item.state_version, item.policy_revision, item.recorded_at_ms)
                or not self._planning_allows(access, row, scope, target_mask)
                or self._store._known_output(access.user_id, item.source)):
            raise MemoryConflict("stale_reformation_root")
        return row

    def _gap_context(self, access, parent_task_id, item_keys, stream_id, pipeline_version, max_sources):
        if not isinstance(item_keys, (list, tuple)) or not item_keys or len(item_keys) > 64:
            raise MemoryValidationError("invalid_gap_item_keys")
        for key in item_keys:
            _identity(key)
        if len(set(item_keys)) != len(item_keys):
            raise MemoryValidationError("invalid_gap_item_keys")
        parent = self._task(self._task_row(access, parent_task_id))
        if (parent.stream_id, parent.pipeline_version) != (stream_id, pipeline_version):
            raise MemoryConflict("gap_recommendation_scope_mismatch")
        current = self.quote_failure_context(access, parent_task_id, max_sources=max_sources)
        selected = tuple(group for group in current.groups if group.item_key in item_keys)
        if current.status != "recorded" or {group.item_key for group in selected} != set(item_keys):
            raise MemoryConflict("source_limit_exceeded" if current.omitted_groups else "gap_recommendation_unavailable")
        return _context_inputs(tuple(pin for group in selected for pin in group.inputs))

    def _freeze_gap_parent(self, task_id, parent_task_id, item_keys):
        child = self._db.execute("SELECT rowid,state FROM formation_tasks WHERE task_id=?", (task_id,)).fetchone()
        parent = self._db.execute("SELECT rowid,state FROM formation_tasks WHERE task_id=?", (parent_task_id,)).fetchone()
        if parent is None or child is None or parent[0] >= child[0] or parent["state"] != "abandoned":
            raise MemoryConflict("gap_parent_order_conflict")
        inherited = {(row[0], row[1]): 0 for row in self._db.execute("SELECT parent_task_id,item_key FROM formation_gap_handoffs WHERE task_id=?", (parent_task_id,))}
        inherited.update({(parent_task_id, key): 1 for key in item_keys})
        if len(inherited) > _MAX_BATCH:
            raise MemoryConflict("gap_ancestry_limit")
        self._db.executemany("INSERT INTO formation_gap_handoffs(task_id,parent_task_id,item_key,direct) VALUES(?,?,?,?)",
                             ((task_id, old, key, direct) for (old, key), direct in sorted(inherited.items())))

    @staticmethod
    def _match_context(task, requested):
        incremental = {item.source: item for item, role in zip(task.inputs, task.input_roles) if role == "incremental"}
        effective = []
        for item in requested:
            if item.source in incremental:
                if incremental[item.source] != item:
                    raise MemoryConflict("context_snapshot_conflict")
            else:
                effective.append(item)
        frozen = tuple(item for item, role in zip(task.inputs, task.input_roles) if role == "context")
        if tuple(effective) != frozen:
            raise MemoryConflict("context_inputs_conflict")

    def _validated_context(self, access, inputs, context_inputs, scope, target_mask, retirements, *, inherited=False):
        accepted = []
        by_identity = {(i.source.namespace, i.source.record_key): i for i in inputs}
        for item in context_inputs:
            key = item.source.namespace, item.source.record_key
            if key in by_identity:
                if by_identity[key] != item:
                    raise MemoryConflict("context_snapshot_stale" if inherited else "context_snapshot_conflict")
                continue
            try:
                current = self._formation_row(access, item.source, retirements)
                if (current["state_version"], current["policy_revision"], current["recorded_at_ms"]) != (item.state_version, item.policy_revision, item.recorded_at_ms):
                    raise MemoryConflict("stale_source_input")
                target_allowed = self._planning_allows(access, current, scope, target_mask)
            except (MemoryValidationError, MemoryNotFound, MemoryConflict):
                if inherited:
                    raise MemoryConflict("context_snapshot_stale") from None
                raise
            if not target_allowed:
                raise MemoryConflict("context_target_uses_not_allowed")
            accepted.append(item)
        return accepted

    def attach_context(self, access, task_id, inputs, *, max_sources):
        """Freeze a complete proposal on the exact, still unattempted incremental task."""
        proposed = _context_inputs(inputs)
        _integer(max_sources, "max_sources", 1, _MAX_BATCH)
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                task = self._task(self._task_row(access, task_id))
                if task.state != "pending" or task.attempts or task.reason != "source_delta":
                    raise MemoryConflict("task_not_unattempted")
                if not self._current(access, task):
                    raise MemoryConflict("context_snapshot_stale")
                if "context" in task.input_roles:
                    if len(task.inputs) > max_sources:
                        raise MemoryValidationError("source_limit_exceeded")
                    self._match_context(task, proposed or ())
                    return task
                stream = self._stream(access, task.stream_id)
                scope = MemoryScope(stream["scope_kind"], stream["user_id"], stream["character_id"], stream["project_id"])
                selected = self._validated_context(
                    access, task.inputs, proposed or (), scope, _target_use_mask(task.target_uses) or 0,
                    self._store.source_retirements(access)
                )
                if len(task.inputs) + len(selected) > max_sources:
                    raise MemoryValidationError("source_limit_exceeded")
                self._db.executemany(
                    "INSERT INTO formation_inputs(task_id,ordinal,namespace,record_key,revision,state_version,"
                    "policy_revision,recorded_at_ms,input_role) VALUES(?,?,?,?,?,?,?,?,?)",
                    ((task_id, i, p.source.namespace, p.source.record_key, p.source.revision,
                      p.state_version, p.policy_revision, p.recorded_at_ms, "context")
                     for i,p in enumerate(selected, len(task.inputs)))
                )
                return self._task(self._task_row(access, task_id))

    def formation_context_pool(self, access, task, cutoff, *, allowed_stream_ids=None):
        """Nominate recorded-eligible sources within any Host-approved stream set."""
        if allowed_stream_ids is not None:
            if not isinstance(allowed_stream_ids, (tuple, list)):
                raise MemoryValidationError("invalid_formation_context_streams")
            for stream_id in allowed_stream_ids:
                _identity(stream_id)
        with self._store._lock:
            self._store._check()
            stream = self._stream(access, task.stream_id)
            scope = MemoryScope(stream["scope_kind"], stream["user_id"], stream["character_id"], stream["project_id"])
            mask = _target_use_mask(task.target_uses) or 0
            where, params = self._store._where(access, "s")
            if allowed_stream_ids is not None:
                where += " AND q.stream_id IN (SELECT value FROM json_each(?))"
                params = (*params, json.dumps(allowed_stream_ids))
            pool = self._db.execute(
                "SELECT q.* FROM source_states q JOIN source_streams s ON q.stream_id=s.stream_id WHERE "
                + where + " AND q.action='upsert' AND q.formation_allowed=1 AND q.recorded_at_ms<? "
                "AND (q.stream_id<>? OR q.state_version<=?) "
                "ORDER BY q.recorded_at_ms DESC,q.namespace,q.record_key LIMIT 2048",
                (*params, cutoff, task.stream_id, task.cursor_before),
            ).fetchall()
            current = {p.source for p in task.inputs}
            retired = self._store.source_retirements(access)
            selected = []
            for row in pool:
                source = SourceSpan(row["namespace"], row["record_key"], row["revision"])
                if source in current or not self._policy_allows(access, source, retired):
                    continue
                try:
                    if not self._planning_allows(access, row, scope, mask):
                        continue
                except (MemoryNotFound, MemoryConflict, MemoryValidationError):
                    continue
                selected.append(SourceInput(source, row["state_version"], row["policy_revision"], row["recorded_at_ms"]))
            return tuple(selected)

    def prepare(self, access: AccessScope, stream_id: str, pipeline_version: str, *,
                max_events: int = 100, max_sources: int = 100, max_attempts: int = 1,
                context_inputs: Sequence[SourceInput] | None = None,
                work_class: Literal["warm", "cold"] = "warm",
                target_uses: Sequence[str] | None = None,
                allow_reformation: bool = True,
                quote_failure_task_id: str | None = None,
                quote_failure_item_keys: Sequence[str] | None = None) -> FormationTask | None:
        _identity(pipeline_version)
        if not isinstance(work_class, str) or work_class not in ("warm", "cold"):
            raise MemoryValidationError("invalid_work_class")
        requested_mask = _target_use_mask(target_uses)
        if type(allow_reformation) is not bool:
            raise MemoryValidationError("invalid_reformation_selection")
        _integer(max_events, "max_events", 1, _MAX_BATCH)
        _integer(max_sources, "max_sources", 1, _MAX_BATCH)
        _integer(max_attempts, "max_attempts", 1, _MAX_BATCH)
        context_inputs = _context_inputs(context_inputs)
        if quote_failure_task_id is not None:
            _identity(quote_failure_task_id)
            if work_class != "warm":
                raise MemoryValidationError("gap_context_warm_only")
        elif quote_failure_item_keys is not None:
            raise MemoryValidationError("gap_parent_required")
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                stream = self._stream(access, stream_id)
                scope = MemoryScope(stream["scope_kind"], stream["user_id"], stream["character_id"], stream["project_id"])
                bound = self._db.execute("SELECT work_class,target_use_mask FROM formation_tasks WHERE stream_id=? AND pipeline_version=? LIMIT 1", (stream_id, pipeline_version)).fetchone()
                if bound is not None and bound[0] != work_class:
                    raise MemoryConflict("task_work_class_conflict")
                if bound is not None and requested_mask is not None and bound["target_use_mask"] != requested_mask:
                    raise MemoryConflict("task_target_uses_conflict")
                target_mask = bound["target_use_mask"] if bound is not None else (requested_mask or 0)
                if quote_failure_task_id is not None:
                    gap_inputs = self._gap_context(access, quote_failure_task_id, quote_failure_item_keys,
                                                   stream_id, pipeline_version, max_sources)
                    context_inputs = _context_inputs(tuple(context_inputs or ()) + gap_inputs)
                from .reformation import enabled
                reformation_allowed = allow_reformation and enabled(self,stream_id,pipeline_version)
                old = self._active_row(stream_id,work_class,reformation_allowed)
                if old is not None:
                    task = self._task(old)
                    if self._current(access, task):
                        if task.pipeline_version != pipeline_version:
                            raise MemoryConflict("stream_task_active")
                        if context_inputs is not None and task.advances_cursor:
                            self._match_context(task, context_inputs)
                        direct = {(row[0], row[1]) for row in self._db.execute("SELECT parent_task_id,item_key FROM formation_gap_handoffs WHERE task_id=? AND direct=1", (task.task_id,))}
                        if quote_failure_task_id is not None and direct != {(quote_failure_task_id, key) for key in quote_failure_item_keys}:
                            raise MemoryConflict("gap_context_parent_conflict")
                        if len(task.inputs) > max_sources:
                            raise MemoryValidationError("source_limit_exceeded")
                        return task
                    self._db.execute("UPDATE formation_tasks SET state='stale' WHERE task_id=?", (task.task_id,))
                    if self._active_row(stream_id,work_class,reformation_allowed) is not None:
                        return None
                before = self._cursor(stream_id, pipeline_version)
                inherited = False
                gap_requests = [(quote_failure_task_id, tuple(quote_failure_item_keys))] if quote_failure_task_id is not None else []
                if context_inputs is None:
                    # A source/known-output change may already have marked the
                    # previous task stale. Omission still means its frozen set,
                    # never an implicit plan that silently drops those inputs.
                    previous = self._db.execute("SELECT * FROM formation_tasks WHERE stream_id=? AND pipeline_version=? AND cursor_before=? AND reformation_event_id IS NULL AND reformation_key IS NULL AND state NOT IN ('done','abandoned') ORDER BY rowid DESC LIMIT 1", (stream_id, pipeline_version, before)).fetchone()
                    if previous is not None:
                        frozen = self._task(previous)
                        context_inputs = tuple(item for item, role in zip(frozen.inputs, frozen.input_roles) if role == "context")
                        inherited = bool(context_inputs)
                        # Omission inherits the previous choice, including why
                        # that old material was selected. It is not a new
                        # independent acquisition of the same bare source pin.
                        direct = {}
                        for row in self._db.execute("SELECT parent_task_id,item_key FROM formation_gap_handoffs WHERE task_id=? AND direct=1 ORDER BY parent_task_id,item_key", (frozen.task_id,)):
                            direct.setdefault(row[0], []).append(row[1])
                        for parent_id, keys in direct.items():
                            try:
                                self._gap_context(access, parent_id, tuple(keys), stream_id, pipeline_version, max_sources)
                            except (MemoryValidationError, MemoryNotFound, MemoryConflict):
                                raise MemoryConflict("context_snapshot_stale") from None
                            gap_requests.append((parent_id, tuple(keys)))
                        inherited = inherited or bool(gap_requests)
                # Select one reason for this call. Even a page with no viable
                # roots consumes only metadata work, never an ordinary delta
                # whose caller intentionally omitted ordinary context.
                if reformation_allowed and work_class == "warm" and self._reformation_due(access, stream_id, pipeline_version):
                    if quote_failure_task_id is not None:
                        raise MemoryConflict("gap_context_source_delta_only")
                    from .reformation import prepare
                    self._db.execute("UPDATE reformation_config SET prefer_reformation=0 WHERE stream_id=? AND pipeline_version=?", (stream_id,pipeline_version))
                    return prepare(self, access, stream, pipeline_version, target_mask,
                        max_events=max_events, max_sources=max_sources, max_attempts=max_attempts)
                events = self._db.execute("SELECT * FROM source_changes WHERE stream_id=? AND position>? ORDER BY position LIMIT ?", (stream_id, before, max_events)).fetchall()
                selected = {}
                after = before
                for row in events:
                    key = row["namespace"], row["record_key"]
                    if key not in selected and len(selected) >= max_sources:
                        break
                    selected[key] = row
                    after = row["position"]
                if after == before:
                    return None
                retirements = self._store.source_retirements(access)
                inputs = []
                for key, row in selected.items():
                    current = self._db.execute("SELECT * FROM source_states WHERE namespace=? AND record_key=?", key).fetchone()
                    seen = self._db.execute("SELECT state_version FROM formation_processed_sources WHERE stream_id=? AND pipeline_version=? AND namespace=? AND record_key=?", (stream_id, pipeline_version, *key)).fetchone()
                    source = SourceSpan(*key, row["revision"])
                    if (current["state_version"] == row["state_version"] and row["action"] == "upsert" and row["formation_allowed"]
                            and (seen is None or seen[0] < row["state_version"])
                            and self._policy_allows(access, source, retirements)):
                        if not self._planning_allows(access, current, scope, target_mask):
                            continue
                        inputs.append(SourceInput(source, row["state_version"], row["policy_revision"], row["recorded_at_ms"]))
                roles = ["incremental"] * len(inputs)
                if inputs:
                    context = self._validated_context(access, inputs, context_inputs or (), scope,
                                                      target_mask, retirements, inherited=inherited)
                    inputs.extend(context)
                    roles.extend(["context"] * len(context))
                    if len(inputs) > max_sources:
                        raise MemoryValidationError("source_limit_exceeded")
                task_id = uuid4().hex
                self._db.execute("INSERT INTO formation_tasks(task_id,stream_id,pipeline_version,cursor_before,cursor_after,state,max_attempts,work_class,target_use_mask) VALUES(?,?,?,?,?,?,?,?,?)", (task_id, stream_id, pipeline_version, before, after, "pending" if inputs else "done", max_attempts, work_class, target_mask))
                if work_class == "warm":
                    self._db.execute("UPDATE reformation_config SET prefer_reformation=1 WHERE stream_id=? AND pipeline_version=?", (stream_id,pipeline_version))
                for ordinal, (item, role) in enumerate(zip(inputs, roles)):
                    self._db.execute("INSERT INTO formation_inputs(task_id,ordinal,namespace,record_key,revision,state_version,policy_revision,recorded_at_ms,input_role) VALUES(?,?,?,?,?,?,?,?,?)", (task_id, ordinal, item.source.namespace, item.source.record_key, item.source.revision, item.state_version, item.policy_revision, item.recorded_at_ms, role))
                if inputs:
                    for parent_id, keys in gap_requests:
                        self._freeze_gap_parent(task_id, parent_id, keys)
                row = self._task_row(access, task_id)
                if not inputs:
                    self._advance(self._task(row))
                return self._task(row)

    def _advance(self, task, *, terminal_state="done"):
        # Resolve cursor and same-state watermarks in the owning transaction.
        # Abandoned work has been handled, but is not successful formation.
        if not task.advances_cursor:
            # Same transaction/owner as completion; this is an ordered index
            # projection of terminal facts, never a second fee or work queue.
            last = self._db.execute("SELECT MAX(maintenance_completion_order) FROM formation_tasks INDEXED BY formation_maintenance_resolved WHERE stream_id=? AND pipeline_version=? AND maintenance_completion_order IS NOT NULL AND state IN ('done','abandoned')", (task.stream_id, task.pipeline_version)).fetchone()[0]
            self._db.execute("UPDATE formation_tasks SET state=?,maintenance_completion_order=? WHERE task_id=?", (terminal_state, (last or 0) + 1, task.task_id))
            return
        if self._cursor(task.stream_id, task.pipeline_version) != task.cursor_before:
            raise MemoryConflict("stale_cursor")
        self._db.execute("INSERT INTO formation_cursors(stream_id,pipeline_version,position) VALUES(?,?,?) ON CONFLICT(stream_id,pipeline_version) DO UPDATE SET position=excluded.position", (task.stream_id, task.pipeline_version, task.cursor_after))
        for item, role in zip(task.inputs, task.input_roles):
            if role != "incremental":
                continue
            self._db.execute("INSERT INTO formation_processed_sources(stream_id,pipeline_version,namespace,record_key,state_version) VALUES(?,?,?,?,?) ON CONFLICT(stream_id,pipeline_version,namespace,record_key) DO UPDATE SET state_version=excluded.state_version", (task.stream_id, task.pipeline_version, item.source.namespace, item.source.record_key, item.state_version))
        self._db.execute("UPDATE formation_tasks SET state=? WHERE task_id=?", (terminal_state, task.task_id))

    def configure_budget(self, window: BudgetWindow) -> BudgetStatus:
        if not isinstance(window, BudgetWindow):
            raise MemoryValidationError("invalid_budget_window")
        _identity(window.window_id)
        _integer(window.start_ms, "window_start")
        _integer(window.end_ms, "window_end", window.start_ms + 1)
        _integer(window.max_calls, "max_calls")
        _usage(window.max_usage)
        values = (window.start_ms, window.end_ms, window.max_calls, *_usage_tuple(window.max_usage))
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                row = self._db.execute("SELECT start_ms,end_ms,max_calls,max_input_tokens,max_output_tokens,max_cost_units FROM maintenance_budgets WHERE window_id=?", (window.window_id,)).fetchone()
                if row is not None:
                    if tuple(row) != values:
                        raise MemoryConflict("budget_window_conflict")
                else:
                    if self._db.execute("SELECT 1 FROM maintenance_budgets WHERE start_ms<? AND end_ms>?", (window.end_ms, window.start_ms)).fetchone():
                        raise MemoryConflict("budget_window_overlap")
                    self._db.execute("INSERT INTO maintenance_budgets VALUES(?,?,?,?,?,?,?)", (window.window_id, *values))
                return self._budget(window.window_id)

    def _budget(self, window_id):
        row = self._db.execute("SELECT * FROM maintenance_budgets WHERE window_id=?", (window_id,)).fetchone()
        if row is None:
            raise MemoryNotFound("budget_not_found")
        window = BudgetWindow(window_id, row["start_ms"], row["end_ms"], row["max_calls"], Usage(row["max_input_tokens"], row["max_output_tokens"], row["max_cost_units"]))
        # Attempts are the sole accounting truth. Python integer sums retain
        # exact totals even when real overages exceed SQLite's integer sum.
        calls = 0
        totals = [0, 0, 0]
        for attempt in self._db.execute("SELECT reserved_input_tokens,reserved_output_tokens,reserved_cost_units,actual_input_tokens,actual_output_tokens,actual_cost_units FROM formation_attempts WHERE window_id=?", (window_id,)):
            calls += 1
            for index in range(3):
                totals[index] += attempt[index + 3] if attempt[index + 3] is not None else attempt[index]
        over = calls > window.max_calls or any(used > cap for used, cap in zip(totals, _usage_tuple(window.max_usage)))
        return BudgetStatus(window, calls, Usage(*totals), over)

    def budget_status(self, window_id: str) -> BudgetStatus:
        _identity(window_id)
        with self._store._lock:
            self._store._check()
            return self._budget(window_id)

    def _clock(self, now_ms, *, advance=True):
        last = self._db.execute("SELECT last_reservation_ms FROM maintenance_clock WHERE singleton=1").fetchone()[0]
        if now_ms < last:
            raise MemoryConflict("clock_rollback")
        if advance:
            self._db.execute("UPDATE maintenance_clock SET last_reservation_ms=? WHERE singleton=1", (now_ms,))

    def _cold_status(self, now_ms, max_runs):
        self._clock(now_ms, advance=False)
        rows = self._db.execute("SELECT a.outcome,COALESCE(a.cold_dispatched_at_ms,a.reserved_at_ms) anchor "
            "FROM formation_attempts a JOIN formation_tasks t ON t.task_id=a.task_id "
            "WHERE t.work_class='cold' AND (a.outcome='reserved' OR COALESCE(a.cold_dispatched_at_ms,a.reserved_at_ms)>?)",
            (now_ms-_COLD_WINDOW_MS,)).fetchall()
        pending = sum(row["outcome"] == "reserved" for row in rows)
        used = len(rows)
        if used < max_runs:
            earliest = now_ms
        elif pending >= max_runs:
            earliest = None
        else:
            expiries = sorted(row["anchor"]+_COLD_WINDOW_MS for row in rows if row["outcome"] != "reserved")
            earliest = expiries[used-max_runs]
        return ColdStatus(used, max(0, max_runs-used), max_runs, pending, earliest)

    def cold_status(self, now_ms: int, *, max_runs: int = 1) -> ColdStatus:
        """Read global Store-wide rolling slots without advancing the Host clock."""
        _integer(now_ms, "now_ms")
        _integer(max_runs, "cold_max_runs", 1, 2)
        with self._store._lock:
            self._store._check()
            return self._cold_status(now_ms, max_runs)

    @staticmethod
    def _attempt(row):
        actual = None if row["actual_input_tokens"] is None else Usage(row["actual_input_tokens"], row["actual_output_tokens"], row["actual_cost_units"])
        return Attempt(row["attempt_id"], row["task_id"], row["reservation_key"], row["window_id"], Usage(row["reserved_input_tokens"], row["reserved_output_tokens"], row["reserved_cost_units"]), actual, row["outcome"])

    def _attempt_row(self, access, attempt_id):
        _identity(attempt_id)
        row = self._db.execute("SELECT * FROM formation_attempts WHERE attempt_id=?", (attempt_id,)).fetchone()
        if row is None:
            raise MemoryNotFound("attempt_not_found")
        self._task_row(access, row["task_id"])
        return row

    def attempt(self, access: AccessScope, attempt_id: str) -> Attempt:
        with self._store._lock:
            self._store._check()
            return self._attempt(self._attempt_row(access, attempt_id))

    def reserve_attempt(self, access: AccessScope, task_id: str, *, reservation_key: str,
                        window_id: str, reserved: Usage, now_ms: int,
                        cold_max_runs: int = 1) -> AttemptReservation:
        _identity(reservation_key)
        _identity(window_id)
        _usage(reserved)
        _integer(now_ms, "now_ms")
        _integer(cold_max_runs, "cold_max_runs", 1, 2)
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                row = self._task_row(access, task_id)
                replay = self._db.execute("SELECT * FROM formation_attempts WHERE task_id=? AND reservation_key=?", (task_id, reservation_key)).fetchone()
                if replay is not None:
                    attempt = self._attempt(replay)
                    if attempt.window_id != window_id or attempt.reserved != reserved:
                        raise MemoryConflict("reservation_key_conflict")
                    return AttemptReservation(attempt, True)
                task = self._task(row)
                if task.state not in ("pending", "failed", "truncated", "unknown") or not self._current(access, task):
                    raise MemoryConflict("task_not_reservable")
                exclusive = self._active_row(task.stream_id,task.work_class,False)
                if exclusive is not None and exclusive["task_id"] != task.task_id:
                    raise MemoryConflict("stream_task_active")
                if task.attempts >= task.max_attempts:
                    raise MemoryConflict("task_attempts_exhausted")
                budget = self._budget(window_id)
                if not budget.window.start_ms <= now_ms < budget.window.end_ms:
                    raise MemoryConflict("outside_budget_window")
                if budget.calls + 1 > budget.window.max_calls or any(used + new > cap for used, new, cap in zip(_usage_tuple(budget.usage), _usage_tuple(reserved), _usage_tuple(budget.window.max_usage))):
                    raise MemoryConflict("budget_exhausted")
                if task.work_class == "cold" and self._cold_status(now_ms, cold_max_runs).remaining == 0:
                    raise MemoryConflict("cold_quota_exhausted")
                self._clock(now_ms)
                attempt_id = uuid4().hex
                self._db.execute("INSERT INTO formation_attempts(attempt_id,task_id,reservation_key,window_id,reserved_input_tokens,reserved_output_tokens,reserved_cost_units,outcome,reserved_at_ms) VALUES(?,?,?,?,?,?,?,'reserved',?)", (attempt_id, task_id, reservation_key, window_id, *_usage_tuple(reserved), now_ms))
                self._db.execute("UPDATE formation_tasks SET state='reserved',current_attempt_id=? WHERE task_id=?", (attempt_id, task_id))
                return AttemptReservation(self._attempt(self._attempt_row(access, attempt_id)), False)

    def validate_dispatch(self, access: AccessScope, attempt_id: str, *, now_ms: int,
                          cold_max_runs: int = 1) -> None:
        """Fresh Host-clock/source checkpoint; no additional charge or callback."""
        _integer(now_ms, "now_ms")
        _integer(cold_max_runs, "cold_max_runs", 1, 2)
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                row = self._attempt_row(access, attempt_id)
                task_row = self._task_row(access, row["task_id"])
                task = self._task(task_row)
                if (row["outcome"] != "reserved" or task.state != "reserved"
                        or task_row["current_attempt_id"] != attempt_id or not self._current(access, task)):
                    raise MemoryConflict("attempt_not_dispatchable")
                budget = self._budget(row["window_id"])
                if not budget.window.start_ms <= now_ms < budget.window.end_ms:
                    raise MemoryConflict("outside_budget_window")
                if budget.over_budget:
                    raise MemoryConflict("budget_exhausted")
                if task.work_class == "cold":
                    if row["cold_dispatched_at_ms"] is not None:
                        raise MemoryConflict("cold_attempt_already_dispatched")
                    if self._cold_status(now_ms, cold_max_runs).used > cold_max_runs:
                        raise MemoryConflict("cold_quota_exhausted")
                    self._db.execute("UPDATE formation_attempts SET cold_dispatched_at_ms=? WHERE attempt_id=?", (now_ms, attempt_id))
                self._clock(now_ms)

    def _record_usage(self, row, actual):
        if actual is None:
            return False
        if row["actual_input_tokens"] is not None:
            if self._attempt(row).actual != actual:
                raise MemoryConflict("usage_conflict")
            return False
        self._db.execute("UPDATE formation_attempts SET actual_input_tokens=?,actual_output_tokens=?,actual_cost_units=? WHERE attempt_id=?", (*_usage_tuple(actual), row["attempt_id"]))
        return True

    def _result(self, access, attempt_id, committed, replayed):
        row = self._attempt_row(access, attempt_id)
        return AttemptResult(self._attempt(row), self._task(self._task_row(access, row["task_id"])), self._budget(row["window_id"]), committed, replayed)

    def settle_usage(self, access: AccessScope, attempt_id: str, actual: Usage) -> AttemptResult:
        """Record accounting only, including late/unknown/over-reservation use."""
        _usage(actual)
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                row = self._attempt_row(access, attempt_id)
                changed = self._record_usage(row, actual)
                return self._result(access, attempt_id, False, not changed)

    def finish_attempt(self, access: AccessScope, attempt_id: str, *,
                       outcome: Literal["failed", "truncated", "unknown"], actual: Usage | None = None) -> AttemptResult:
        """Close an unsuccessful/unknown attempt; never advance processing."""
        if outcome not in ("failed", "truncated", "unknown"):
            raise MemoryValidationError("invalid_attempt_outcome")
        if actual is not None:
            _usage(actual)
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                row = self._attempt_row(access, attempt_id)
                if row["outcome"] not in ("reserved", outcome):
                    raise MemoryConflict("attempt_outcome_conflict")
                usage_changed = self._record_usage(row, actual)
                replayed = row["outcome"] == outcome and not usage_changed
                if row["outcome"] == "reserved":
                    self._db.execute("UPDATE formation_attempts SET outcome=? WHERE attempt_id=?", (outcome, attempt_id))
                    self._db.execute("UPDATE formation_tasks SET state=? WHERE task_id=? AND current_attempt_id=? AND state='reserved'", (outcome, row["task_id"], attempt_id))
                return self._result(access, attempt_id, False, replayed)

    def complete_no_candidates(self, access: AccessScope, attempt_id: str, *, actual: Usage | None = None) -> AttemptResult:
        """Confirm a complete empty result. This API cannot accept candidates.

        Usage knowledge is independent of result completeness. Invalidated,
        recovered or superseded attempts can settle usage but cannot commit.
        """
        if actual is not None:
            _usage(actual)
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                row = self._attempt_row(access, attempt_id)
                usage_changed = self._record_usage(row, actual)
                if row["outcome"] == "no_candidates":
                    return self._result(access, attempt_id, True, not usage_changed)
                if row["outcome"] != "reserved":
                    return self._result(access, attempt_id, False, not usage_changed)
                task_row = self._task_row(access, row["task_id"])
                task = self._task(task_row)
                valid = task.state == "reserved" and task_row["current_attempt_id"] == attempt_id and self._current(access, task)
                self._db.execute("UPDATE formation_attempts SET outcome=? WHERE attempt_id=?", ("no_candidates" if valid else "stale", attempt_id))
                if valid:
                    self._advance(task)
                elif task.state not in ("done", "stale", "abandoned"):
                    self._db.execute("UPDATE formation_tasks SET state='stale' WHERE task_id=?", (task.task_id,))
                return self._result(access, attempt_id, valid, False)
