"""Atomic pending proposals, exact source coordinates and transactional purge.

Pending proposals are not adopted memories or execution authority. A trusted
Host can separately confirm a user's explicit save or rejection.
Full formation read sets remain in formation_inputs, separate from each item's
jointly necessary evidence. No canonical source text or quote is persisted here.
"""
from __future__ import annotations

from collections.abc import Mapping, Sequence
from collections import deque
from contextlib import ExitStack, nullcontext
from dataclasses import asdict, dataclass, replace
from typing import TYPE_CHECKING, Literal
from uuid import uuid4

from .maintenance import Maintenance, Usage, Attempt, BudgetStatus, _integer, _usage
from .models import AccessScope, MemoryScope, SourceSpan, OperationResult, MemoryConflict, MemoryNotFound, MemoryValidationError
from .sources import _identity, _validate_source, locate_source_quote

if TYPE_CHECKING:
    from .executor import AdoptionDecision
    from .evidence import OutputReadSet


_MAX_CANDIDATES = 64
_MAX_EVIDENCE = 256
_MAX_BODY_CHARS = 131072
_MAX_QUOTE_CHARS = 131072
_MAX_CANONICAL_CHARS = 1_000_000
_KINDS = ("fact", "preference", "instruction", "event", "proposal", "hypothesis")
_COMPARISON_KINDS = ("reported_change", "reported_correction", "coexisting", "unresolved")


@dataclass(frozen=True)
class EvidenceQuote:
    source: SourceSpan
    quote: str


@dataclass(frozen=True)
class ComparisonDraft:
    kind: str
    left: EvidenceQuote
    right: EvidenceQuote


@dataclass(frozen=True)
class Comparison:
    kind: str
    left: SourceSpan
    right: SourceSpan


@dataclass(frozen=True)
class CandidateDraft:
    item_key: str
    text: str
    kind: str
    supports: tuple[EvidenceQuote, ...]
    condition: str | None = None
    transitions: tuple[EvidenceQuote, ...] = ()
    comparison: ComparisonDraft | None = None


@dataclass(frozen=True)
class CandidateEvidence:
    role: Literal["support", "transition"]
    group: int
    source: SourceSpan


@dataclass(frozen=True)
class CandidateReference:
    candidate_id: str
    row_version: int


@dataclass(frozen=True)
class Candidate:
    candidate_id: str
    task_id: str
    attempt_id: str
    item_key: str
    scope: MemoryScope
    text: str | None
    kind: str
    condition: str | None
    created_at_ms: int
    row_version: int
    state: str
    invalid_reason: str | None
    index_state: str
    evidence: tuple[CandidateEvidence, ...]
    review_state: Literal["pending", "accepted", "rejected"] = "pending"
    reviewed_at_ms: int | None = None
    memory_id: str | None = None
    comparison: Comparison | None = None


@dataclass(frozen=True)
class CandidateCommitResult:
    status: str
    candidates: tuple[CandidateReference, ...]
    attempt: Attempt
    budget: BudgetStatus
    replayed: bool
    quote_failures: tuple[tuple[str, str], ...] = ()


@dataclass(frozen=True)
class DerivedAuthorization:
    """Host configuration approval, not evidence of semantic qualification."""
    authorization_id: str
    stream_id: str
    policy_id: str
    policy_version: str
    pipeline_version: str
    generation: int
    enabled: bool


@dataclass(frozen=True)
class SelectionPublishResult:
    """Durable set receipt; input references are not new pending versions."""
    candidates: tuple[CandidateReference, ...]
    results: tuple[OperationResult, ...]
    replayed: bool
    cleanup_pending: bool


def _uses_mask(uses):
    if not isinstance(uses, (tuple, list)):
        raise MemoryValidationError("invalid_derived_uses")
    uses = tuple(uses)
    if not uses or any(p not in ("lookup", "ordinary") for p in uses):
        raise MemoryValidationError("invalid_derived_uses")
    return sum({1 if p == "lookup" else 2 for p in uses})


def _invalidate_memories(store, access, memory_ids, reason, *, privacy, permanent=False):
    _invalidate_graph(store, access, memory_ids, (), reason, privacy=privacy, permanent=permanent)


def _invalidate_outputs(store, access, outputs, reason, *, privacy, permanent=False):
    _invalidate_graph(store, access, (), outputs, reason, privacy=privacy, permanent=permanent)


def _walk_invalidation_graph(store, access, memory_ids, outputs, *, privacy, permanent=False):
    """Read-only directed walker: Memory -> output -> output/candidate -> Memory.

    Resolve neighbours before yielding: a consumer may clear the current body.
    Privacy traverses ordinary tombstones. Independent inputs are never reverse
    edges. Preview and mutation use the same bounded persisted relationships.
    """
    db = store._db
    from .store import _MAX_OUTPUT_GRAPH
    queue = deque(dict.fromkeys([*(('memory', mid) for mid in memory_ids), *(('output', s) for s in outputs)]))
    queued = set(queue)
    def enqueue(nodes):
        for node in nodes:
            if node not in queued:
                queued.add(node)
                if len(queued) > _MAX_OUTPUT_GRAPH:
                    raise MemoryConflict("output_invalidation_limit")
                queue.append(node)
    visited = set()
    while queue:
        node = queue.popleft()
        if node in visited:
            continue
        visited.add(node)
        if len(visited) > _MAX_OUTPUT_GRAPH:
            raise MemoryConflict("output_invalidation_limit")
        kind, value = node
        if kind == 'memory':
            mid = value
            row = db.execute("SELECT invalid_reason FROM memories WHERE memory_id=? AND user_id=? AND retention='dependent'", (mid, access.user_id)).fetchone()
            if row is None:
                continue
            if row["invalid_reason"] is not None and not privacy:
                continue
            children = store._memory_use_sources(access, mid)
            yield node
            enqueue(('output', s) for s in children)
            continue
        output = value
        args = access.user_id, output.namespace, output.record_key, output.revision
        binding = db.execute("SELECT invalid_reason FROM output_bindings WHERE user_id=? AND namespace=? AND record_key=? AND revision=?", args).fetchone()
        children, memory_ids, body_outputs = (), (), ()
        if privacy or binding is None or binding["invalid_reason"] is None:
            children = store._direct_output_children(access.user_id, output, cross_revision=permanent)
            relation, parameters = _output_target_relation(access, output, privacy=privacy, permanent=permanent)
            memory_ids, body_outputs = _target_dependencies(store, access, relation, parameters, privacy=privacy)
        yield node
        enqueue(('output', s) for s in children)
        enqueue(('memory', mid) for mid in memory_ids)
        enqueue(('output', source) for source in body_outputs)


def _output_target_relation(access, output, *, privacy, permanent):
    source_args = (output.namespace, output.record_key) + (() if permanent else (output.revision,))
    input_filter = "i.namespace=? AND i.record_key=?" + ("" if permanent else " AND i.revision=?")
    relation = ("FROM formation_authority_inputs i JOIN candidates target ON target.task_id=i.task_id " if privacy else
                "FROM candidate_evidence i JOIN candidates target ON target.candidate_id=i.candidate_id ")
    relation += "JOIN formation_tasks t ON t.task_id=target.task_id JOIN source_streams s ON s.stream_id=t.stream_id WHERE " + input_filter + " AND s.user_id=?"
    return relation, (*source_args, access.user_id)


def _invalidate_graph(store, access, memory_ids, outputs, reason, *, privacy, permanent=False):
    db = store._db
    for kind, value in _walk_invalidation_graph(store, access, memory_ids, outputs, privacy=privacy, permanent=permanent):
        if kind == 'memory':
            mid = value
            row = db.execute("SELECT invalid_reason FROM memories WHERE memory_id=?", (mid,)).fetchone()
            if row["invalid_reason"] is None:
                db.execute("DELETE FROM search_documents WHERE memory_id=?", (mid,))
                db.execute("DELETE FROM embeddings WHERE memory_id=?", (mid,))
                db.execute("UPDATE memories SET text=NULL,condition_text=NULL,invalid_reason=?,row_version=row_version+1,index_state='pending',index_version=NULL,index_error=NULL WHERE memory_id=?", (reason, mid))
                db.execute("UPDATE store_state SET cleanup_pending=1")
                store._change()
            continue
        output = value
        args = access.user_id, output.namespace, output.record_key, output.revision
        if permanent:
            # Only an explicit forget/exclude operation creates irreversible
            # exclusions. Permission loss uses full-read-set cleanup without
            # forbidding an independent new revision of the Host record.
            excluded = db.execute("INSERT INTO exclusions(user_id,namespace,record_key,revision,start_cp,end_cp) SELECT ?,?,?,?,NULL,NULL WHERE NOT EXISTS (SELECT 1 FROM exclusions WHERE user_id=? AND namespace=? AND record_key=? AND revision=? AND start_cp IS NULL)", (*args, *args)).rowcount
            if excluded:
                store._change()
        db.execute("INSERT OR IGNORE INTO output_bindings(user_id,namespace,record_key,revision) VALUES(?,?,?,?)", args)
        changed = db.execute("UPDATE output_bindings SET invalid_reason=COALESCE(invalid_reason,?),privacy_invalidated=MAX(privacy_invalidated,?) WHERE user_id=? AND namespace=? AND record_key=? AND revision=? AND (invalid_reason IS NULL OR privacy_invalidated<?)", (reason, int(privacy), *args, int(privacy))).rowcount
        if changed:
            store._change()
        elif not privacy:
            continue
        # Explicit exclusions cross revisions; permission/privacy cleanup keeps
        # the exact output version while still following its full read set.
        source_filter = "namespace=? AND record_key=?" + ("" if permanent else " AND revision=?")
        source_args = (output.namespace, output.record_key) + (() if permanent else (output.revision,))
        db.execute("DELETE FROM retrieval_documents WHERE target_kind='source' AND " + source_filter + " AND stream_id IN (SELECT stream_id FROM source_streams WHERE user_id=?)", (*source_args, access.user_id))
        input_filter = "i.namespace=? AND i.record_key=?" + ("" if permanent else " AND i.revision=?")
        task_selection = "SELECT i.task_id FROM formation_authority_inputs i JOIN formation_tasks t ON t.task_id=i.task_id JOIN source_streams s ON s.stream_id=t.stream_id WHERE " + input_filter + " AND s.user_id=?"
        db.execute("UPDATE formation_tasks SET state='stale' WHERE state NOT IN ('done','stale','abandoned') AND task_id IN (" + task_selection + ")", (*source_args, access.user_id))
        db.execute("UPDATE formation_attempts SET outcome='stale' WHERE outcome='reserved' AND task_id IN (" + task_selection + ")", (*source_args, access.user_id))
        relation, parameters = _output_target_relation(access, output, privacy=privacy, permanent=permanent)
        _purge_targets(store, access, relation, parameters, reason, privacy=privacy, propagate=False)


def _invalidate_raw_sources(store, access, sources, reason, *, privacy, permanent=False):
    outputs = set()
    for source in sources:
        outputs.update(store._raw_reader_outputs(access.user_id, source, cross_revision=privacy))
        if store._known_output(access.user_id, source):
            outputs.add(SourceSpan(source.namespace, source.record_key, source.revision))
    _invalidate_outputs(store, access, outputs, reason, privacy=privacy, permanent=permanent)


def _target_dependencies(store, access, source_targets, parameters, *, privacy=False, use_mask=None):
    """Select the exact outgoing edges before bodies are cleared; no writes."""
    db = store._db
    # Preserve the old version before clearing bodies. Privacy revisits every
    # historical version, including candidates already reviewed or invalidated.
    # Ordinary retirement follows only the version being retired now.
    body_outputs = ()
    if use_mask is None:
        selected = "SELECT DISTINCT r.namespace,r.record_key,r.revision FROM output_candidate_reads r WHERE r.user_id=? AND r.candidate_id IN (SELECT target.candidate_id " + source_targets
        if not privacy:
            selected += " AND target.state='pending' AND target.row_version=r.row_version"
        selected += ")"
        body_outputs = tuple(SourceSpan(*row) for row in db.execute(selected, (access.user_id, *parameters)))
    selected = "SELECT m.memory_id FROM origins o JOIN memories m ON m.memory_id=o.memory_id WHERE m.retention='dependent'" + ("" if privacy else " AND m.invalid_reason IS NULL") + " AND o.candidate_id IN (SELECT target.candidate_id " + source_targets + ")"
    args = parameters
    if use_mask is not None:
        selected += " AND (m.use_mask & ?)<>0"
        args = (*parameters, use_mask)
    memory_ids = tuple(row[0] for row in db.execute(selected, args))
    return memory_ids, body_outputs


def _purge_targets(store, access, source_targets, parameters, reason, *, privacy=False, use_mask=None, propagate=True, permanent=False):
    """Private fixed-SQL hook: caller already owns the store transaction."""
    db = store._db
    memory_ids, body_outputs = (_target_dependencies(store, access, source_targets, parameters, privacy=privacy, use_mask=use_mask)
                               if propagate else ((), ()))
    # Clearing one item's body also clears its batch's content-derived replay
    # fingerprint. Surviving independent items retain their own pending bodies.
    cleared = 0 if use_mask is not None else db.execute("UPDATE candidate_submissions SET fingerprint=NULL WHERE fingerprint IS NOT NULL AND attempt_id IN (SELECT target.attempt_id " + source_targets + ")", parameters).rowcount
    # Filter pending rows inside the source-driven selection. The outer UPDATE
    # then addresses candidate primary keys rather than scanning all pending work.
    purged = 0 if use_mask is not None else db.execute("UPDATE candidates SET text=NULL,condition_text=NULL,state='invalidated',invalid_reason=?,index_state='inactive',row_version=row_version+1 WHERE candidate_id IN (SELECT target.candidate_id " + source_targets + " AND target.state='pending')", (reason, *parameters)).rowcount
    if cleared or purged:
        db.execute("UPDATE store_state SET cleanup_pending=1")
        store._change()
    if propagate:
        _invalidate_graph(store, access, memory_ids, body_outputs, reason, privacy=privacy, permanent=permanent)
    return memory_ids, body_outputs


def _exclusion_target_relation(access, source):
    return ("FROM formation_authority_inputs i JOIN formation_tasks t ON t.task_id=i.task_id JOIN source_streams s ON s.stream_id=t.stream_id CROSS JOIN candidates target WHERE target.task_id=i.task_id AND i.namespace=? AND i.record_key=? AND s.user_id=?",
            (source.namespace, source.record_key, access.user_id))


def _exclusion_impact(store, access, sources):
    """Private read-only counterpart of permanent privacy propagation.

    Results are owner-wide internal coordinates, not display authorization.
    The caller holds the store lock; neither a transaction nor a clone is used.
    """
    memories, outputs = set(), set()
    for source in sources:
        relation, parameters = _exclusion_target_relation(access, source)
        mids, bodies = _target_dependencies(store, access, relation, parameters, privacy=True)
        memories.update(mids)
        outputs.update(bodies)
        outputs.update(store._raw_reader_outputs(access.user_id, source, cross_revision=True))
        if store._known_output(access.user_id, source):
            outputs.add(SourceSpan(source.namespace, source.record_key, source.revision))
    nodes = tuple(_walk_invalidation_graph(store, access, memories, outputs, privacy=True, permanent=True))
    return (tuple(sorted(value for kind, value in nodes if kind == 'memory')),
            store._sort_sources(value for kind, value in nodes if kind == 'output'))


def _invalidate_exclusions(store, access, sources, reason="source_excluded", *, use_mask=None, permanent=False):
    if permanent and reason == "source_excluded" and use_mask is None:
        from .reformation import capture
        capture(Maintenance(store), access, sources)
    # Every formation input is whole-record. Existing _check_origin excludes a
    # whole input on any matching record exclusion, conservatively across
    # revisions without a Host-authorized position mapping. Do not add exclusions
    # for the other independent supports whose pending output is being purged.
    for source in sources:
        # CROSS JOIN keeps candidate lookup behind the indexed source read set;
        # otherwise a pending-state index can pull unrelated work into the scan.
        relation, parameters = _exclusion_target_relation(access, source)
        _purge_targets(store, access, relation, parameters, reason, privacy=True, use_mask=use_mask, permanent=permanent)
    if use_mask is None:
        _invalidate_raw_sources(store, access, sources, reason, privacy=True, permanent=permanent)


def _invalidate_retirements(store, access, sources, *, reason="source_retired"):
    # This is the exact revision/half-open overlap relation of store._overlap.
    # Unlike privacy exclusions, lifecycle retirement follows each item's own
    # support/transition coordinates and never the rest of its formation read set.
    for source in sources:
        # A whole-record cache contains every fragment of this revision. A
        # disjoint independently evidenced candidate may still remain pending.
        store._db.execute("DELETE FROM retrieval_documents WHERE target_kind='source' AND namespace=? AND record_key=? AND revision=? AND stream_id IN (SELECT stream_id FROM source_streams WHERE user_id=?)",
                          (source.namespace, source.record_key, source.revision, access.user_id))
        _purge_targets(store, access, "FROM candidate_evidence e JOIN candidates target ON target.candidate_id=e.candidate_id JOIN formation_tasks t ON t.task_id=target.task_id JOIN source_streams s ON s.stream_id=t.stream_id WHERE e.namespace=? AND e.record_key=? AND e.revision=? AND (? IS NULL OR e.start_cp IS NULL OR (e.start_cp<? AND e.end_cp>?)) AND s.user_id=?",
                     (source.namespace, source.record_key, source.revision, source.start_cp, source.end_cp, source.start_cp, access.user_id), reason)
    _invalidate_raw_sources(store, access, sources, reason, privacy=False)


def _invalidate_source_change(store, access, old, change):
    # Called for EACH accepted effective event, including intermediate withdrawal
    # or revocation in a batch. Comparing only the final state would miss ABA.
    privacy = (change.action == "withdraw" or (old is not None and (
        old["formation_allowed"] != int(change.formation_allowed)
        or old["policy_revision"] != change.policy_revision)))
    ordinary_retired = False
    if privacy:
        _invalidate_exclusions(store, access, (change.source,), "source_withdrawn" if change.action == "withdraw" else "source_policy_changed")
    elif old is not None and (old["revision"] != change.source.revision or old["recorded_at_ms"] != change.recorded_at_ms):
        _invalidate_retirements(store, access, (SourceSpan(change.source.namespace, change.source.record_key, old["revision"]),))
        ordinary_retired = True
    if old is not None:
        # Any changed snapshot retires already delivered whole-record reads.
        # Lookup revocation is privacy for raw readers only, not independent
        # derived memories formed under a different permission.
        lookup_revoked = bool(old["lookup_allowed"] and not change.lookup_allowed)
        if not privacy and (not ordinary_retired or lookup_revoked):
            _invalidate_raw_sources(store, access, (SourceSpan(change.source.namespace, change.source.record_key, old["revision"]),),
                "source_lookup_revoked" if lookup_revoked else "source_snapshot_changed", privacy=lookup_revoked)
        removed = old["derived_use_mask"] & ~change.derived_use_mask
        if removed:
            _invalidate_exclusions(store, access, (change.source,), "derived_permission_revoked", use_mask=removed)


class Candidates:
    """Pending proposals and Host-confirmed, single-item explicit review."""

    def _commit_guard(self, access):
        """Host serialization after compilation, before the Store lock."""
        return nullcontext()

    def _publish_guard(self, access, candidate_id):
        """Host authorization immediately before a single derived publication."""
        return nullcontext()

    def __init__(self, store):
        self._store = store
        self._maintenance = Maintenance(store)

    @property
    def _db(self):
        return self._store._db

    @staticmethod
    def _authorization(row):
        return DerivedAuthorization(row["authorization_id"], row["stream_id"], row["policy_id"], row["policy_version"], row["pipeline_version"], row["generation"], bool(row["enabled"]))

    def derived_authorization(self, access: AccessScope, authorization_id: str) -> DerivedAuthorization:
        _identity(authorization_id)
        with self._store._lock:
            self._store._check()
            row = self._db.execute("SELECT * FROM derived_authorizations WHERE authorization_id=?", (authorization_id,)).fetchone()
            if row is None:
                raise MemoryNotFound("derived_authorization_not_found")
            self._maintenance._stream(access, row["stream_id"])
            return self._authorization(row)

    def register_derived_policy(self, access: AccessScope, stream_id: str, *, policy_id: str,
                                policy_version: str, pipeline_version: str) -> DerivedAuthorization:
        """Register immutable Host configuration, disabled until explicit enable.

        Host owns semantic qualification and approval. No model, source flag or
        candidate kind can register or enable a policy on the Host's behalf.
        """
        for value in (policy_id, policy_version, pipeline_version):
            _identity(value)
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                self._maintenance._stream(access, stream_id)
                row = self._db.execute("SELECT * FROM derived_authorizations WHERE stream_id=? AND policy_id=? AND policy_version=?", (stream_id, policy_id, policy_version)).fetchone()
                if row is not None:
                    if row["pipeline_version"] != pipeline_version:
                        raise MemoryConflict("derived_policy_binding_conflict")
                    return self._authorization(row)
                aid = uuid4().hex
                self._db.execute("INSERT INTO derived_authorizations VALUES(?,?,?,?,?,1,0)", (aid, stream_id, policy_id, policy_version, pipeline_version))
                self._store._change()
                return self.derived_authorization(access, aid)

    def set_derived_policy_enabled(self, access: AccessScope, authorization_id: str,
                                   expected_generation: int, *, enabled: bool) -> DerivedAuthorization:
        """Compare-and-set Host approval; revocation and purge share a commit."""
        _integer(expected_generation, "expected_generation", 1)
        if not isinstance(enabled, bool):
            raise MemoryValidationError("invalid_derived_policy_state")
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                current = self.derived_authorization(access, authorization_id)
                if current.generation != expected_generation:
                    raise MemoryConflict("stale_derived_authorization")
                if current.enabled == enabled:
                    return current
                self._db.execute("UPDATE derived_authorizations SET enabled=?,generation=generation+1 WHERE authorization_id=?", (int(enabled), authorization_id))
                if not enabled:
                    mids = tuple(row[0] for row in self._db.execute("SELECT memory_id FROM memories WHERE authorization_id=? AND retention='dependent'", (authorization_id,)))
                    _invalidate_memories(self._store, access, mids, "authorization_revoked", privacy=True)
                self._store._change()
                result = self.derived_authorization(access, authorization_id)
            if self._store._cleanup_pending():
                self._store.cleanup()
            return result

    def _publish_eligible(self, access, candidate, authorization, use_mask, *, checked_inputs=None):
        task = self._maintenance._task(self._maintenance._task_row(access, candidate.task_id))
        if not task.advances_cursor:
            from .maintenance import _target_use_mask
            allowed = _target_use_mask(task.target_uses)
            if allowed and use_mask & allowed != use_mask:
                raise MemoryConflict("reformation_target_uses_expansion")
        if authorization.stream_id != task.stream_id or authorization.pipeline_version != task.pipeline_version:
            raise MemoryConflict("derived_policy_task_mismatch")
        # Atomic selection shares this cache only on its raw-authority path:
        # its own candidate retirements cannot change those source rows.
        # Output-source tasks keep normal checks. Never cache item or policy
        # generation validation.
        cache_key = task.task_id, use_mask
        if checked_inputs is not None and cache_key in checked_inputs:
            return
        retirements = self._store.source_retirements(access)
        # Completed task cursor is deliberately irrelevant. The entire actual
        # analysis read-set must still describe this exact authorized snapshot.
        for item in self._maintenance._authority_inputs(task.task_id):
            source = item.source
            if task.reformation_event_id is not None:
                self._maintenance._reformation_input(access, item, candidate.scope, use_mask, retirements)
            row = self._db.execute("SELECT * FROM source_states WHERE namespace=? AND record_key=?", (source.namespace, source.record_key)).fetchone()
            if (row is None or row["state_version"] != item.state_version
                    or row["revision"] != source.revision or row["policy_revision"] != item.policy_revision
                    or row["recorded_at_ms"] != item.recorded_at_ms or row["action"] != "upsert"
                    or not row["formation_allowed"] or row["derived_use_mask"] & use_mask != use_mask
                    or not self._maintenance._policy_allows(access, source, retirements)):
                raise MemoryConflict("stale_derived_input")
            self._maintenance._source_scope(access, row, candidate.scope)
            # A Host output's surface source flags cannot wash away the current
            # purposes or scope of its known versioned memory dependencies.
            # Ordinary sources without recall_uses contribute no parent edges.
            for purpose, bit in (("lookup", 1), ("ordinary", 2)):
                if use_mask & bit:
                    self._maintenance._source_scope(access, row, candidate.scope, purpose=purpose)
        if checked_inputs is not None:
            checked_inputs.add(cache_key)

    def publish_derived(self, access: AccessScope, candidate_id: str, expected_version: int, *,
                        authorization_id: str, expected_generation: int, operation_id: str,
                        item_id: str, memory_kind: str, now_ms: int,
                        uses: tuple[str, ...] = ("lookup",)) -> OperationResult:
        """Execute a trusted Host's already approved policy decision, atomically.

        Bodies and evidence come only from the pending DB row. This is dependent
        retention and never an explicit save, user confirmation or receipt.
        """
        self._store._access(access)
        self._store._key(operation_id, item_id)
        _integer(now_ms, "now_ms")
        mask, fp = self._derived_parameters(candidate_id, expected_version, authorization_id,
            expected_generation, memory_kind, uses)
        with ExitStack() as owned:
            with self._publish_guard(access, candidate_id):
                owned.enter_context(self._store._lock)
                self._store._check()
                with self._store._transaction():
                    result = self._publish_derived_in_transaction(access, candidate_id, expected_version,
                        authorization_id=authorization_id, expected_generation=expected_generation,
                        operation_id=operation_id, item_id=item_id, memory_kind=memory_kind,
                        now_ms=now_ms, mask=mask, fingerprint=fp)
                    if result.replayed:
                        return result
            clean = self._store.cleanup()
            return replace(result, cleanup_pending=not clean)

    def _derived_parameters(self, candidate_id, expected_version, authorization_id,
                            expected_generation, memory_kind, uses):
        _identity(candidate_id)
        _identity(authorization_id)
        _integer(expected_version, "expected_version", 1)
        _integer(expected_generation, "expected_generation", 1)
        if memory_kind not in ("fact", "preference", "instruction", "event"):
            raise MemoryValidationError("invalid_kind")
        mask = _uses_mask(uses)
        fp = self._store._fingerprint(["candidate_publish", candidate_id, expected_version, authorization_id, expected_generation, memory_kind, mask])
        return mask, fp

    def _publication_candidate(self, access, candidate_id, expected_version,
                               authorization_id, expected_generation, mask, *, checked_inputs=None):
        candidate = self.detail(access, candidate_id)
        if candidate.state != "pending" or candidate.row_version != expected_version:
            raise MemoryConflict("stale_candidate_reference")
        authorization = self.derived_authorization(access, authorization_id)
        if not authorization.enabled or authorization.generation != expected_generation:
            raise MemoryConflict("stale_derived_authorization")
        self._publish_eligible(access, candidate, authorization, mask, checked_inputs=checked_inputs)
        return candidate, authorization

    def _publish_derived_in_transaction(self, access, candidate_id, expected_version, *,
                                        authorization_id, expected_generation, operation_id,
                                        item_id, memory_kind, now_ms, mask, fingerprint,
                                        validated=None):
        """Original one-item mutation; caller owns transaction and later cleanup."""
        replay = self._store._replay(access, operation_id, item_id, fingerprint, "candidate_publish")
        if replay:
            return replay
        candidate, authorization = validated if validated is not None else self._publication_candidate(
            access, candidate_id, expected_version, authorization_id, expected_generation, mask)
        self._store._input(candidate.text, candidate.condition, memory_kind, now_ms, None)
        mid = self._store._insert(candidate.scope, candidate.text, memory_kind, candidate.condition, None,
            now_ms, authorization=authorization, use_mask=mask)
        self._db.execute("INSERT INTO origins(memory_id,candidate_id) VALUES(?,?)", (mid, candidate_id))
        self._store._record(access, operation_id, item_id, "candidate_publish", mid, "published", fingerprint,
            candidate_id=candidate_id, reviewed_at_ms=now_ms)
        self._db.execute("UPDATE candidates SET state='published',text=NULL,condition_text=NULL,index_state='inactive',row_version=row_version+1 WHERE candidate_id=?", (candidate_id,))
        _invalidate_outputs(self._store, access,
            self._store._candidate_use_sources(access, candidate_id, expected_version),
            "candidate_published", privacy=False)
        self._db.execute("UPDATE candidate_submissions SET fingerprint=NULL WHERE attempt_id=?", (candidate.attempt_id,))
        self._db.execute("UPDATE store_state SET cleanup_pending=1")
        return OperationResult("published", mid, 1, False, "pending", True)

    def _selection_task(self, access, references):
        """Scope-filtered metadata, valid for current commit or receipt replay."""
        where, parameters = self._store._where(access, "s")
        rows = [self._db.execute("SELECT c.task_id,s.scope_kind,s.user_id,s.character_id,s.project_id FROM candidates c JOIN formation_tasks t ON t.task_id=c.task_id JOIN source_streams s ON s.stream_id=t.stream_id WHERE c.candidate_id=? AND " + where,
            (ref.candidate_id, *parameters)).fetchone() for ref in references]
        if any(row is None for row in rows):
            raise MemoryNotFound("candidate_not_found")
        if len({row["task_id"] for row in rows}) != 1:
            raise MemoryValidationError("selection_snapshot_requires_one_task")
        first = rows[0]
        return first["task_id"], MemoryScope(first["scope_kind"], first["user_id"],
            first["character_id"], first["project_id"])

    def publish_selection(self, access: AccessScope, snapshot: OutputReadSet,
                          decisions: Sequence[tuple[CandidateReference, AdoptionDecision]], *,
                          operation_id: str, item_id: str, now_ms: int) -> SelectionPublishResult:
        """Conditionally publish one trusted Host choice in a single transaction.

        Actual comparison versions belong to one task; direct source pins must
        already be part of its persistent authority inputs. Extra memory/output
        reads are not accepted as one-time-only adoption authority. The Host
        records all actual reads and owns semantic selection. Exact replay is a
        receipt, never permission to read or resurrect retired content.
        """
        from .evidence import _read_set
        from .executor import AdoptionDecision
        self._store._access(access)
        self._store._key(operation_id, item_id)
        _integer(now_ms, "now_ms")
        reads = _read_set(snapshot)
        if not 1 <= len(reads.candidates) <= _MAX_CANDIDATES or reads.memories or reads.outputs:
            raise MemoryValidationError("selection_snapshot_requires_task_candidates_and_sources")
        if not isinstance(decisions, (tuple, list)) or len(decisions) > _MAX_CANDIDATES:
            raise MemoryValidationError("invalid_selection_decisions")
        compared = {ref.candidate_id: ref.row_version for ref in reads.candidates}
        chosen = {}
        for item in decisions:
            if not isinstance(item, (tuple, list)) or len(item) != 2:
                raise MemoryValidationError("invalid_selection_decision")
            ref, decision = item
            if not isinstance(ref, CandidateReference) or not isinstance(decision, AdoptionDecision):
                raise MemoryValidationError("invalid_selection_decision")
            if ref.candidate_id in chosen:
                raise MemoryValidationError("duplicate_selection_candidate")
            if compared.get(ref.candidate_id) != ref.row_version:
                raise MemoryValidationError("selected_candidate_not_in_snapshot")
            mask, fingerprint = self._derived_parameters(ref.candidate_id, ref.row_version,
                decision.authorization_id, decision.generation, decision.memory_kind, decision.uses)
            member = "selection-member:" + self._store._fingerprint([item_id, ref.candidate_id])
            chosen[ref.candidate_id] = (ref, decision, mask, fingerprint, member)
        ordered = tuple(chosen[key] for key in sorted(chosen))
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                task_id, scope = self._selection_task(access, reads.candidates)
                fp = self._store._fingerprint(["candidate_publish_set", task_id, asdict(scope), asdict(reads),
                    [(asdict(ref), decision.authorization_id, decision.generation, decision.memory_kind, mask)
                     for ref, decision, mask, _, _ in ordered]])
                previous = self._db.execute("SELECT operation_kind,fingerprint,formation_task_id FROM operations WHERE user_id=? AND operation_id=? AND item_id=?", (access.user_id, operation_id, item_id)).fetchone()
                if previous is not None:
                    if previous["operation_kind"] != "candidate_publish_set" or previous["fingerprint"] != fp or previous["formation_task_id"] != task_id:
                        raise MemoryConflict("operation_key_reused")
                    results = []
                    for ref, decision, mask, fingerprint, member in ordered:
                        result = self._store._replay(access, operation_id, member, fingerprint, "candidate_publish")
                        if result is None:
                            raise MemoryConflict("selection_receipt_incomplete")
                        results.append(result)
                    return SelectionPublishResult(tuple(item[0] for item in ordered), tuple(results), True,
                        self._store._cleanup_pending())
                authority = tuple(self._maintenance._authority_inputs(task_id))
                if any(pin not in authority for pin in reads.sources):
                    raise MemoryValidationError("selection_source_outside_task")
                # Registered upstream outputs retain the original per-item
                # current dependency checks. Only raw inputs are unaffected by
                # this transaction's own candidate/output retirements.
                raw_inputs_only = not any(self._store._known_output(access.user_id, pin.source) for pin in authority)
                current = self._store.capture_read_set(access, candidates=reads.candidates, sources=reads.sources,
                    now_ms=now_ms, purpose="lookup", review_pending=True)
                if current != reads:
                    raise MemoryConflict("selection_snapshot_changed")
                prepared = []
                checked_inputs = set() if raw_inputs_only else None
                for ref, decision, mask, _, member in ordered:
                    if self._db.execute("SELECT 1 FROM operations WHERE user_id=? AND operation_id=? AND item_id=?", (access.user_id, operation_id, member)).fetchone():
                        raise MemoryConflict("operation_key_reused")
                    prepared.append(self._publication_candidate(access, ref.candidate_id, ref.row_version,
                        decision.authorization_id, decision.generation, mask, checked_inputs=checked_inputs))
                results = tuple(self._publish_derived_in_transaction(access, ref.candidate_id, ref.row_version,
                    authorization_id=decision.authorization_id, expected_generation=decision.generation,
                    operation_id=operation_id, item_id=member, memory_kind=decision.memory_kind,
                    now_ms=now_ms, mask=mask, fingerprint=fingerprint,
                    validated=validated if raw_inputs_only else None)
                    for (ref, decision, mask, fingerprint, member), validated in zip(ordered, prepared))
                self._store._record(access, operation_id, item_id, "candidate_publish_set", None,
                    "published_set" if ordered else "empty_selection", fp,
                    formation_task_id=task_id, reviewed_at_ms=now_ms)
            clean = self._store.cleanup()
            return SelectionPublishResult(tuple(item[0] for item in ordered),
                tuple(replace(result, cleanup_pending=not clean) for result in results), False, not clean)

    def _receipt(self, access, attempt_id, status, replayed, quote_failures=()):
        attempt = self._maintenance._attempt(self._maintenance._attempt_row(access, attempt_id))
        references = tuple(CandidateReference(row[0], row[1]) for row in self._db.execute("SELECT candidate_id,row_version FROM candidates WHERE attempt_id=? ORDER BY item_key", (attempt_id,)))
        return CandidateCommitResult(status, references, attempt, self._maintenance._budget(attempt.window_id), replayed, quote_failures)

    def result(self, access: AccessScope, attempt_id: str) -> CandidateCommitResult:
        """Recover committed references, including terminal items, without bodies."""
        with self._store._lock:
            self._store._check()
            self._maintenance._attempt_row(access, attempt_id)
            if not self._db.execute("SELECT 1 FROM candidate_submissions WHERE attempt_id=?", (attempt_id,)).fetchone():
                raise MemoryNotFound("candidate_result_not_found")
            return self._receipt(access, attempt_id, "committed", True)

    def _compile(self, task, drafts, canonical_texts, now_ms, *, isolate_quote_failures=False):
        if not isinstance(drafts, (list, tuple)) or not 1 <= len(drafts) <= _MAX_CANDIDATES:
            raise MemoryValidationError("invalid_candidate_batch")
        frozen = []
        for draft in drafts:
            if not isinstance(draft, CandidateDraft) or not isinstance(draft.supports, (list, tuple)) or not isinstance(draft.transitions, (list, tuple)):
                raise MemoryValidationError("invalid_candidate_draft")
            frozen.append(replace(draft, supports=tuple(draft.supports), transitions=tuple(draft.transitions)))
        if not isinstance(canonical_texts, Mapping):
            raise MemoryValidationError("invalid_canonical_sources")
        canonical_texts = dict(canonical_texts)
        fixed = {item.source for item in task.inputs}
        if len(canonical_texts) > len(fixed):
            raise MemoryValidationError("candidate_source_not_in_task")
        canonical_chars = 0
        for source, text in canonical_texts.items():
            _validate_source(source)
            if source not in fixed:
                raise MemoryValidationError("candidate_source_not_in_task")
            if not isinstance(text, str):
                raise MemoryValidationError("invalid_source_text")
            canonical_chars += len(text)
        if canonical_chars > _MAX_CANONICAL_CHARS:
            raise MemoryValidationError("candidate_canonical_limit")
        keys = set()
        bodies = quotes = evidence_count = 0
        def validate_quote(quotation):
            nonlocal quotes, evidence_count
            if not isinstance(quotation, EvidenceQuote):
                raise MemoryValidationError("invalid_candidate_evidence")
            source = quotation.source
            _validate_source(source)
            if source not in fixed:
                raise MemoryValidationError("candidate_source_not_in_task")
            if source not in canonical_texts:
                raise MemoryValidationError("candidate_source_text_missing")
            if source.start_cp is not None:
                raise MemoryValidationError("quote_requires_whole_source")
            if not isinstance(quotation.quote, str) or not quotation.quote:
                raise MemoryValidationError("invalid_quote")
            evidence_count += 1
            quotes += len(quotation.quote)
            if evidence_count > _MAX_EVIDENCE or quotes > _MAX_QUOTE_CHARS:
                raise MemoryValidationError("candidate_evidence_limit")
        # Validate ALL shapes, sources, identities and aggregate limits first.
        # A local location failure must not mask a later batch-level defect.
        for draft in frozen:
            _identity(draft.item_key)
            if draft.item_key in keys:
                raise MemoryValidationError("duplicate_candidate_item")
            keys.add(draft.item_key)
            if draft.kind not in _KINDS:
                raise MemoryValidationError("invalid_candidate_kind")
            self._store._input(draft.text, draft.condition, "fact", now_ms, None)
            bodies += len(draft.text) + len(draft.condition or "")
            if bodies > _MAX_BODY_CHARS:
                raise MemoryValidationError("candidate_body_limit")
            if not draft.supports and draft.comparison is None:
                raise MemoryValidationError("candidate_support_required")
            if draft.comparison is not None:
                proposed = draft.comparison
                if isolate_quote_failures:
                    raise MemoryValidationError("quote_isolation_warm_only")
                if not isinstance(proposed, ComparisonDraft) or proposed.kind not in _COMPARISON_KINDS:
                    raise MemoryValidationError("invalid_comparison")
                validate_quote(proposed.left)
                validate_quote(proposed.right)
            for quotation in (*draft.supports, *draft.transitions):
                validate_quote(quotation)
        if isolate_quote_failures and tuple(d.item_key for d in frozen) != tuple(str(i) for i in range(len(frozen))):
            raise MemoryValidationError("quote_isolation_requires_original_positions")
        compiled, failures, failure_inputs = [], [], []
        input_ordinals = {item.source: ordinal for ordinal, item in enumerate(task.inputs)}
        def locate(quotation):
            return locate_source_quote(quotation.source, canonical_texts[quotation.source], quotation.quote)
        for draft in frozen:
            evidence, comparison = [], None
            try:
                if draft.comparison is not None:
                    proposed = draft.comparison
                    comparison = Comparison(proposed.kind, locate(proposed.left), locate(proposed.right))
                    if comparison.left == comparison.right:
                        raise MemoryValidationError("comparison_distinct_targets_required")
                    evidence.extend(CandidateEvidence("support", 0, source) for source in (comparison.left, comparison.right))
                for role, group in (("support", draft.supports), ("transition", draft.transitions)):
                    for quotation in group:
                        evidence.append(CandidateEvidence(role, 0, locate(quotation)))
            except MemoryValidationError as error:
                if not isolate_quote_failures or str(error) not in ("quote_not_found", "quote_not_unique"):
                    raise
                failures.append((draft.item_key, str(error)))
                # Preserve all declared input identities of this failed item,
                # not only the first quote which could not be located. Roles
                # are declarations, not verified spans or semantic evidence.
                declared = {}
                for mask, quotations in ((1, draft.supports), (2, draft.transitions)):
                    for quotation in quotations:
                        ordinal = input_ordinals[quotation.source]
                        declared[ordinal] = declared.get(ordinal, 0) | mask
                failure_inputs.extend((draft.item_key, str(error), ordinal, mask)
                                      for ordinal, mask in sorted(declared.items()))
                continue
            if comparison is not None:
                supports = sorted({e for e in evidence if e.role == "support"},
                    key=lambda e: (e.source.namespace, e.source.record_key, e.source.revision, e.source.start_cp, e.source.end_cp))
                evidence = [*supports, *(e for e in evidence if e.role == "transition")]
            compiled.append((draft, tuple(evidence), comparison))
        # Hash only observable accepted bodies/coordinates. Rejected bodies and
        # rejected quotes never enter this digest, including all-rejected runs.
        payload = []
        for draft, edges, comparison in sorted(compiled, key=lambda item: item[0].item_key):
            item = [draft.item_key, draft.text, draft.kind, draft.condition,
             sorted([edge.role, edge.group, edge.source.namespace, edge.source.record_key,
                     edge.source.revision, edge.source.start_cp, edge.source.end_cp] for edge in edges)]
            if comparison is not None:
                item.append([comparison.kind, *[[s.namespace, s.record_key, s.revision, s.start_cp, s.end_cp]
                             for s in (comparison.left, comparison.right)]])
            payload.append(item)
        fingerprint = self._store._fingerprint(payload)
        if failures:
            fingerprint = self._store._fingerprint([payload, failures])
        return tuple(compiled), fingerprint, tuple(failures), tuple(sorted(failure_inputs))

    def commit(self, access: AccessScope, attempt_id: str, drafts: Sequence[CandidateDraft], *,
               canonical_texts: Mapping[SourceSpan, str], now_ms: int, actual: Usage | None = None,
               isolate_quote_failures: bool = False) -> CandidateCommitResult:
        """Submit one complete NONEMPTY result, pending review, never adoption.

        Final known usage is settled independently before structural validation.
        Bad/stale output therefore cannot erase a real external charge. Database
        failures during body commit leave at least the original reservation.
        """
        if actual is not None:
            _usage(actual)
            self._maintenance.settle_usage(access, attempt_id, actual)
        _integer(now_ms, "now_ms")
        if type(isolate_quote_failures) is not bool:
            raise MemoryValidationError("invalid_quote_isolation")
        with self._store._lock:
            self._store._check()
            attempt = self._maintenance._attempt_row(access, attempt_id)
            task = self._maintenance._task(self._maintenance._task_row(access, attempt["task_id"]))
            existing = self._db.execute("SELECT fingerprint FROM candidate_submissions WHERE attempt_id=?", (attempt_id,)).fetchone()
            if existing is not None and existing[0] is None:
                return self._receipt(access, attempt_id, "retired", True)
            if attempt["outcome"] == "no_candidates":
                raise MemoryConflict("attempt_completion_kind_conflict")
            if existing is None and attempt["outcome"] != "reserved":
                return self._receipt(access, attempt_id, "stale", True)
            if isolate_quote_failures:
                if task.work_class != "warm" or task.reason != "source_delta":
                    raise MemoryValidationError("quote_isolation_warm_only")
                # Authorize every fixed input BEFORE item-local location. The
                # resolved cursor is irrelevant for a committed replay.
                if not self._maintenance._inputs_current(access, task):
                    return self._receipt(access, attempt_id, "stale", existing is not None)
        # Freeze and locate outside the owner lock; no model or large quote scan
        # runs inside a write transaction. The fixed task is rechecked below.
        compiled, fingerprint, failures, failure_inputs = self._compile(task, drafts, canonical_texts, now_ms, isolate_quote_failures=isolate_quote_failures)
        with self._commit_guard(access), self._store._lock:
            self._store._check()
            with self._store._transaction():
                attempt = self._maintenance._attempt_row(access, attempt_id)
                existing = self._db.execute("SELECT fingerprint FROM candidate_submissions WHERE attempt_id=?", (attempt_id,)).fetchone()
                if existing is not None:
                    if existing[0] is None:
                        return self._receipt(access, attempt_id, "retired", True)
                    if isolate_quote_failures and not self._maintenance._inputs_current(access, task):
                        return self._receipt(access, attempt_id, "stale", True)
                    if existing[0] != fingerprint:
                        raise MemoryConflict("candidate_submission_conflict")
                    if failures:
                        stored = tuple(tuple(row) for row in self._db.execute(
                            "SELECT item_key,error_code,input_ordinal,declared_role_mask FROM formation_quote_failures WHERE attempt_id=? ORDER BY item_key,input_ordinal", (attempt_id,)))
                        # Empty means a pre-16 receipt: preserve its old replay,
                        # never infer or backfill the missing declaration.
                        if stored and stored != failure_inputs:
                            raise MemoryConflict("candidate_submission_conflict")
                    return self._receipt(access, attempt_id, "committed", True, failures)
                if attempt["outcome"] == "no_candidates":
                    raise MemoryConflict("attempt_completion_kind_conflict")
                row = self._maintenance._task_row(access, attempt["task_id"])
                task = self._maintenance._task(row)
                valid = (attempt["outcome"] == "reserved" and task.state == "reserved"
                         and row["current_attempt_id"] == attempt_id and self._maintenance._current(access, task))
                if not valid:
                    if attempt["outcome"] == "reserved":
                        self._db.execute("UPDATE formation_attempts SET outcome='stale' WHERE attempt_id=?", (attempt_id,))
                        if task.state not in ("done", "stale", "abandoned"):
                            self._db.execute("UPDATE formation_tasks SET state='stale' WHERE task_id=?", (task.task_id,))
                    return self._receipt(access, attempt_id, "stale", False)
                self._db.execute("INSERT INTO candidate_submissions(attempt_id,fingerprint) VALUES(?,?)", (attempt_id, fingerprint))
                self._db.executemany("INSERT INTO formation_quote_failures(attempt_id,item_key,error_code,input_ordinal,declared_role_mask) VALUES(?,?,?,?,?)",
                                     ((attempt_id, *row) for row in failure_inputs))
                for draft, edges, comparison in compiled:
                    candidate_id = uuid4().hex
                    self._db.execute("INSERT INTO candidates(candidate_id,task_id,attempt_id,item_key,text,kind,condition_text,created_at_ms) VALUES(?,?,?,?,?,?,?,?)", (candidate_id, task.task_id, attempt_id, draft.item_key, draft.text, draft.kind, draft.condition, now_ms))
                    for ordinal, edge in enumerate(edges):
                        source = edge.source
                        self._db.execute("INSERT INTO candidate_evidence(candidate_id,ordinal,role,group_no,namespace,record_key,revision,start_cp,end_cp) VALUES(?,?,?,?,?,?,?,?,?)", (candidate_id, ordinal, edge.role, edge.group, source.namespace, source.record_key, source.revision, source.start_cp, source.end_cp))
                    if comparison is not None:
                        left = edges.index(CandidateEvidence("support", 0, comparison.left))
                        right = edges.index(CandidateEvidence("support", 0, comparison.right))
                        self._db.execute("INSERT INTO candidate_comparisons VALUES(?,?,?,?)", (candidate_id, comparison.kind, left, right))
                self._db.execute("UPDATE formation_attempts SET outcome='candidates' WHERE attempt_id=?", (attempt_id,))
                self._maintenance._advance(task, terminal_state="abandoned" if failures else "done")
                self._store._change()
                return self._receipt(access, attempt_id, "committed", False, failures)

    def _comparison(self, candidate_id):
        row = self._db.execute("SELECT c.comparison_kind,l.namespace ln,l.record_key lk,l.revision lr,l.start_cp ls,l.end_cp le,r.namespace rn,r.record_key rk,r.revision rr,r.start_cp rs,r.end_cp re FROM candidate_comparisons c JOIN candidate_evidence l ON l.candidate_id=c.candidate_id AND l.ordinal=c.left_ordinal JOIN candidate_evidence r ON r.candidate_id=c.candidate_id AND r.ordinal=c.right_ordinal WHERE c.candidate_id=?", (candidate_id,)).fetchone()
        return Comparison(row["comparison_kind"], SourceSpan(row["ln"], row["lk"], row["lr"], row["ls"], row["le"]),
                          SourceSpan(row["rn"], row["rk"], row["rr"], row["rs"], row["re"])) if row else None

    def _candidate(self, row):
        edges = tuple(CandidateEvidence(edge["role"], edge["group_no"], SourceSpan(edge["namespace"], edge["record_key"], edge["revision"], edge["start_cp"], edge["end_cp"]))
                      for edge in self._db.execute("SELECT * FROM candidate_evidence WHERE candidate_id=? ORDER BY ordinal", (row["candidate_id"],)))
        review = self._db.execute("SELECT memory_id,reviewed_at_ms FROM operations WHERE candidate_id=?", (row["candidate_id"],)).fetchone()
        return Candidate(row["candidate_id"], row["task_id"], row["attempt_id"], row["item_key"],
                         MemoryScope(row["scope_kind"], row["user_id"], row["character_id"], row["project_id"]),
                         row["text"], row["kind"], row["condition_text"], row["created_at_ms"], row["row_version"],
                         row["state"], row["invalid_reason"], row["index_state"], edges,
                         row["state"] if row["state"] in ("accepted", "rejected") else "pending",
                         review["reviewed_at_ms"] if review else None, review["memory_id"] if review else None,
                         self._comparison(row["candidate_id"]) if row["state"] == "pending" and row["text"] is not None else None)

    def _review_eligible(self, access, candidate, *, check_parents=True, require_current=True):
        """Recheck privacy read-set and necessary evidence, never task cursor.

        Formation is already done. Ordinary changes to independently read
        material don't retire an item; privacy changes still cover the read-set.
        """
        inputs = self._db.execute("SELECT i.*,q.stream_id,q.action,q.formation_allowed,q.policy_revision current_policy,q.revision current_revision,q.recorded_at_ms current_recorded FROM formation_authority_inputs i LEFT JOIN source_states q ON q.namespace=i.namespace AND q.record_key=i.record_key WHERE i.task_id=?", (candidate.task_id,)).fetchall()
        necessary = {(edge.source.namespace, edge.source.record_key) for edge in candidate.evidence}
        # A source's current derived-use restriction also constrains inherited
        # recommendation authority, without requiring unrelated ordinary edits
        # to remain at the old revision after the new analysis has completed.
        parents = self._db.execute("SELECT DISTINCT p.parent_task_id,t.target_use_mask FROM formation_gap_handoffs p JOIN formation_tasks t ON t.task_id=p.parent_task_id WHERE p.task_id=?", (candidate.task_id,)).fetchall()
        for parent in parents:
            for old in self._db.execute("SELECT i.*,q.derived_use_mask FROM formation_inputs i LEFT JOIN source_states q ON q.namespace=i.namespace AND q.record_key=i.record_key WHERE i.task_id=?", (parent["parent_task_id"],)):
                if old["derived_use_mask"] is None or old["derived_use_mask"] & parent["target_use_mask"] != parent["target_use_mask"]:
                    raise MemoryConflict("stale_candidate_reference")
        for item in inputs:
            source = SourceSpan(item["namespace"], item["record_key"], item["revision"])
            self._store._check_origin(candidate.scope, source)
            if (item["action"] != "upsert" or not item["formation_allowed"]
                    or item["current_policy"] != item["policy_revision"]):
                raise MemoryConflict("stale_candidate_reference")
            # Unreferenced ordinary edits may leave this independent proposal
            # reviewable. Immutable parent scope still applies; privacy is
            # checked over the entire read-set by lifecycle/exclusions above.
            self._maintenance._source_scope(access, item, candidate.scope,
                current_parents=require_current and (source.namespace, source.record_key) in necessary,
                check_parents=check_parents)
            if require_current and (source.namespace, source.record_key) in necessary and (
                    item["current_revision"] != source.revision or item["current_recorded"] != item["recorded_at_ms"]):
                raise MemoryConflict("stale_candidate_reference")
        for retirement in self._store._source_retirements(candidate.scope.user_id) if require_current else ():
            retired = retirement.source
            for edge in candidate.evidence:
                source = edge.source
                if (source.namespace == retired.namespace and source.record_key == retired.record_key
                        and source.revision == retired.revision and (retired.start_cp is None
                        or (source.start_cp < retired.end_cp and source.end_cp > retired.start_cp))):
                    raise MemoryConflict("stale_candidate_reference")
        return tuple((SourceSpan(item["namespace"], item["record_key"], item["revision"]),
                      require_current and (item["namespace"], item["record_key"]) in necessary)
                     for item in inputs)

    def accept(self, access: AccessScope, candidate_id: str, expected_version: int, *,
               operation_id: str, item_id: str, memory_kind: str, now_ms: int) -> OperationResult:
        """Save exactly the displayed proposal as an independent explicit M1 item.

        The trusted Host authenticates access and confirms the user's decision
        and explicit M1 kind. Candidate category is never a fact certification.
        """
        if memory_kind not in ("fact", "preference", "instruction", "event"):
            raise MemoryValidationError("invalid_kind")
        return self._review(access, candidate_id, expected_version, operation_id, item_id, now_ms, memory_kind)

    def reject(self, access: AccessScope, candidate_id: str, expected_version: int, *,
               operation_id: str, item_id: str, now_ms: int) -> OperationResult:
        """Retire one displayed proposal; do not exclude its source or siblings."""
        return self._review(access, candidate_id, expected_version, operation_id, item_id, now_ms, None)

    def _review(self, access, candidate_id, expected_version, operation_id, item_id, now_ms, memory_kind):
        self._store._access(access)
        self._store._key(operation_id, item_id)
        _identity(candidate_id)
        _integer(expected_version, "expected_version", 1)
        _integer(now_ms, "now_ms")
        decision = "accepted" if memory_kind is not None else "rejected"
        kind = "candidate_accept" if memory_kind is not None else "candidate_reject"
        # No content-derived fingerprint: exact parameter replay stays possible
        # after erasure without retaining a hash of the forgotten assertion.
        fp = self._store._fingerprint([kind, candidate_id, expected_version, memory_kind])
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                replay = self._store._replay(access, operation_id, item_id, fp, kind)
                if replay:
                    return replay
                candidate = self.detail(access, candidate_id)
                if candidate.state != "pending" or candidate.row_version != expected_version:
                    raise MemoryConflict("stale_candidate_reference")
                mid = None
                if memory_kind is not None:
                    self._review_eligible(access, candidate)
                    self._store._input(candidate.text, candidate.condition, memory_kind, now_ms, None)
                    mid = self._store._insert(candidate.scope, candidate.text, memory_kind, candidate.condition, None, now_ms)
                    self._db.execute("INSERT INTO origins(memory_id,candidate_id) VALUES(?,?)", (mid, candidate_id))
                self._store._record(access, operation_id, item_id, kind, mid, decision, fp,
                                    candidate_id=candidate_id, reviewed_at_ms=now_ms)
                self._db.execute("UPDATE candidates SET state=?,text=NULL,condition_text=NULL,index_state='inactive',row_version=row_version+1 WHERE candidate_id=?", (decision, candidate_id))
                _invalidate_outputs(self._store, access,
                    self._store._candidate_use_sources(access, candidate_id, expected_version),
                    "candidate_" + decision, privacy=False)
                self._db.execute("UPDATE candidate_submissions SET fingerprint=NULL WHERE attempt_id=?", (candidate.attempt_id,))
                self._db.execute("UPDATE store_state SET cleanup_pending=1")
                if mid is None:
                    self._store._change()
            clean = self._store.cleanup()
            return OperationResult(decision, mid, 1 if mid else None, False, "pending" if mid else None, not clean)

    def _read_query(self, access):
        self._store._access(access)
        where, parameters = self._store._where(access, "s")
        return ("SELECT c.*,s.scope_kind,s.user_id,s.character_id,s.project_id FROM candidates c JOIN formation_tasks t ON t.task_id=c.task_id JOIN source_streams s ON s.stream_id=t.stream_id WHERE " + where), parameters

    def _read_candidate(self, row, access=None):
        candidate = self._candidate(row)
        if candidate.state == "pending" and candidate.text is not None:
            try:
                self._review_eligible(access, candidate)
            except (MemoryConflict, MemoryValidationError, MemoryNotFound):
                raise MemoryNotFound("candidate_not_found") from None
        return candidate

    def detail(self, access: AccessScope, candidate_id: str) -> Candidate:
        _identity(candidate_id)
        with self._store._lock:
            self._store._check()
            sql, parameters = self._read_query(access)
            row = self._db.execute(sql + " AND c.candidate_id=?", (*parameters, candidate_id)).fetchone()
            if row is None:
                raise MemoryNotFound("candidate_not_found")
            return self._read_candidate(row, access)

    def list(self, access: AccessScope, *, limit: int = 100) -> tuple[Candidate, ...]:
        _integer(limit, "limit", 1, 1000)
        with self._store._lock:
            self._store._check()
            sql, parameters = self._read_query(access)
            result = []
            for row in self._db.execute(sql + " AND c.state='pending' ORDER BY c.created_at_ms,c.candidate_id", parameters):
                try:
                    result.append(self._read_candidate(row, access))
                except MemoryNotFound:
                    continue
                if len(result) == limit:
                    break
            return tuple(result)

    def pending_index(self, access: AccessScope, *, limit: int = 100) -> tuple[CandidateReference, ...]:
        _integer(limit, "limit", 1, 1000)
        with self._store._lock:
            self._store._check()
            sql, parameters = self._read_query(access)
            result = []
            for row in self._db.execute(sql + " AND c.state='pending' AND c.index_state='pending' ORDER BY c.created_at_ms,c.candidate_id", parameters):
                try:
                    candidate = self._read_candidate(row, access)
                except MemoryNotFound:
                    continue
                result.append(CandidateReference(candidate.candidate_id, candidate.row_version))
                if len(result) == limit:
                    break
            return tuple(result)

    def exclude_sources(self, access: AccessScope, stream_id: str, sources: Sequence[SourceSpan]) -> bool:
        """Host-confirmed irreversible source exclusion; not M1 memory deletion.

        Returns whether managed cleanup completed. A busy cleanup stays durably
        observable through MemoryStore.status/cleanup and recovers on next owner.
        """
        if not isinstance(sources, (list, tuple)):
            raise MemoryValidationError("invalid_exclusion_batch")
        sources = tuple(sources)
        if not 1 <= len(sources) <= 1000:
            raise MemoryValidationError("invalid_exclusion_batch")
        for source in sources:
            _validate_source(source)
            if source is None:
                raise MemoryValidationError("invalid_source")
            _integer(source.revision, "source_revision", 1)
            if source.start_cp is not None:
                _integer(source.start_cp, "source_start")
                _integer(source.end_cp, "source_end", source.start_cp + 1)
        with self._store._lock:
            self._store._check()
            with self._store._transaction():
                self._maintenance._stream(access, stream_id)
                for source in sources:
                    if not self._db.execute("SELECT 1 FROM source_changes WHERE stream_id=? AND namespace=? AND record_key=? AND revision=? LIMIT 1", (stream_id, source.namespace, source.record_key, source.revision)).fetchone():
                        raise MemoryValidationError("exclusion_source_not_in_stream")
                    prior = self._db.execute("SELECT 1 FROM exclusions WHERE user_id=? AND namespace=? AND record_key=? AND revision=? AND start_cp IS ? AND end_cp IS ?", (access.user_id, source.namespace, source.record_key, source.revision, source.start_cp, source.end_cp)).fetchone()
                    if prior is None:
                        self._db.execute("INSERT INTO exclusions(user_id,namespace,record_key,revision,start_cp,end_cp) VALUES(?,?,?,?,?,?)", (access.user_id, source.namespace, source.record_key, source.revision, source.start_cp, source.end_cp))
                        self._db.execute("UPDATE store_state SET cleanup_pending=1")
                        self._store._change()
                _invalidate_exclusions(self._store, access, sources, permanent=True)
            return self._store.cleanup()
